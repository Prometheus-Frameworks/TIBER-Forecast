# R1a repair and executable-validation handoff

Starting eight-file identity: `83d92a66f192b931f86956604ad35a0aeda20650e1f522ebb978e81d49c0b6c3`.
Final eight-file identity: `dd884ce6b72801451984d9f99a7e9062e1b706d50c32252b7b227b3de6cae0d4`.
Base: `e295e3de745b676df571348cb8541fb5e35e3a02`.
Specification: `7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844`.

Recovered the preserved closeout ZIP (SHA-256 `621aedbcc8b84fa5fa445489ecf839769a4f545b189bd96bee5615b78b0abc59`), verified every FILES.sha256 entry, recovered the actual reviewed bytes, and verified the existing isolated checkout against them. No reconstruction from memory. Existing dependencies and package/config files were preserved; no network or installation occurred.

The only production change is ComponentEvidence.locator.provider_player_id becoming string | null, with exact-key nullable-string validation. Null explicitly represents absent provider identity; the key remains required. source_ref, artifact_sha256, row and field remain mandatory nonempty strings, the artifact digest remains checked, and existing source/identity/mapping equality checks remain unchanged. No invented identity or automatic mapping/confidence is added. A wholly unavailable locator is still distinct from an anonymous but source-located observation.

| Requirement | Code/test evidence | Author disposition |
| --- | --- | --- |
| Exact R1a reproduction | New source-located absent-provider probe plus unchanged positive control; pre-repair full focused run: 105 passed, 1 failed with component locator nonempty-string rejection | Reproduced before production repair |
| Known source location, absent provider | input.ts ComponentEvidence and cellShape; anonymous evidence tests retain exact source/hash/row/field and null provider ID | Implemented |
| Values and missingness | observed/nonzero, explicit_zero, source_null, absent, unavailable parameterized input cases; serialization checks nonzero, zero, source-null descriptive observations | Passed |
| Anonymous remains unresolved | Null canonical and provider identity, null mapping record/reference, primary false, identity_unresolved; serialized point null | Passed |
| Locator required | observed/explicit_zero/source_null missing-locator negatives; all five required locator keys tested | Passed |
| Malformed/contradictory identity | Empty, whitespace, padded string, numeric, object, array, boolean IDs reject; null/different IDs contradicting resolved row reject | Passed |
| Accepted source/mapping boundaries | Wrong source/hash/mapping, fabricated canonical or provider identity, added confidence/outcome payload negatives | Passed |
| Arithmetic/selection unchanged | Equivalent provider-known unresolved vs anonymous unresolved synthetic studies, each with 21 per position and one unresolved QB; P/W, prior counts/cents, primary eligibility, fitted rule, selection and points equal; output evidence hash changes | Passed |
| Prior R1 and F1–F6 protections | All 105 previous tests retained and pass; existing production files other than input.ts byte-identical | Preserved |

Exact changed paths:

- src/experiments/year1Week2Bootstrap/input.ts
- tests/year1Week2BootstrapInput.test.ts
- tests/year1Week2BootstrapArtifacts.test.ts

No replay fixture edit was necessary. shrinkage.ts, replay.ts, artifacts.ts, shrinkage/replay tests, packages, lockfile, tsconfig and specification are unchanged.

Executable evidence (existing Node v24.19.0 / TypeScript 5.9.3 / Vitest 2.1.9 toolchain):

- `./node_modules/.bin/tsc --noEmit`: exit 0, final-tsc.log.
- `./node_modules/.bin/vitest run tests/year1Week2BootstrapInput.test.ts tests/year1Week2BootstrapShrinkage.test.ts tests/year1Week2BootstrapReplay.test.ts tests/year1Week2BootstrapArtifacts.test.ts`: exit 0, 136 passed, 0 failed, final-vitest.log.
- Pre-repair same focused command: exit 1, 105 passed, 1 failed. No other intermediate execution failures occurred.

Only synthetic test fixtures and synthetic staged replay were executed. No football providers, retained football artifacts, databases, source builders, real-data experiments or live inference. New tests extend the existing in-memory synthetic helpers; runtime imports are unchanged.

Remaining prescribed-but-uncovered or non-exhaustive conformance cases carried from the existing review: legitimate prior/current team-change positive fixtures; delayed/resumed games; every roster/bye category; every season/position combination of 20-row and 95% sufficiency boundaries; independent multi-game inner ordering (the prior row-permutation fixture has one game). These are coverage limits, not demonstrated new defects. This repair does not claim exhaustive specification proof.

The independent-review reports, once created, provide the final review disposition; author validation alone does not close that gate. Any new finding is reported without an automatic repair/review loop. Source/finality/purpose admission, real historical method selection, live runner and Week 2 execution remain separate gates regardless of review disposition.
