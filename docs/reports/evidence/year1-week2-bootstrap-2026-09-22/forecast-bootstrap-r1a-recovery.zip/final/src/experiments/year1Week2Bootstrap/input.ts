/** Forecast-owned internal package validation. Trust is injected, never issued here. */
import { TIBER_GENERIC_FULL_PPR_V1_PROFILE_REF as PROFILE, resolveGenericFullPprCompatibility,
  validateScoringReconciliationEvidence, type ScoringReconciliationEvidenceRef } from '../../contracts/genericFullPprProfile.js';
import { canonicalForwardJson, canonicalForwardJsonBytes, forwardArtifactSha256, compareForwardCanonicalStrings as cmp } from '../../serialization/canonicalForwardArtifacts.js';
import { serviceFailure, serviceSuccess, type ServiceResult } from '../../services/result.js';
import { POSITIONS, scoreComponents, priorAnchor, assertSafeInteger, type Features, type Position } from './shrinkage.js';

export type Purpose = 'historical_method_selection' | 'live_2026_forecast_inputs';
export type EvidenceClass = 'verified_asof' | 'retrospective_reconstruction_for_method_selection';
export type SourceKind = 'prior' | 'week1' | 'population' | 'schedule' | 'labels';
export interface SourceBytes { kind: SourceKind; bytes: Uint8Array }
export interface PriorMembership {
  gsis: string; season: number; season_type: 'REG'; complete: boolean; receipt_sha256: string;
  games: { game_id: string; season: number; season_type: 'REG'; completed_at: string }[];
}
export interface SourceBinding {
  evidence: EvidenceRegistry;
  kind: SourceKind; season: number; cutoff: string; purpose: Purpose;
  sha256: string; byte_count: number; source_sha256: string; source_version: string;
  source_locator: string; provider: string; license_ref: string; owner_commit: string;
  contract_version: 'year1-bootstrap-internal-v0'; reader_version: string; transform_version: string;
  evidence_class: EvidenceClass; publication_at: string | null; retrieved_at: string | null;
  effective_at: string; generated_at: string; admitted_at: string;
  witness_ids: string[]; record_keys: string[]; complete: boolean; prior_membership: PriorMembership[] | null;
  decision_ref: string; review_ref: string; receipt_sha256: string; limitations: string[];
  reconstruction_checks: null | { completed_game_facts: boolean; cutoff_context_supported: boolean; no_postcutoff_information: boolean; labels_excluded: boolean };
  derivation: null | { receipt_sha256: string; source_sha256: string; consumed_sha256: string; transform_sha256: string };
}
export interface AvailabilityWitness {
  id: string; kind: 'publication' | 'retrieval'; at: string;
  source_sha256: string; source_version: string; receipt_sha256: string;
}
export interface PurposeAdmission {
  id: string; scope: 'forecast.bootstrap.inputs' | 'forecast.bootstrap.labels';
  purpose: Purpose; season: number; cutoff: string; source_sha256s: string[];
  decision_ref: string; review_ref: string; admitted_at: string;
}
/** Must come from the host's separately accepted trust store, not request bytes. */
export interface TrustedEvidence {
  bindings: SourceBinding[]; witnesses: AvailabilityWitness[]; admissions: PurposeAdmission[];
  reconciliations: ScoringReconciliationEvidenceRef[];
}
export interface InputRequest {
  season: number; cutoff: string; purpose: Purpose; profile: typeof PROFILE;
  sources: SourceBytes[]; admission_id: string; reconciliation: ScoringReconciliationEvidenceRef;
}
export interface PopulationRow {
  evidence: RowEvidence;
  row_id: string; gsis: string | null; position: string | null; team: string | null;
  identity_status: IdentityState;
  roster_status: 'active' | 'practice_squad' | 'injured_reserve' | 'PUP' | 'NFI' | 'suspended' | 'released' | 'free_agent' | 'unresolved';
  position_resolution_ref: string | null;
}
export interface BootstrapRow {
  population_evidence: RetainedEvidence;
  prior_identity_evidence: RetainedEvidence | null;
  prior_game_evidence: { game_id: string; season: number; season_type: 'REG'; completed_at: string; evidence: RetainedEvidence }[];
  week1_evidence: { game_id: string; state: string; evidence: RetainedEvidence }[];
  row_id: string; gsis: string | null; position: string | null; team: string | null;
  target_game_id: string | null; prior_team: string | null;
  p: number | null; w: number | null; prior_games: number | null;
  prior_total_cents: number | null; week1_cents: number | null;
  prior_state: 'available' | 'no_prior_production' | 'prior_coverage_unavailable' | 'prior_components_incomplete' | 'prior_row_missing';
  week1_state: string; changed_team: boolean | null; reasons: readonly string[];
  eligible_supported: boolean; primary: boolean;
}
export interface ValidatedWorld {
  readonly season: number; readonly cutoff: string; readonly purpose: Purpose;
  readonly profile: typeof PROFILE; readonly rows: readonly BootstrapRow[];
  readonly primary_ids: readonly string[]; readonly earliest_week2_kickoff: string;
  readonly source_hashes: readonly string[]; readonly bindings: readonly SourceBinding[];
  readonly witnesses: readonly AvailabilityWitness[];
  readonly availability: readonly { source_sha256: string; fact_available_at: string | null; witness_ids: readonly string[] }[];
  readonly reconciliation: ScoringReconciliationEvidenceRef;
  readonly admission: PurposeAdmission; readonly evidence_class: EvidenceClass;
  readonly limitations: readonly string[]; readonly hash: string;
}
const worlds = new WeakSet<object>();
const labelsIssued = new WeakSet<object>();
const kinds = ['prior', 'week1', 'population', 'schedule'] as const;
const SHA = /^[0-9a-f]{64}$/;
function fail(message: string): never { throw new Error(message); }
export function exact(value: unknown, fields: readonly string[], where: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype) return fail(`${where}: object required`);
  const own = Reflect.ownKeys(value);
  if (own.some(k => typeof k !== 'string') || own.length !== fields.length || fields.some(k => !Object.hasOwn(value, k))) return fail(`${where}: exact fields required`);
  for (const key of fields) if (!('value' in Object.getOwnPropertyDescriptor(value, key)!)) return fail(`${where}: accessors forbidden`);
  return value as Record<string, unknown>;
}
const str = (v: unknown, where: string): string => typeof v === 'string' && v.trim() === v && v.length > 0 ? v : fail(`${where}: nonempty string required`);
const nullableString = (v: unknown, where: string): string | null => v === null ? null : str(v, where);
export function instant(v: unknown): string {
  const t = str(v, 'clock');
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(t) || !Number.isFinite(Date.parse(t)) || new Date(t).toISOString() !== t) return fail('canonical UTC instant required');
  return t;
}
const list = (v: unknown, where: string): unknown[] => Array.isArray(v) ? v : fail(`${where}: array required`);
const sameSet = (a: readonly string[], b: readonly string[]): boolean => new Set(a).size === a.length && new Set(b).size === b.length && [...a].sort(cmp).join('\n') === [...b].sort(cmp).join('\n');
export const digest = (v: unknown): string => forwardArtifactSha256(canonicalForwardJsonBytes(v));
export function freeze<T>(v: T): T {
  if (v && typeof v === 'object') { for (const x of Object.values(v)) freeze(x); Object.freeze(v); }
  return v;
}
function jsonSnapshot<T>(v: T): T { return JSON.parse(canonicalForwardJson(v)) as T; }
const bindingFields = ['kind', 'season', 'cutoff', 'purpose', 'sha256', 'byte_count', 'source_sha256', 'source_version',
  'source_locator', 'provider', 'license_ref', 'owner_commit', 'contract_version', 'reader_version', 'transform_version',
  'evidence_class', 'publication_at', 'retrieved_at', 'effective_at', 'generated_at', 'admitted_at', 'witness_ids',
  'record_keys', 'complete', 'evidence', 'prior_membership', 'decision_ref', 'review_ref', 'receipt_sha256', 'limitations', 'reconstruction_checks', 'derivation'] as const;
const strings = (v: unknown, where: string) => list(v, where).map(x => str(x, where));
function reconciliationShape(v: unknown): void {
  const r = exact(v, ['status', 'validator_id', 'validator_version', 'evidence_ref', 'scoring_profile_sha256', 'source_input_sha256s'], 'reconciliation');
  for (const k of ['status', 'validator_id', 'validator_version', 'scoring_profile_sha256']) str(r[k], k);
  strings(r.source_input_sha256s, 'reconciliation sources');
  const ref = exact(r.evidence_ref, ['repository', 'path', 'artifact_version', 'content_sha256'], 'reconciliation reference');
  for (const v of Object.values(ref)) str(v, 'reconciliation reference');
}
function trustedSnapshot(trusted: TrustedEvidence): TrustedEvidence {
  // Canonical serialization rejects accessors/non-JSON values before copying. All
  // retained nested objects then pass exact schemas, including unused trust entries.
  const t = jsonSnapshot(trusted);
  exact(t, ['bindings', 'witnesses', 'admissions', 'reconciliations'], 'trust context');
  for (const k of ['bindings', 'witnesses', 'admissions', 'reconciliations'] as const) list(t[k], k);
  for (const b of t.bindings) {
    exact(b, bindingFields, 'source binding'); registryShape(b);
    for (const k of ['kind', 'cutoff', 'purpose', 'sha256', 'source_sha256', 'source_version', 'source_locator', 'provider', 'license_ref',
      'owner_commit', 'contract_version', 'reader_version', 'transform_version', 'evidence_class', 'effective_at', 'generated_at', 'admitted_at',
      'decision_ref', 'review_ref', 'receipt_sha256'] as const) str(b[k], k);
    nullableString(b.publication_at, 'publication'); nullableString(b.retrieved_at, 'retrieval');
    if (!Number.isInteger(b.season) || !Number.isSafeInteger(b.byte_count) || b.byte_count < 0 || typeof b.complete !== 'boolean') fail('binding scalar types');
    for (const k of ['witness_ids', 'record_keys', 'limitations'] as const) strings(b[k], k);
    if (new Set(b.witness_ids).size !== b.witness_ids.length) fail('duplicate witness references');
    if (b.reconstruction_checks !== null) {
      exact(b.reconstruction_checks, ['completed_game_facts', 'cutoff_context_supported', 'no_postcutoff_information', 'labels_excluded'], 'reconstruction');
      if (Object.values(b.reconstruction_checks).some(v => typeof v !== 'boolean')) fail('reconstruction flags');
    }
    if (b.derivation !== null) {
      exact(b.derivation, ['receipt_sha256', 'source_sha256', 'consumed_sha256', 'transform_sha256'], 'derivation');
      for (const h of Object.values(b.derivation)) if (typeof h !== 'string' || !SHA.test(h)) fail('derivation digest');
    }
    if (b.kind !== 'prior' && b.prior_membership !== null) fail('unexpected prior membership');
    if (b.kind === 'prior') {
      const members = list(b.prior_membership, 'certified prior membership') as PriorMembership[];
      for (const m of members) {
        exact(m, ['gsis', 'season', 'season_type', 'complete', 'receipt_sha256', 'games'], 'prior certificate');
        str(m.gsis, 'certificate identity');
        if (m.season !== b.season - 1 || m.season_type !== 'REG' || typeof m.complete !== 'boolean' || typeof m.receipt_sha256 !== 'string' || !SHA.test(m.receipt_sha256)) fail('prior certificate scope');
        const games = list(m.games, 'certified games') as PriorMembership['games'];
        for (const g of games) {
          exact(g, ['game_id', 'season', 'season_type', 'completed_at'], 'certified game'); str(g.game_id, 'certified game identity');
          if (g.season !== m.season || g.season_type !== 'REG' || instant(g.completed_at) > b.cutoff) fail('prior certified game scope');
        }
        if (new Set(games.map(g => g.game_id)).size !== games.length) fail('duplicate certified prior game');
      }
      if (!sameSet(members.map(m => m.gsis), b.record_keys)) fail('prior certificate population');
    }
  }
  for (const w of t.witnesses) {
    exact(w, ['id', 'kind', 'at', 'source_sha256', 'source_version', 'receipt_sha256'], 'witness');
    for (const v of Object.values(w)) str(v, 'witness scalar');
  }
  for (const a of t.admissions) {
    exact(a, ['id', 'scope', 'purpose', 'season', 'cutoff', 'source_sha256s', 'decision_ref', 'review_ref', 'admitted_at'], 'admission');
    for (const k of ['id', 'scope', 'purpose', 'cutoff', 'decision_ref', 'review_ref', 'admitted_at'] as const) str(a[k], k);
    if (!Number.isInteger(a.season)) fail('admission season'); strings(a.source_sha256s, 'admission sources');
  }
  t.reconciliations.forEach(reconciliationShape);
  if (new Set(t.witnesses.map(w => w.id)).size !== t.witnesses.length) fail('duplicate witnesses');
  return t;
}
function requireAdmission(t: TrustedEvidence, request: { admission_id: string; season: number; cutoff: string; purpose: Purpose }, hashes: string[], scope: PurposeAdmission['scope']): PurposeAdmission {
  const matches = t.admissions.filter(a => a.id === request.admission_id);
  if (matches.length !== 1) return fail('purpose-specific admission missing/ambiguous');
  const a = matches[0];
  if (a.scope !== scope || a.season !== request.season || a.cutoff !== request.cutoff || a.purpose !== request.purpose || !sameSet(a.source_sha256s, hashes)) return fail('admission binding mismatch');
  str(a.decision_ref, 'operator decision'); str(a.review_ref, 'independent review'); instant(a.admitted_at);
  return a;
}
function decode(source: SourceBytes, t: TrustedEvidence, season: number, cutoff: string, purpose: Purpose, isLabel = false): { binding: SourceBinding; rows: unknown[] } {
  exact(source, ['kind', 'bytes'], 'source');
  if (!(source.bytes instanceof Uint8Array)) return fail('exact source bytes required');
  const bytes = Uint8Array.from(source.bytes);
  const sha = forwardArtifactSha256(bytes);
  const bs = t.bindings.filter(b => b.sha256 === sha && b.kind === source.kind && b.season === season && b.cutoff === cutoff && b.purpose === purpose);
  if (bs.length !== 1) return fail('accepted source-version/cutoff binding missing/ambiguous');
  const b = bs[0];
  if (b.byte_count !== bytes.length || b.complete !== true || b.contract_version !== 'year1-bootstrap-internal-v0') return fail('source completeness/version');
  for (const hash of [b.sha256, b.source_sha256, b.receipt_sha256]) if (!SHA.test(hash)) fail('invalid source digest');
  if (!/^[0-9a-f]{40}$/.test(b.owner_commit)) fail('owner commit');
  for (const s of [b.provider, b.source_locator, b.source_version, b.license_ref, b.reader_version, b.transform_version, b.decision_ref, b.review_ref]) str(s, 'provenance');
  for (const clock of [b.effective_at, b.generated_at, b.admitted_at]) instant(clock);
  for (const clock of [b.publication_at, b.retrieved_at]) if (clock !== null) instant(clock);
  if (!isLabel && b.effective_at > cutoff) fail('post-cutoff effective facts');
  if (b.generated_at > b.admitted_at) fail('admission predates bytes');
  const limitations = list(b.limitations, 'limitations').map(v => str(v, 'limitation'));
  if (b.source_sha256 !== sha) {
    const d = b.derivation;
    if (!d || d.source_sha256 !== b.source_sha256 || d.consumed_sha256 !== sha || !SHA.test(d.receipt_sha256) || !SHA.test(d.transform_sha256)) fail('accepted deterministic lineage required');
  } else if (b.derivation !== null) fail('unexpected derivation');
  if (b.evidence_class !== 'verified_asof' && b.evidence_class !== 'retrospective_reconstruction_for_method_selection') fail('ineligible evidence class');
  if (!isLabel && b.evidence_class === 'verified_asof') {
    const witnesses = b.witness_ids.map(id => t.witnesses.find(w => w.id === id));
    if (!witnesses.length || witnesses.some(w => !w)) fail('independent availability witness required');
    let beforeCutoff = false;
    for (const w of witnesses) {
      if (!w || !SHA.test(w.receipt_sha256) || w.source_sha256 !== b.source_sha256 || w.source_version !== b.source_version) fail('witness exact-byte/version mismatch');
      instant(w.at);
      if (w.kind !== 'publication' && w.kind !== 'retrieval') fail('witness kind');
      if (w.at !== (w.kind === 'retrieval' ? b.retrieved_at : b.publication_at)) fail('witness clock mismatch');
      if (w.at <= cutoff) beforeCutoff = true;
    }
    if (!beforeCutoff) fail('availability not evidenced by cutoff');
  } else if (!isLabel) {
    if (purpose !== 'historical_method_selection' || season === 2026) fail('reconstruction cannot satisfy live input gate');
    const c = b.reconstruction_checks;
    if (!c || c.completed_game_facts !== true || c.cutoff_context_supported !== true || c.no_postcutoff_information !== true || c.labels_excluded !== true || !limitations.length) fail('reconstruction qualification missing');
  }
  let body: unknown;
  try { body = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { return fail('invalid source JSON bytes'); }
  if (forwardArtifactSha256(canonicalForwardJsonBytes(body)) !== sha) fail('internal package must use canonical JSON bytes');
  const obj = exact(body, ['kind', 'season', 'rows'], 'source body');
  if (obj.kind !== source.kind || obj.season !== (source.kind === 'prior' ? season - 1 : season)) return fail('source season/kind mismatch');
  const rows = list(obj.rows, 'source rows');
  return { binding: b, rows };
}
function keysMatch(keys: string[], b: SourceBinding): void {
  if (!sameSet(keys, b.record_keys)) fail('truncated/duplicate source inventory');
}
export function assertValidatedWorld(w: ValidatedWorld): void {
  if (!w || !worlds.has(w)) fail('unissued/mutated world');
}
export function featuresFor(row: BootstrapRow): Features {
  if (!row.primary || row.prior_total_cents === null || row.prior_games === null || row.week1_cents === null) return fail('row outside shared comparison cohort');
  return { prior_total_cents: row.prior_total_cents, prior_games: row.prior_games, week1_cents: row.week1_cents };
}

export function validateInputs(value: unknown, trusted: TrustedEvidence): ServiceResult<ValidatedWorld> {
  try {
    const r = exact(value, ['season', 'cutoff', 'purpose', 'profile', 'sources', 'admission_id', 'reconciliation'], 'input request') as unknown as InputRequest;
    if (!Number.isInteger(r.season) || r.season < 2022 || r.season > 2026) fail('unsupported season');
    instant(r.cutoff);
    if (r.purpose !== (r.season === 2026 ? 'live_2026_forecast_inputs' : 'historical_method_selection')) fail('season/purpose mismatch');
    if (!resolveGenericFullPprCompatibility(r.profile).ok) fail('wrong scoring profile');
    const t = trustedSnapshot(trusted);
    const sources = list(r.sources, 'sources') as SourceBytes[];
    if (!sameSet(sources.map(s => s.kind), [...kinds])) fail('exact four input sources required; labels forbidden');
    const decoded = Object.fromEntries(kinds.map(k => [k, decode(sources.find(s => s.kind === k)!, t, r.season, r.cutoff, r.purpose)])) as Record<typeof kinds[number], ReturnType<typeof decode>>;
    const bindings = kinds.map(k => decoded[k].binding);
    const hashes = bindings.map(b => b.sha256).sort(cmp);
    const admission = requireAdmission(t, r, hashes, 'forecast.bootstrap.inputs');
    reconciliationShape(r.reconciliation);
    const reconciliation = validateScoringReconciliationEvidence(r.reconciliation, { run_status: 'succeeded', expected_scoring_profile_sha256: PROFILE.profile_sha256, expected_source_input_sha256s: hashes });
    if (!reconciliation.ok || !t.reconciliations.some(x => canonicalForwardJson(x) === canonicalForwardJson(r.reconciliation))) fail('trusted scoring reconciliation required');

    const scheduleKeys: string[] = [], week1 = new Set<string>();
    const teams = new Map<string, string>(), kickoffs: string[] = [];
    for (const v of decoded.schedule.rows) {
      const g = exact(v, ['game_id', 'week', 'home', 'away', 'completed_at', 'kickoff'], 'game');
      const id = str(g.game_id, 'game ID'), home = str(g.home, 'home'), away = str(g.away, 'away');
      if (home === away || (g.week !== 1 && g.week !== 2)) fail('game structure');
      instant(g.kickoff);
      scheduleKeys.push(`${g.week}:${id}`);
      if (g.week === 1) {
        if (instant(g.completed_at) > r.cutoff || (g.kickoff as string) > (g.completed_at as string)) fail('whole Week 1 incomplete');
        week1.add(id);
      } else {
        if (g.completed_at !== null || (g.kickoff as string) <= r.cutoff) fail('target-week information/cutoff');
        if (teams.has(home) || teams.has(away)) fail('multiple target team games');
        teams.set(home, id); teams.set(away, id); kickoffs.push(g.kickoff as string);
      }
    }
    keysMatch(scheduleKeys, decoded.schedule.binding);
    if (!week1.size || !kickoffs.length) fail('empty schedule');

    const priorEvidenceUsed: string[] = [], weeklyEvidenceUsed: string[] = [], populationEvidenceUsed: string[] = [];
    const priors = new Map<string, { identity: RetainedEvidence; lineage: BootstrapRow['prior_game_evidence']; total: number | null; games: number | null; position: string; team: string; state: BootstrapRow['prior_state'] }>();
    const priorKeys: string[] = [];
    for (const v of decoded.prior.rows) {
      const p = exact(v, ['gsis', 'season', 'position', 'team', 'coverage', 'games', 'evidence'], 'prior');
      const id = str(p.gsis, 'prior identity'); priorKeys.push(id);
      if (p.season !== r.season - 1 || !['complete', 'unavailable'].includes(p.coverage as string)) fail('prior scope');
      const identity = preserveEvidence(p.evidence, decoded.prior.binding, JSON.stringify([id]), id, null, 'identity', priorEvidenceUsed);
      const lineage: BootstrapRow['prior_game_evidence'] = [];
      const gameRows = list(p.games, 'recorded games'), ids: string[] = [];
      const certificate = decoded.prior.binding.prior_membership!.find(m => m.gsis === id)!;
      let total = 0, complete = p.coverage === 'complete' && certificate.complete;
      let incompleteComponents = false;
      for (const gv of gameRows) {
        const game = exact(gv, ['game_id', 'season', 'season_type', 'completed_at', 'components', 'evidence'], 'prior game');
        ids.push(str(game.game_id, 'prior game ID'));
        if (game.season !== r.season - 1 || game.season_type !== 'REG' || instant(game.completed_at) > r.cutoff) fail('prior game season/REG scope');
        const certified = certificate.games.find(g => g.game_id === game.game_id);
        if (!certified || certified.completed_at !== game.completed_at || certified.season !== game.season || certified.season_type !== game.season_type) fail('prior game membership proof');
        const evidence = preserveEvidence(game.evidence, decoded.prior.binding, JSON.stringify([id, game.game_id]), id, game.components, 'production', priorEvidenceUsed);
        lineage.push({ game_id: game.game_id as string, season: game.season as number, season_type: 'REG', completed_at: game.completed_at as string, evidence });
        const points = scoreComponents(game.components);
        if (points === null) { complete = false; incompleteComponents = true; } else total = assertSafeInteger(total + points, 'prior aggregate');
      }
      if (new Set(ids).size !== ids.length) fail('duplicate recorded game');
      if (!sameSet(ids, certificate.games.map(g => g.game_id))) fail('prior denominator membership mismatch');
      const state: BootstrapRow['prior_state'] = p.coverage !== 'complete' || !certificate.complete ? 'prior_coverage_unavailable' :
        incompleteComponents ? 'prior_components_incomplete' : ids.length === 0 ? 'no_prior_production' : 'available';
      priors.set(id, { identity, lineage: lineage.sort((a, z) => cmp(a.game_id, z.game_id)), total: complete && ids.length > 0 ? total : null, games: complete && ids.length > 0 ? ids.length : null,
        position: str(p.position, 'prior position'), team: str(p.team, 'prior team'), state });
    }
    keysMatch(priorKeys, decoded.prior.binding); evidenceInventory(decoded.prior.binding, priorEvidenceUsed);
    const weekly = new Map<string, { gsis: string | null; game_id: string; evidence: RetainedEvidence; cents: number | null; state: string }[]>(), weeklyKeys: string[] = [];
    for (const v of decoded.week1.rows) {
      const w = exact(v, ['population_row_id', 'gsis', 'season', 'week', 'game_id', 'state', 'zero_evidence_ref', 'components', 'evidence'], 'Week 1');
      const id = str(w.population_row_id, 'Week 1 population row'), gsis = nullableString(w.gsis, 'Week 1 identity'), game = str(w.game_id, 'Week 1 game');
      if (w.season !== r.season || w.week !== 1 || !week1.has(game)) fail('Week 1 game/season mapping');
      if (!['played', 'played_zero', 'did_not_play', 'unresolved'].includes(w.state as string)) fail('participation state');
      nullableString(w.zero_evidence_ref, 'zero evidence');
      const evidence = preserveEvidence(w.evidence, decoded.week1.binding, JSON.stringify([id, game]), gsis, w.components, 'week1', weeklyEvidenceUsed);
      let cents = scoreComponents(w.components);
      if (w.state === 'unresolved') cents = null;
      if (w.state === 'played_zero' || w.state === 'did_not_play') {
        if (Object.values(w.components as object).some(x => x !== 0) || !w.zero_evidence_ref) cents = null;
      }
      weeklyKeys.push(`${id}:${game}`);
      weekly.set(id, [...(weekly.get(id) ?? []), { gsis, game_id: game, evidence, cents, state: w.state as string }]);
    }
    keysMatch(weeklyKeys, decoded.week1.binding); evidenceInventory(decoded.week1.binding, weeklyEvidenceUsed);
    const rows: BootstrapRow[] = [], popKeys: string[] = [], gsisIds = new Set<string>();
    for (const v of decoded.population.rows) {
      const p = exact(v, ['row_id', 'gsis', 'position', 'team', 'identity_status', 'roster_status', 'position_resolution_ref', 'evidence'], 'population') as unknown as PopulationRow;
      popKeys.push(str(p.row_id, 'population row ID'));
      nullableString(p.gsis, 'canonical identity'); nullableString(p.position, 'position'); nullableString(p.team, 'team'); nullableString(p.position_resolution_ref, 'position resolution');
      if (!identityStates.includes(p.identity_status)) fail('identity status');
      if (p.identity_status === 'conflicting') fail('identity_conflicting');
      const populationEvidence = preserveEvidence(p.evidence, decoded.population.binding, JSON.stringify([p.row_id]), p.gsis, null, 'identity', populationEvidenceUsed);
      if (p.identity_status !== populationEvidence.identity.status) fail('population identity evidence status');
      if (p.gsis && gsisIds.has(p.gsis)) fail('duplicate canonical population identity');
      if (p.gsis) gsisIds.add(p.gsis);
      const prior = p.gsis ? priors.get(p.gsis) : undefined, obs = weekly.get(p.row_id) ?? [];
      if (obs.some(o => o.gsis !== p.gsis)) fail('Week 1 population identity mismatch');
      const reasons: string[] = [];
      if (p.identity_status !== 'resolved' || !p.gsis) reasons.push('identity_unresolved');
      const rosterStates = ['active', 'practice_squad', 'injured_reserve', 'PUP', 'NFI', 'suspended'];
      if (!rosterStates.includes(p.roster_status) && !['released', 'free_agent', 'unresolved'].includes(p.roster_status)) fail('unknown roster vocabulary');
      if (p.roster_status === 'unresolved' || (!p.team && rosterStates.includes(p.roster_status))) reasons.push('eligibility_unresolved');
      else if (!rosterStates.includes(p.roster_status) || !p.team || !teams.has(p.team)) reasons.push('population_ineligible');
      if (!p.position || (prior && prior.position !== p.position && !p.position_resolution_ref)) reasons.push('position_unresolved');
      else if (!(POSITIONS as readonly string[]).includes(p.position)) reasons.push('unsupported_position');
      const eligible = reasons.length === 0;
      const priorState = prior?.state ?? 'prior_row_missing';
      if (priorState !== 'available') reasons.push(priorState);
      const w = obs.length === 1 ? obs[0].cents : null;
      if (w === null) reasons.push('week1_unavailable');
      if (obs.length > 1) reasons.push('unsupported_week1_game_structure');
      rows.push({ population_evidence: populationEvidence, prior_identity_evidence: prior?.identity ?? null, prior_game_evidence: prior?.lineage ?? [],
        week1_evidence: obs.map(o => ({ game_id: o.game_id, state: o.state, evidence: o.evidence })).sort((a, z) => cmp(a.game_id, z.game_id)), row_id: p.row_id, gsis: p.gsis, position: p.position, team: p.team, target_game_id: p.team ? teams.get(p.team) ?? null : null,
        prior_team: prior?.team ?? null, p: prior?.total != null && prior.games !== null ? priorAnchor(prior.total, prior.games) : null,
        w: w === null ? null : w / 100, prior_games: prior?.games ?? null, prior_total_cents: prior?.total ?? null, week1_cents: w,
        prior_state: priorState, week1_state: obs.length === 1 ? obs[0].state : 'unavailable', changed_team: prior && p.team ? prior.team !== p.team : null,
        reasons, eligible_supported: eligible, primary: reasons.length === 0 });
    }
    keysMatch(popKeys, decoded.population.binding); evidenceInventory(decoded.population.binding, populationEvidenceUsed);
    if ([...weekly.keys()].some(id => !popKeys.includes(id))) fail('Week 1 row outside population');
    if (!rows.length) fail('empty population');
    rows.sort((a, b) => cmp(a.row_id, b.row_id));
    const witnessIds = [...new Set(bindings.flatMap(b => b.witness_ids))].sort(cmp);
    const witnesses = witnessIds.map(id => t.witnesses.find(w => w.id === id) ?? fail('referenced witness missing'));
    const availability = bindings.map(b => {
      const accepted = witnesses.filter(w => b.witness_ids.includes(w.id) && w.at <= r.cutoff).sort((a, z) => cmp(a.at, z.at) || cmp(a.id, z.id));
      return { source_sha256: b.source_sha256, fact_available_at: b.evidence_class === 'verified_asof' ? accepted[0].at : null,
        witness_ids: b.evidence_class === 'verified_asof' ? accepted.map(w => w.id) : [] };
    });
    const core = { season: r.season, cutoff: r.cutoff, purpose: r.purpose, profile: PROFILE, rows,
      primary_ids: rows.filter(x => x.primary).map(x => x.row_id), earliest_week2_kickoff: kickoffs.sort(cmp)[0], source_hashes: hashes, bindings, witnesses, availability, reconciliation: jsonSnapshot(r.reconciliation), admission,
      evidence_class: bindings.some(b => b.evidence_class !== 'verified_asof') ? 'retrospective_reconstruction_for_method_selection' as const : 'verified_asof' as const,
      limitations: [...new Set(bindings.flatMap(b => b.limitations))].sort(cmp) };
    if (r.purpose === 'live_2026_forecast_inputs' && (admission.admitted_at >= core.earliest_week2_kickoff || bindings.some(b => b.admitted_at >= core.earliest_week2_kickoff))) fail('live input admission missed target kickoff');
    const world: ValidatedWorld = freeze({ ...core, hash: digest(core) }); worlds.add(world);
    return serviceSuccess(world);
  } catch (error) { return serviceFailure({ code: 'BOOTSTRAP_INPUT_REJECTED', message: error instanceof Error ? error.message : 'invalid input' }); }
}

export interface LabelRequest { source: SourceBytes; admission_id: string }
export interface ValidatedLabels {
  readonly world_hash: string; readonly source_hash: string; readonly binding: SourceBinding;
  readonly admission: PurposeAdmission;
  readonly outcomes: Readonly<Record<string, number | null>>; readonly reasons: Readonly<Record<string, string>>;
}
export function validateLabels(value: unknown, world: ValidatedWorld, trusted: TrustedEvidence): ValidatedLabels {
  assertValidatedWorld(world);
  if (world.purpose !== 'historical_method_selection') fail('live labels forbidden');
  const request = exact(value, ['source', 'admission_id'], 'label request') as unknown as LabelRequest;
  if (request.source.kind !== 'labels') fail('label source kind');
  const t = trustedSnapshot(trusted), decoded = decode(request.source, t, world.season, world.cutoff, world.purpose, true);
  const admission = requireAdmission(t, { ...world, admission_id: request.admission_id }, [decoded.binding.sha256], 'forecast.bootstrap.labels');
  const labelEvidenceUsed: string[] = [];
  const outcomes: Record<string, number | null> = Object.create(null), reasons: Record<string, string> = Object.create(null), keys: string[] = [];
  for (const v of decoded.rows) {
    const row = exact(v, ['row_id', 'gsis', 'season', 'week', 'game_id', 'state', 'zero_evidence_ref', 'components', 'evidence'], 'label');
    const id = str(row.row_id, 'label row'); keys.push(id);
    const member = world.rows.find(x => x.row_id === id);
    if (!member || row.gsis !== member.gsis || row.season !== world.season || row.week !== 2 || row.game_id !== member.target_game_id) fail('label membership/week mismatch');
    if (!['played', 'played_zero', 'did_not_play', 'unresolved'].includes(row.state as string)) fail('label state');
    nullableString(row.zero_evidence_ref, 'label zero evidence');
    preserveEvidence(row.evidence, decoded.binding, JSON.stringify([id]), nullableString(row.gsis, 'label identity'), row.components, 'production', labelEvidenceUsed);
    let cents = row.components === null ? null : scoreComponents(row.components);
    if (row.state === 'unresolved') cents = null;
    if (row.state === 'played_zero' || row.state === 'did_not_play') {
      if (!row.zero_evidence_ref || !row.components || Object.values(row.components as object).some(x => x !== 0)) cents = null;
    }
    outcomes[id] = cents;
    if (cents === null) reasons[id] = 'outcome_unresolved';
  }
  keysMatch(keys, decoded.binding); evidenceInventory(decoded.binding, labelEvidenceUsed);
  if (!sameSet(keys, world.rows.map(r => r.row_id))) fail('label ledger must retain entire frozen population');
  const result = freeze({ world_hash: world.hash, source_hash: decoded.binding.sha256, binding: decoded.binding, admission, outcomes, reasons });
  labelsIssued.add(result); return result;
}
export function assertValidatedLabels(v: ValidatedLabels): void { if (!v || !labelsIssued.has(v)) fail('unissued label package'); }

export const COMPONENT_FIELDS = ['receptions', 'receiving_yards', 'receiving_tds', 'rushing_yards', 'rushing_tds', 'passing_yards', 'passing_tds', 'interceptions'] as const;
type ComponentField = typeof COMPONENT_FIELDS[number];
type IdentityState = 'resolved' | 'unresolved' | 'unavailable' | 'conflicting';
export interface EvidenceSource {
  id: string; kind: SourceKind; season: number; sha256: string; locator: string; provider: string; receipt_sha256: string;
}
export interface IdentityMapping {
  id: string; source_ref: string; provider_player_id: string; canonical_gsis: string | null;
  version: string; sha256: string; receipt_sha256: string;
  status: IdentityState; confidence: 'provider_verified' | 'high' | 'medium' | 'low' | null;
}
export interface IdentityEvidence { status: IdentityState; source_ref: string | null; provider_player_id: string | null; mapping_ref: string | null }
export interface ComponentEvidence {
  value: number | null; state: 'observed' | 'explicit_zero' | 'source_null' | 'absent' | 'unavailable'; units: 'count' | 'yards' | null;
  locator: null | { source_ref: string; artifact_sha256: string; row: string; field: string; provider_player_id: string | null };
}
export interface RowEvidence {
  identity: IdentityEvidence;
  components: Record<ComponentField, ComponentEvidence> | null;
  descriptive: { targets: ComponentEvidence; carries: ComponentEvidence } | null;
}
export interface EvidenceRegistry {
  sources: EvidenceSource[]; mappings: IdentityMapping[]; rows: { key: string; evidence: RowEvidence }[];
}
export interface RetainedEvidence extends RowEvidence { mapping_record: IdentityMapping | null; source_records: EvidenceSource[] }
const identityStates = ['resolved', 'unresolved', 'unavailable', 'conflicting'];
const hashString = (v: unknown) => { if (typeof v !== 'string' || !SHA.test(v)) fail('evidence digest'); };
function identityShape(value: unknown): IdentityEvidence {
  const x = exact(value, ['status', 'source_ref', 'provider_player_id', 'mapping_ref'], 'identity evidence') as unknown as IdentityEvidence;
  if (!identityStates.includes(x.status)) fail('identity evidence status');
  for (const v of [x.source_ref, x.provider_player_id, x.mapping_ref]) nullableString(v, 'identity evidence reference');
  return x;
}
function cellShape(value: unknown, field: string): ComponentEvidence {
  const x = exact(value, ['value', 'state', 'units', 'locator'], 'component evidence') as unknown as ComponentEvidence;
  const unit = field.endsWith('_yards') ? 'yards' : 'count';
  if (x.units !== null && x.units !== unit) fail('component units');
  if (!['observed', 'explicit_zero', 'source_null', 'absent', 'unavailable'].includes(x.state)) fail('component state');
  if (x.state === 'observed' || x.state === 'explicit_zero') {
    if (!Number.isSafeInteger(x.value) || x.units !== unit || !x.locator || (x.state === 'explicit_zero' ? x.value !== 0 : x.value === 0)) fail('component value/status');
    if (unit === 'count' && x.value! < 0) fail('negative count');
  } else if (x.value !== null) fail('missing component must be null');
  if (x.state === 'source_null' && x.locator === null) fail('source null requires source locator');
  if (x.locator !== null) {
    const l = exact(x.locator, ['source_ref', 'artifact_sha256', 'row', 'field', 'provider_player_id'], 'component locator');
    for (const v of [l.source_ref, l.artifact_sha256, l.row, l.field]) str(v, 'component locator');
    nullableString(l.provider_player_id, 'component locator provider identity'); hashString(l.artifact_sha256);
  }
  return x;
}
function rowEvidenceShape(value: unknown): RowEvidence {
  const e = exact(value, ['identity', 'components', 'descriptive'], 'row evidence') as unknown as RowEvidence;
  identityShape(e.identity);
  if (e.components !== null) { exact(e.components, COMPONENT_FIELDS, 'component evidence fields'); for (const k of COMPONENT_FIELDS) cellShape(e.components[k], k); }
  if (e.descriptive !== null) { exact(e.descriptive, ['targets', 'carries'], 'descriptive fields'); for (const k of ['targets', 'carries'] as const) cellShape(e.descriptive[k], k); }
  return e;
}
function registryShape(b: SourceBinding): void {
  const r = exact(b.evidence, ['sources', 'mappings', 'rows'], 'accepted evidence registry') as unknown as EvidenceRegistry;
  for (const k of ['sources', 'mappings', 'rows'] as const) list(r[k], k);
  for (const s of r.sources) {
    exact(s, ['id', 'kind', 'season', 'sha256', 'locator', 'provider', 'receipt_sha256'], 'accepted evidence source');
    for (const v of [s.id, s.locator, s.provider]) str(v, 'source reference'); hashString(s.sha256); hashString(s.receipt_sha256);
    if (s.kind !== b.kind || s.season !== (b.kind === 'prior' ? b.season - 1 : b.season)) fail('evidence source channel/season');
  }
  for (const m of r.mappings) {
    exact(m, ['id', 'source_ref', 'provider_player_id', 'canonical_gsis', 'version', 'sha256', 'receipt_sha256', 'status', 'confidence'], 'accepted identity mapping');
    for (const v of [m.id, m.source_ref, m.provider_player_id, m.version]) str(v, 'mapping reference');
    nullableString(m.canonical_gsis, 'mapping canonical identity'); hashString(m.sha256); hashString(m.receipt_sha256);
    if (!identityStates.includes(m.status) || ![null, 'provider_verified', 'high', 'medium', 'low'].includes(m.confidence)) fail('mapping status/confidence');
    if ((m.status === 'resolved') !== (m.canonical_gsis !== null) || !r.sources.some(s => s.id === m.source_ref)) fail('mapping source/canonical binding');
  }
  for (const row of r.rows) { exact(row, ['key', 'evidence'], 'accepted row evidence'); str(row.key, 'accepted row key'); rowEvidenceShape(row.evidence); }
  for (const ids of [r.sources.map(s => s.id), r.mappings.map(m => m.id), r.rows.map(x => x.key)]) if (new Set(ids).size !== ids.length) fail('duplicate evidence registry key');
  if (b.kind === 'schedule' && (r.sources.length || r.mappings.length || r.rows.length)) fail('player evidence in schedule');
}
function preserveEvidence(value: unknown, b: SourceBinding, key: string, gsis: string | null, components: unknown, context: 'identity' | 'production' | 'week1', used: string[]): RetainedEvidence {
  const e = rowEvidenceShape(value), accepted = b.evidence.rows.find(r => r.key === key);
  if (!accepted || canonicalForwardJson(accepted.evidence) !== canonicalForwardJson(e)) fail('unaccepted row evidence');
  used.push(key);
  const i = e.identity, source = i.source_ref === null ? null : b.evidence.sources.find(s => s.id === i.source_ref) ?? fail('unaccepted identity source');
  const mapping = i.mapping_ref === null ? null : b.evidence.mappings.find(m => m.id === i.mapping_ref) ?? fail('unaccepted identity mapping');
  if (i.status === 'conflicting') fail('identity_conflicting');
  if (mapping && (mapping.source_ref !== i.source_ref || mapping.provider_player_id !== i.provider_player_id || mapping.canonical_gsis !== gsis || mapping.status !== i.status)) fail('mapping/player conflict');
  if (i.status === 'resolved' && (!source || !i.provider_player_id || !mapping || gsis === null)) fail('resolved identity requires accepted mapping');
  if (i.status !== 'resolved' && gsis !== null) fail('unresolved canonical identity');
  if ((i.provider_player_id !== null && !source) || (i.status === 'unavailable' && (i.source_ref !== null || i.provider_player_id !== null || i.mapping_ref !== null))) fail('unavailable identity evidence');
  if ((context === 'identity') !== (e.components === null) || (context === 'week1') !== (e.descriptive !== null)) fail('row evidence channel');
  const sources = new Map<string, EvidenceSource>(); if (source) sources.set(source.id, source);
  const check = (cell: ComponentEvidence) => {
    if (cell.locator) {
      const l = cell.locator, s = b.evidence.sources.find(s => s.id === l.source_ref);
      if (!s || s.sha256 !== l.artifact_sha256 || l.source_ref !== i.source_ref || l.provider_player_id !== i.provider_player_id) fail('component source/player binding');
      sources.set(s.id, s);
    }
  };
  if (e.components) {
    const numeric = components === null ? null : exact(components, COMPONENT_FIELDS, 'numeric components');
    for (const k of COMPONENT_FIELDS) {
      check(e.components[k]);
      if (e.components[k].value !== (numeric === null ? null : numeric[k])) fail('component evidence/numeric disagreement');
    }
  }
  if (e.descriptive) { check(e.descriptive.targets); check(e.descriptive.carries); }
  return { ...e, mapping_record: mapping, source_records: [...sources.values()].sort((a, z) => cmp(a.id, z.id)) };
}
function evidenceInventory(b: SourceBinding, used: string[]): void {
  if (!sameSet(used, b.evidence.rows.map(r => r.key))) fail('unused/truncated row evidence');
}
