/** Candidate-only historical study serialization; no publisher or live runner. */
import { canonicalForwardJsonBytes, canonicalForwardJsonlBytes, forwardArtifactSha256 } from '../../serialization/canonicalForwardArtifacts.js';
import { TIBER_GENERIC_FULL_PPR_V1_PROFILE_REF as PROFILE } from '../../contracts/genericFullPprProfile.js';
import { digest, exact, freeze, instant } from './input.js';
import { assertCompletedStudy, type CompletedStudy } from './replay.js';
import { movement, NUMERIC_VERSION, PRIOR_BASIS } from './shrinkage.js';

export const BASE_COMMIT = 'e295e3de745b676df571348cb8541fb5e35e3a02' as const;
export const SPECIFICATION_SHA256 = '7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844' as const;
export interface CandidateMetadata {
  run_id: string; generated_at: string; code_sha256: string; configuration_sha256: string; specification_sha256: typeof SPECIFICATION_SHA256;
}
const SHA = /^[0-9a-f]{64}$/;
function metadata(value: unknown): CandidateMetadata {
  const v = exact(value, ['run_id', 'generated_at', 'code_sha256', 'configuration_sha256', 'specification_sha256'], 'candidate metadata') as unknown as CandidateMetadata;
  if (typeof v.run_id !== 'string' || !v.run_id.trim() || v.run_id.trim() !== v.run_id) throw new Error('run identity');
  instant(v.generated_at);
  if (!SHA.test(v.code_sha256) || !SHA.test(v.configuration_sha256) || v.specification_sha256 !== SPECIFICATION_SHA256) throw new Error('candidate code/config/spec pins');
  return { ...v };
}
export function buildCandidate(study: CompletedStudy, proposedMetadata: CandidateMetadata) {
  assertCompletedStudy(study);
  const m = metadata(proposedMetadata), world = study.prepared_final.world;
  if (m.run_id !== study.identity.run_id || m.code_sha256 !== study.identity.code_sha256 || m.configuration_sha256 !== study.identity.configuration_sha256 || m.specification_sha256 !== study.identity.specification_sha256) throw new Error('sealed run/code/config identity mismatch');
  if (world.season !== 2025 || world.purpose !== 'historical_method_selection') throw new Error('offline final-study candidate only; no live inference entry point');
  if ([...study.feature_worlds.flatMap(w => w.bindings.map(b => b.generated_at)), study.final.label_binding.generated_at, study.validation.label_binding.generated_at,
    ...study.training_reports.map(r => r.label_binding.generated_at)].some(t => t > m.generated_at)) throw new Error('generation predates consumed evidence');
  const reports = { training: study.training_reports, validation: study.validation, final: study.final };
  const rule = {
    contract: 'forecast.year1_week2_bootstrap.rule', contract_version: '0.1.0', selected: study.selected,
    numeric_version: NUMERIC_VERSION, fitted_alpha: study.rule,
    training_world_hashes: study.training_world_hashes, training_label_hashes: study.training_label_hashes,
    validation_report_sha256: digest(study.validation), final_report_sha256: digest(study.final), validation_seal: study.seal,
    selection_result: study.result, historical_evidence_class: study.evidence_class, limitations: study.limitations,
  };
  const rows = world.rows.map(row => {
    const usable = row.primary && study.selected !== null;
    const point = usable ? study.prepared_final.points[row.row_id][study.selected!] : null;
    const emitted = usable ? study.prepared_final.emitted[row.row_id][study.selected!] : null;
    const emittedPrior = row.primary ? study.prepared_final.emitted[row.row_id].C0 : null;
    const reasons = [...row.reasons, ...(study.selected === null ? ['bootstrap_study_inconclusive'] : [])];
    return {
      population_row_id: row.row_id, identity_evidence: row.population_evidence, gsis: row.gsis, position: row.position, team: row.team,
      target: { season: world.season, week: 2, horizon: 'single_scoring_week' }, scoring_profile: PROFILE,
      status: usable ? 'available_candidate' : 'unavailable', status_reasons: reasons,
      prior: { identity_evidence: row.prior_identity_evidence, game_evidence: row.prior_game_evidence, basis: PRIOR_BASIS, season: world.season - 1, value: row.p, emitted_value: emittedPrior,
        availability: row.prior_state, recorded_production_games: row.prior_games, total_cents: row.prior_total_cents, future_availability_modeled: false },
      week_1_observed: { evidence: row.week1_evidence, value: row.w, state: row.week1_state, method_use: study.selected === 'C0' && usable ? 'observed_no_predictive_weight_under_v0' : usable ? 'combined_v0' : 'forecast_unavailable' },
      forecast: { method: study.selected, point, emitted_point: emitted, uncertainty_status: 'unavailable_not_calibrated',
        floor: null, median: null, ceiling: null, confidence: null, probabilities: null, future_availability_modeled: false },
      movement: { versus_prior: movement(emitted, emittedPrior, usable), formula_version: NUMERIC_VERSION,
        reason: !usable ? 'valid_anchor_forecast_pair_unavailable' : study.selected === 'C0' ? 'c0_selected_week1_did_not_move_forecast' : 'alpha_times_week1_minus_anchor' },
      limitations: [...study.limitations, 'recorded_production_game_denominator', 'future_availability_not_modeled', 'uncertainty_not_calibrated',
        ...(row.prior_games !== null && row.prior_games < 8 ? ['weak_prior'] : [])],
      source_refs: world.source_hashes,
    };
  });
  const manifest = {
    contract: 'forecast.year1_week2_bootstrap.candidate', contract_version: '0.1.0',
    candidate_only: true, production_ready: false, consumer_eligibility: 'not_eligible_pending_admission',
    artifact_context: 'retrospective_method_study_candidate',
    run: { ...m, base_commit: BASE_COMMIT, numeric_version: NUMERIC_VERSION, method: study.selected },
    target: { season: world.season, week: 2, observed_through_week: 1, horizon: 'single_scoring_week' },
    forecast_cutoff: world.cutoff, scoring_profile: PROFILE, world_sha256: world.hash,
    population_row_ids: world.rows.map(r => r.row_id), source_sha256s: world.source_hashes,
    source_bindings: world.bindings, availability_witnesses: world.witnesses, availability_bounds: world.availability, scoring_reconciliation: world.reconciliation,
    historical_input_evidence: study.feature_worlds.map(w => ({ season: w.season, world_sha256: w.hash, bindings: w.bindings,
      witnesses: w.witnesses, availability: w.availability, reconciliation: w.reconciliation, admission: w.admission })), input_admission: world.admission,
    method_evidence: { class: study.evidence_class, limitations: study.limitations, study_sha256: study.hash },
    feature_families: { production_bootstrap: 'active', Teamstate: 'inactive', Rookies: 'inactive', role_opportunity: 'inactive', special_teams: 'inactive', injury_interpretation: 'inactive', operator_film: 'inactive' },
    rows_sha256: forwardArtifactSha256(canonicalForwardJsonlBytes(rows)), rule_sha256: digest(rule), reports_sha256: digest(reports),
  };
  return freeze({ manifest, rows, rule, reports });
}
export type BootstrapCandidate = ReturnType<typeof buildCandidate>;
/** Rebuild from issued study state so unknown fields or modified bindings cannot pass. */
export function serializeCandidate(value: unknown, study: CompletedStudy, proposedMetadata: CandidateMetadata) {
  const expected = buildCandidate(study, proposedMetadata);
  if (digest(value) !== digest(expected)) throw new Error('candidate mismatch: identity, target, hashes, points or authority fields');
  const manifest = canonicalForwardJsonBytes(expected.manifest), rows = canonicalForwardJsonlBytes(expected.rows);
  const rule = canonicalForwardJsonBytes(expected.rule), reports = canonicalForwardJsonBytes(expected.reports);
  return { manifest_bytes: manifest, rows_bytes: rows, rule_bytes: rule, reports_bytes: reports,
    hashes: freeze({ manifest: forwardArtifactSha256(manifest), rows: forwardArtifactSha256(rows), rule: forwardArtifactSha256(rule), reports: forwardArtifactSha256(reports) }) };
}
