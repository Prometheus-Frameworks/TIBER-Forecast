/** Offline Year 1 arithmetic. No I/O, live weights or availability model. */
export const POSITIONS = ['QB', 'RB', 'WR', 'TE'] as const;
export type Position = typeof POSITIONS[number];
export const NUMERIC_VERSION = 'year1-rational-cents-half-up-v0' as const;
export const PRIOR_BASIS = 'prior_production_rate_anchor' as const;
export const COMPONENT_WEIGHTS = Object.freeze({
  receptions: 100, receiving_yards: 10, receiving_tds: 600,
  rushing_yards: 10, rushing_tds: 600, passing_yards: 4,
  passing_tds: 400, interceptions: -200,
});
export type Components = { [K in keyof typeof COMPONENT_WEIGHTS]: number | null };
type Rational = { n: bigint; d: bigint };
const gcd = (a: bigint, b: bigint): bigint => {
  a = a < 0n ? -a : a;
  while (b !== 0n) { const t = a % b; a = b; b = t; }
  return a;
};
const rational = (n: bigint, d = 1n): Rational => {
  if (d === 0n) throw new Error('zero denominator');
  if (d < 0n) { n = -n; d = -d; }
  const g = gcd(n, d);
  return { n: n / g, d: d / g };
};
const add = (a: Rational, b: Rational) => rational(a.n * b.d + b.n * a.d, a.d * b.d);
const sub = (a: Rational, b: Rational) => rational(a.n * b.d - b.n * a.d, a.d * b.d);
const mul = (a: Rational, b: Rational) => rational(a.n * b.n, a.d * b.d);
const div = (a: Rational, b: Rational) => rational(a.n * b.d, a.d * b.n);
const number = (a: Rational): number => {
  // Use quotient/remainder to avoid Infinity / Infinity for large exact sums.
  const sign = a.n < 0n ? -1 : 1;
  const n = a.n < 0n ? -a.n : a.n;
  const scale = 10n ** 18n;
  const value = sign * (Number(n / a.d) + Number((n % a.d) * scale / a.d) / 1e18);
  if (!Number.isFinite(value)) throw new Error('nonfinite arithmetic');
  return value === 0 ? 0 : value;
};
const halfUpInteger = (r: Rational): bigint => {
  const negative = r.n < 0n;
  const n = negative ? -r.n : r.n;
  const magnitude = n / r.d + ((n % r.d) * 2n >= r.d ? 1n : 0n);
  return negative ? -magnitude : magnitude;
};
const emittedPoints = (cents: Rational) => Number(halfUpInteger(cents)) / 100;
export const assertSafeInteger = (v: unknown, where: string): number => {
  if (typeof v !== 'number' || !Number.isSafeInteger(v)) throw new Error(`${where}: unsafe/nonintegral value`);
  return v;
};

/** Null stays unavailable; malformed/unknown components are rejected. */
export function scoreComponents(value: unknown): number | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('components required');
  const row = value as Record<string, unknown>;
  const keys = Object.keys(COMPONENT_WEIGHTS) as (keyof Components)[];
  if (Object.keys(row).sort().join() !== [...keys].sort().join()) throw new Error('component fields');
  let unavailable = false;
  let cents = 0n;
  for (const key of keys) {
    if (row[key] === null) { unavailable = true; continue; }
    const v = assertSafeInteger(row[key], key);
    if (!key.endsWith('_yards') && v < 0) throw new Error('negative production count');
    cents += BigInt(v) * BigInt(COMPONENT_WEIGHTS[key]);
  }
  if (unavailable) return null;
  return assertSafeInteger(Number(cents), 'point cents');
}

export interface Features {
  prior_total_cents: number;
  prior_games: number;
  week1_cents: number;
}
const priorCents = (f: Features): Rational => {
  assertSafeInteger(f.prior_total_cents, 'prior cents');
  assertSafeInteger(f.prior_games, 'recorded games');
  assertSafeInteger(f.week1_cents, 'Week 1 cents');
  if (f.prior_games < 1) throw new Error('prior_unavailable');
  return rational(BigInt(f.prior_total_cents), BigInt(f.prior_games));
};
export function priorAnchor(totalCents: number, games: number): number {
  return number(div(priorCents({ prior_total_cents: totalCents, prior_games: games, week1_cents: 0 }), rational(100n)));
}
export interface TrainingObservation extends Features {
  season: 2022 | 2023;
  player_id: string;
  position: Position;
  outcome_cents: number;
}
export interface FittedAlpha {
  readonly alpha: number;
  readonly numerator: string;
  readonly denominator: string;
  readonly identifiable: boolean;
  readonly status: 'fitted' | 'update_not_identifiable';
  readonly numeric_version: typeof NUMERIC_VERSION;
  readonly training_members: readonly string[];
}
const fitted = new WeakSet<object>();
export function assertFittedAlpha(value: FittedAlpha): void {
  if (!value || !fitted.has(value)) throw new Error('unissued fitted rule; arbitrary weights forbidden');
}

/** Exact constrained WLS; position weights are fixed 1/n_p across both years. */
export function fitAlpha(rows: readonly TrainingObservation[]): FittedAlpha {
  const ordered = [...rows].sort((a, b) => a.season - b.season || (a.player_id < b.player_id ? -1 : a.player_id > b.player_id ? 1 : 0));
  const ids = ordered.map(r => `${r.season}:${r.player_id}`);
  if (new Set(ids).size !== ids.length || rows.length === 0) throw new Error('duplicate/empty training membership');
  const counts = Object.fromEntries(POSITIONS.map(p => [p, rows.filter(r => r.position === p).length])) as Record<Position, number>;
  if (POSITIONS.some(p => counts[p] === 0) || !rows.some(r => r.season === 2022) || !rows.some(r => r.season === 2023)) throw new Error('training seasons/positions incomplete');
  let n = rational(0n), d = rational(0n);
  for (const r of ordered) {
    if ((r.season !== 2022 && r.season !== 2023) || !POSITIONS.includes(r.position) || !r.player_id) throw new Error('training scope');
    const p = priorCents(r);
    const delta = sub(rational(BigInt(r.week1_cents)), p);
    const y = rational(BigInt(assertSafeInteger(r.outcome_cents, 'outcome')));
    const weight = rational(1n, BigInt(counts[r.position]));
    n = add(n, mul(weight, mul(delta, sub(y, p))));
    d = add(d, mul(weight, mul(delta, delta)));
  }
  const identifiable = d.n !== 0n;
  let alpha = identifiable ? div(n, d) : rational(0n);
  if (alpha.n < 0n) alpha = rational(0n);
  if (alpha.n > alpha.d) alpha = rational(1n);
  const result: FittedAlpha = Object.freeze({ alpha: number(alpha), numerator: alpha.n.toString(), denominator: alpha.d.toString(), identifiable,
    status: identifiable ? 'fitted' : 'update_not_identifiable', numeric_version: NUMERIC_VERSION,
    training_members: Object.freeze(ids) });
  fitted.add(result);
  return result;
}
export interface ChallengerPoints { C0: number; C1: number; C2: number }
export function calculateChallengers(f: Features, rule: FittedAlpha): { points: ChallengerPoints; emitted: ChallengerPoints } {
  assertFittedAlpha(rule);
  if (Object.keys(f).sort().join() !== ['prior_games', 'prior_total_cents', 'week1_cents'].join()) throw new Error('exact feature fields; labels/extra predictors forbidden');
  const p = priorCents(f), w = rational(BigInt(f.week1_cents));
  const alpha = rational(BigInt(rule.numerator), BigInt(rule.denominator));
  const c2 = add(p, mul(alpha, sub(w, p)));
  const points = { C0: number(div(p, rational(100n))), C1: f.week1_cents / 100, C2: number(div(c2, rational(100n))) };
  return { points, emitted: { C0: emittedPoints(p), C1: emittedPoints(w), C2: emittedPoints(c2) } };
}
/** Display arithmetic only; the caller must establish matching anchor/profile. */
export function movement(point: number | null, prior: number | null, sameBinding: boolean): number | null {
  if (!sameBinding || point === null || prior === null || !Number.isFinite(point) || !Number.isFinite(prior)) return null;
  const p = Math.round(point * 100), b = Math.round(prior * 100);
  if (!Number.isSafeInteger(p) || !Number.isSafeInteger(b)) return null;
  if (!Number.isSafeInteger(p - b)) return null;
  const value = (p - b) / 100;
  return value === 0 ? 0 : value;
}
