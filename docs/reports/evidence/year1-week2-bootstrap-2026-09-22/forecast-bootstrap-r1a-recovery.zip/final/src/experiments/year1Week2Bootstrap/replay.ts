/** In-memory historical stages. No provider, filesystem or live run entry point. */
import { summarizeSeasonalErrors, summarizeSeasonalErrorsByPosition } from '../../datasets/seasonal/evaluateSeasonalPpr.js';
import { compareForwardCanonicalStrings as cmp } from '../../serialization/canonicalForwardArtifacts.js';
import { assertValidatedWorld, validateLabels, featuresFor, digest, freeze, exact,
  type ValidatedWorld, type BootstrapRow, type LabelRequest, type TrustedEvidence, type ValidatedLabels } from './input.js';
import { POSITIONS, fitAlpha, calculateChallengers, type Position, type FittedAlpha, type ChallengerPoints, type TrainingObservation } from './shrinkage.js';

type Arm = keyof ChallengerPoints;
const ARMS: readonly Arm[] = ['C0', 'C1', 'C2'];
export interface Metrics { n: number; mae: number | null; rmse: number | null; spearman: number | null; reason: string | null }
export interface MetricSet { pooled: Metrics; positions: Record<Position, Metrics>; macro_mae: number | null; macro_rmse: number | null }
export interface Coverage { numerator: number; denominator: number; rate: number | null }
export interface ReplayReport {
  season: number; world_hash: string; label_source_hash: string; label_binding: ValidatedLabels['binding']; label_admission: ValidatedLabels['admission'];
  primary_ids: readonly string[]; evaluated_ids: readonly string[];
  sufficient: boolean; sufficiency: Record<Position, { primary: number; resolved: number; passes: boolean }>;
  arms: Record<Arm, MetricSet>;
  coverage: Record<Arm, { full_population: Coverage; eligible_supported: Coverage; diagnostic_extra_ids: string[] }>;
  unavailable_counts: Record<string, number>; unresolved_label_ids: string[];
  paired_differences: Record<'C2_minus_C0' | 'C1_minus_C0', { mae: number | null; rmse: number | null }>;
  cohorts: Record<string, { population_count: number; evaluated_count: number; arms: Record<Arm, Metrics> }>;
  games: Record<string, { count: number; C2_minus_C0_mae: number; C1_minus_C0_mae: number }>;
  game_count: number; paired_errors: { row_id: string; position: string; game_id: string; errors: ChallengerPoints }[];
  top_absolute_misses: Record<Arm, { row_id: string; absolute_error: number }[]>;
  evidence_class: ValidatedWorld['evidence_class']; limitations: readonly string[];
}
export interface PreparedPredictions {
  readonly world: ValidatedWorld; readonly points: Readonly<Record<string, ChallengerPoints>>;
  readonly emitted: Readonly<Record<string, ChallengerPoints>>; readonly hash: string;
}
export function preparePredictions(world: ValidatedWorld, rule: FittedAlpha): PreparedPredictions {
  assertValidatedWorld(world);
  if (world.purpose !== 'historical_method_selection' || world.season === 2026) throw new Error('offline historical predictions only');
  const points: Record<string, ChallengerPoints> = Object.create(null), emitted: Record<string, ChallengerPoints> = Object.create(null);
  for (const row of world.rows.filter(r => r.primary)) {
    const prediction = calculateChallengers(featuresFor(row), rule);
    points[row.row_id] = prediction.points; emitted[row.row_id] = prediction.emitted;
  }
  return freeze({ world, points, emitted, hash: digest({ world_hash: world.hash, points, emitted }) });
}
function metrics(rows: BootstrapRow[], point: (r: BootstrapRow) => number, labels: ValidatedLabels): Metrics {
  if (!rows.length) return { n: 0, mae: null, rmse: null, spearman: null, reason: 'empty_cohort' };
  const pairs = rows.map(r => ({ position: r.position as Position, predicted: point(r), actual: labels.outcomes[r.row_id]! / 100 }));
  if (pairs.some(p => !Number.isFinite(p.predicted) || !Number.isFinite(p.actual))) throw new Error('nonfinite metric input');
  const m = summarizeSeasonalErrors(pairs);
  return { n: m.sample_size, mae: m.mae, rmse: m.rmse, spearman: m.rank_correlation, reason: m.rank_correlation === null ? 'rank_constant_or_insufficient' : null };
}
function metricSet(rows: BootstrapRow[], arm: Arm, prepared: PreparedPredictions, labels: ValidatedLabels): MetricSet {
  // Exercise the existing position grouping on validated pairs; empty groups remain explicit nulls.
  const pairs = rows.map(r => ({ position: r.position as Position, predicted: prepared.points[r.row_id][arm], actual: labels.outcomes[r.row_id]! / 100 }));
  const grouped = summarizeSeasonalErrorsByPosition(pairs);
  const positions = Object.fromEntries(POSITIONS.map(p => {
    const subset = rows.filter(r => r.position === p), m = metrics(subset, r => prepared.points[r.row_id][arm], labels);
    if (grouped[p] && grouped[p]!.sample_size !== m.n) throw new Error('position denominator disagreement');
    return [p, m];
  })) as Record<Position, Metrics>;
  const complete = POSITIONS.every(p => positions[p].n > 0);
  return { pooled: metrics(rows, r => prepared.points[r.row_id][arm], labels), positions,
    macro_mae: complete ? POSITIONS.reduce((s, p) => s + positions[p].mae!, 0) / 4 : null,
    macro_rmse: complete ? POSITIONS.reduce((s, p) => s + positions[p].rmse!, 0) / 4 : null };
}
function sufficiency(world: ValidatedWorld, labels: ValidatedLabels): ReplayReport['sufficiency'] {
  return Object.fromEntries(POSITIONS.map(p => {
    const rows = world.rows.filter(r => r.primary && r.position === p);
    const resolved = rows.filter(r => labels.outcomes[r.row_id] !== null).length;
    return [p, { primary: rows.length, resolved, passes: resolved >= 20 && resolved * 100 >= rows.length * 95 }];
  })) as ReplayReport['sufficiency'];
}
const ratio = (n: number, d: number): Coverage => ({ numerator: n, denominator: d, rate: d === 0 ? null : n / d });
function report(prepared: PreparedPredictions, labels: ValidatedLabels): ReplayReport {
  const world = prepared.world;
  if (labels.world_hash !== world.hash) throw new Error('wrong label world');
  const members = world.rows.filter(r => r.primary && labels.outcomes[r.row_id] !== null);
  const gates = sufficiency(world, labels);
  const arms = Object.fromEntries(ARMS.map(a => [a, metricSet(members, a, prepared, labels)])) as Record<Arm, MetricSet>;
  const coverage = Object.fromEntries(ARMS.map(a => {
    const available = world.rows.filter(r => r.eligible_supported && (a === 'C0' ? r.p !== null : a === 'C1' ? r.w !== null : r.primary));
    return [a, { full_population: ratio(available.length, world.rows.length), eligible_supported: ratio(available.length, world.rows.filter(r => r.eligible_supported).length),
      diagnostic_extra_ids: available.filter(r => !r.primary).map(r => r.row_id) }];
  })) as ReplayReport['coverage'];
  const predicates: Record<string, (r: BootstrapRow) => boolean> = {
    established_prior: r => r.prior_games !== null && r.prior_games >= 8,
    weak_prior: r => r.prior_games !== null && r.prior_games >= 1 && r.prior_games < 8,
    no_prior: r => r.prior_state === 'no_prior_production', prior_unavailable: r => r.prior_state !== 'available' && r.prior_state !== 'no_prior_production', changed_team: r => r.changed_team === true,
    changed_team_unknown: r => r.changed_team === null, played_zero: r => r.week1_state === 'played_zero',
    did_not_play: r => r.week1_state === 'did_not_play', participation_unknown: r => r.week1_state === 'unresolved' || r.week1_state === 'unavailable',
  };
  const cohorts = Object.fromEntries(Object.entries(predicates).map(([name, predicate]) => {
    const subset = members.filter(predicate);
    return [name, { population_count: world.rows.filter(predicate).length, evaluated_count: subset.length,
      arms: Object.fromEntries(ARMS.map(a => [a, metrics(subset, r => prepared.points[r.row_id][a], labels)])) as Record<Arm, Metrics> }];
  }));
  const unavailable_counts: Record<string, number> = Object.create(null);
  for (const r of world.rows) for (const reason of r.reasons) unavailable_counts[reason] = (unavailable_counts[reason] ?? 0) + 1;
  const difference = (a: Arm) => ({ mae: arms[a].pooled.mae === null ? null : arms[a].pooled.mae! - arms.C0.pooled.mae!, rmse: arms[a].pooled.rmse === null ? null : arms[a].pooled.rmse! - arms.C0.pooled.rmse! });
  const games: ReplayReport['games'] = Object.create(null);
  for (const id of [...new Set(members.map(r => r.target_game_id!))].sort(cmp)) {
    const subset = members.filter(r => r.target_game_id === id);
    const mae = (a: Arm) => metrics(subset, r => prepared.points[r.row_id][a], labels).mae!;
    games[id] = { count: subset.length, C2_minus_C0_mae: mae('C2') - mae('C0'), C1_minus_C0_mae: mae('C1') - mae('C0') };
  }
  return freeze({ season: world.season, world_hash: world.hash, label_source_hash: labels.source_hash, label_binding: labels.binding, label_admission: labels.admission,
    primary_ids: world.primary_ids, evaluated_ids: members.map(r => r.row_id), sufficient: POSITIONS.every(p => gates[p].passes), sufficiency: gates, arms, coverage,
    unavailable_counts, unresolved_label_ids: world.rows.filter(r => labels.outcomes[r.row_id] === null).map(r => r.row_id),
    paired_differences: { C2_minus_C0: difference('C2'), C1_minus_C0: difference('C1') }, cohorts, games, game_count: Object.keys(games).length,
    paired_errors: members.map(r => ({ row_id: r.row_id, position: r.position!, game_id: r.target_game_id!, errors: Object.fromEntries(ARMS.map(a => [a, prepared.points[r.row_id][a] - labels.outcomes[r.row_id]! / 100])) as unknown as ChallengerPoints })),
    top_absolute_misses: Object.fromEntries(ARMS.map(a => [a, members.map(r => ({ row_id: r.row_id, absolute_error: Math.abs(prepared.points[r.row_id][a] - labels.outcomes[r.row_id]! / 100) })).sort((a, b) => b.absolute_error - a.absolute_error || cmp(a.row_id, b.row_id)).slice(0, 10)])) as ReplayReport['top_absolute_misses'],
    evidence_class: world.evidence_class, limitations: world.limitations });
}
function c2Passes(r: ReplayReport): boolean {
  return r.sufficient && r.arms.C2.macro_mae! < r.arms.C0.macro_mae! && r.arms.C2.macro_rmse! <= r.arms.C0.macro_rmse! && POSITIONS.every(p => r.arms.C2.positions[p].mae! <= r.arms.C0.positions[p].mae!);
}
export type LabelLoader = () => { request: LabelRequest; trusted: TrustedEvidence };
export interface ReplayIdentity { readonly run_id: string; readonly code_sha256: string; readonly configuration_sha256: string; readonly specification_sha256: string }
const SPEC = '7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844';
function runIdentity(value: ReplayIdentity): ReplayIdentity {
  const r = exact(value, ['run_id', 'code_sha256', 'configuration_sha256', 'specification_sha256'], 'replay identity');
  if (typeof r.run_id !== 'string' || !r.run_id.trim() || r.run_id.trim() !== r.run_id ||
      typeof r.code_sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(r.code_sha256) ||
      typeof r.configuration_sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(r.configuration_sha256) || r.specification_sha256 !== SPEC) throw new Error('replay code/config/spec identity');
  return freeze({ run_id: r.run_id, code_sha256: r.code_sha256, configuration_sha256: r.configuration_sha256, specification_sha256: SPEC });
}
export interface ValidationSeal { readonly identity: ReplayIdentity; readonly rule_hash: string; readonly report_hash: string; readonly prediction_hash: string; readonly hash: string }
export interface CompletedStudy {
  readonly identity: ReplayIdentity; readonly feature_worlds: readonly ValidatedWorld[];
  readonly result: 'c2_update_supported' | 'c0_prior_only_retained' | 'bootstrap_study_inconclusive';
  readonly selected: 'C0' | 'C2' | null; readonly rule: FittedAlpha;
  readonly training_world_hashes: readonly string[]; readonly training_label_hashes: readonly string[];
  readonly validation: ReplayReport; readonly final: ReplayReport; readonly seal: ValidationSeal;
  readonly training_reports: readonly ReplayReport[]; readonly prepared_final: PreparedPredictions;
  readonly access_log: readonly string[]; readonly evidence_class: ValidatedWorld['evidence_class'];
  readonly limitations: readonly string[]; readonly hash: string;
}
const completed = new WeakSet<object>();
export function assertCompletedStudy(value: CompletedStudy): void { if (!value || !completed.has(value)) throw new Error('unissued study/selection'); }

/** Closure state and issued seal identity enforce stage order at runtime. */
export function createReplay(proposedIdentity: ReplayIdentity) {
  const identity = runIdentity(proposedIdentity);
  const featureWorlds: ValidatedWorld[] = [];
  let stage = 'empty';
  let rule: FittedAlpha;
  let training: ValidatedWorld[] = [], trainingLabels: ValidatedLabels[] = [], trainingReports: ReplayReport[] = [];
  let prepared: PreparedPredictions, validation: ReplayReport, seal: ValidationSeal;
  const access: string[] = [];
  const check = (expected: string) => { if (stage !== expected) throw new Error(`stage ${stage}; expected ${expected}`); };
  const worldAt = (w: ValidatedWorld, season: number) => { assertValidatedWorld(w); if (w.season !== season || w.purpose !== 'historical_method_selection') throw new Error('stage season/purpose'); };
  const load = (w: ValidatedWorld, loader: LabelLoader): ValidatedLabels => {
    access.push(`labels:${w.season}`);
    const value = loader(); return validateLabels(value.request, w, value.trusted);
  };
  return Object.freeze({
    train(worlds: readonly [ValidatedWorld, ValidatedWorld], loaders: readonly [LabelLoader, LabelLoader]): FittedAlpha {
      check('empty');
      if (worlds.length !== 2 || loaders.length !== 2) throw new Error('exact training stages required');
      worldAt(worlds[0], 2022); worldAt(worlds[1], 2023);
      stage = 'training_opened'; // A failed/throwing load cannot be retried to cherry-pick labels.
      training = [...worlds]; featureWorlds.push(...training); trainingLabels = training.map((w, i) => load(w, loaders[i]));
      if (training.some((w, i) => POSITIONS.some(p => !sufficiency(w, trainingLabels[i])[p].passes))) { stage = 'inconclusive'; throw new Error('bootstrap_study_inconclusive: training sufficiency'); }
      const observations: TrainingObservation[] = training.flatMap((w, i) => w.rows.filter(r => r.primary && trainingLabels[i].outcomes[r.row_id] !== null).map(r => ({
        ...featuresFor(r), season: w.season as 2022 | 2023, player_id: r.gsis!, position: r.position as Position, outcome_cents: trainingLabels[i].outcomes[r.row_id]!,
      })));
      rule = fitAlpha(observations);
      trainingReports = training.map((w, i) => report(preparePredictions(w, rule), trainingLabels[i]));
      access.push(`rule_frozen:${digest(rule)}`); stage = 'trained'; return rule;
    },
    prepareValidation(world: ValidatedWorld): string {
      check('trained'); worldAt(world, 2024); featureWorlds.push(world); prepared = preparePredictions(world, rule);
      access.push(`predictions_frozen:2024:${prepared.hash}`); stage = 'validation_prepared'; return prepared.hash;
    },
    evaluateValidation(loader: LabelLoader): ReplayReport {
      check('validation_prepared'); stage = 'validation_opened'; validation = report(prepared, load(prepared.world, loader));
      stage = 'validation_evaluated'; return validation;
    },
    sealValidation(): ValidationSeal {
      check('validation_evaluated');
      const core = { identity, rule_hash: digest(rule), report_hash: digest(validation), prediction_hash: prepared.hash };
      seal = freeze({ ...core, hash: digest(core) }); access.push(`validation_sealed:${seal.hash}`); stage = 'validation_sealed'; return seal;
    },
    prepareFinal(world: ValidatedWorld, suppliedSeal: ValidationSeal): string {
      check('validation_sealed');
      if (suppliedSeal !== seal || suppliedSeal.rule_hash !== digest(rule) || suppliedSeal.report_hash !== digest(validation)) throw new Error('unissued/altered seal');
      worldAt(world, 2025); featureWorlds.push(world); prepared = preparePredictions(world, rule);
      access.push(`predictions_frozen:2025:${prepared.hash}`); stage = 'final_prepared'; return prepared.hash;
    },
    evaluateFinal(loader: LabelLoader): CompletedStudy {
      check('final_prepared'); stage = 'final_opened'; const final = report(prepared, load(prepared.world, loader));
      const sufficient = validation.sufficient && final.sufficient;
      const selected = !sufficient ? null : rule.identifiable && rule.alpha > 0 && c2Passes(validation) && c2Passes(final) ? 'C2' as const : 'C0' as const;
      const inputs = [...training, prepared.world];
      const core = { identity, feature_worlds: [...featureWorlds], result: selected === 'C2' ? 'c2_update_supported' as const : selected === 'C0' ? 'c0_prior_only_retained' as const : 'bootstrap_study_inconclusive' as const,
        selected, rule, training_world_hashes: training.map(w => w.hash), training_label_hashes: trainingLabels.map(l => l.source_hash),
        training_reports: trainingReports, validation, final, seal, prepared_final: prepared, access_log: [...access],
        evidence_class: inputs.some(w => w.evidence_class !== 'verified_asof') || validation.evidence_class !== 'verified_asof' ? 'retrospective_reconstruction_for_method_selection' as const : 'verified_asof' as const,
        limitations: [...new Set([...inputs.flatMap(w => w.limitations), ...validation.limitations])].sort(cmp) };
      const result: CompletedStudy = freeze({ ...core, hash: digest(core) }); completed.add(result); stage = 'done'; return result;
    },
    state(): string { return stage; },
  });
}
