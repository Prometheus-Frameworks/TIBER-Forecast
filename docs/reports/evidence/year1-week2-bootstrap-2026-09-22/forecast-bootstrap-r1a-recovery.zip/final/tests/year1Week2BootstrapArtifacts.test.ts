import { describe, it, expect } from 'vitest';
// SYNTHETIC FIXTURE START
import { TIBER_GENERIC_FULL_PPR_V1_PROFILE_REF as PROFILE } from '../src/contracts/genericFullPprProfile.js';
import { canonicalForwardJsonBytes, forwardArtifactSha256 } from '../src/serialization/canonicalForwardArtifacts.js';
import { validateInputs, type InputRequest, type SourceKind, type SourceBinding, type TrustedEvidence, type LabelRequest } from '../src/experiments/year1Week2Bootstrap/input.js';
const HASH = 'a'.repeat(64);
const RUN = { run_id: 'synthetic-only-run', code_sha256: HASH, configuration_sha256: HASH, specification_sha256: '7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844' };
const components = (points: number) => ({ receptions: points, receiving_yards: 0, receiving_tds: 0, rushing_yards: 0, rushing_tds: 0, passing_yards: 0, passing_tds: 0, interceptions: 0 });
/** Entirely invented games, people, source bytes, receipts and labels. No I/O. */
function synthetic(season = 2022, n = 20, outcome = 15) {
  const cutoff = season + '-09-14T12:00:00.000Z';
  const purpose = season === 2026 ? 'live_2026_forecast_inputs' as const : 'historical_method_selection' as const;
  const populations = ['QB', 'RB', 'WR', 'TE'].flatMap(position => Array.from({ length: n }, (_, i) => ({
    row_id: position + ':' + i, gsis: 'synthetic:' + position + ':' + i, position, team: 'SYN_A', identity_status: 'resolved', roster_status: 'active', position_resolution_ref: null,
  })));
  const prior = populations.map(p => ({ gsis: p.gsis, season: season - 1, position: p.position, team: 'SYN_A', coverage: 'complete',
    games: [{ game_id: 'SYN_PRIOR', season: season - 1, season_type: 'REG', completed_at: (season - 1) + '-09-10T12:00:00.000Z', components: components(10) }] }));
  const weekly = populations.map(p => ({ population_row_id: p.row_id, gsis: p.gsis, season, week: 1, game_id: 'SYN_W1', state: 'played', zero_evidence_ref: null, components: components(20) }));
  const schedule = [
    { game_id: 'SYN_W1', week: 1, home: 'SYN_A', away: 'SYN_B', completed_at: season + '-09-11T12:00:00.000Z', kickoff: season + '-09-11T09:00:00.000Z' },
    { game_id: 'SYN_W2', week: 2, home: 'SYN_A', away: 'SYN_B', completed_at: null, kickoff: season + '-09-17T09:00:00.000Z' },
  ];
  const outcomes = populations.map(p => ({ row_id: p.row_id, gsis: p.gsis, season, week: 2, game_id: 'SYN_W2', state: 'played', zero_evidence_ref: null, components: components(outcome) }));
  const providerId = (row: any) => row.gsis === null ? null : 'provider:' + row.gsis;
  const rawHash = (kind: SourceKind) => forwardArtifactSha256(canonicalForwardJsonBytes({ synthetic_raw: kind, season }));
  function decorate(kind: SourceKind, rows: any[]) {
    const identity = (row: any) => ({ status: row.gsis === null ? (row.identity_status === 'unavailable' ? 'unavailable' : 'unresolved') : 'resolved',
      source_ref: row.gsis === null ? null : 'source', provider_player_id: providerId(row), mapping_ref: row.gsis === null ? null : row.gsis });
    const cells = (row: any, values: any, rowKey: string) => Object.fromEntries(Object.keys(components(0)).map(field => {
      const value = values === null ? null : values[field];
      return [field, { value, state: value === null ? 'source_null' : value === 0 ? 'explicit_zero' : 'observed', units: field.endsWith('_yards') ? 'yards' : 'count',
        locator: row.gsis === null ? null : { source_ref: 'source', artifact_sha256: rawHash(kind), row: rowKey, field, provider_player_id: providerId(row) } }];
    }));
    const ev = (row: any, vals: any, rowKey: string, description = false) => ({ identity: identity(row), components: vals === undefined ? null : cells(row, vals, rowKey),
      descriptive: description ? Object.fromEntries(['targets', 'carries'].map(field => [field, { value: 3, state: 'observed', units: 'count',
        locator: { source_ref: 'source', artifact_sha256: rawHash(kind), row: rowKey, field, provider_player_id: providerId(row) } }])) : null });
    for (const row of rows) {
      if (kind === 'population') row.evidence = ev(row, undefined, row.row_id);
      if (kind === 'prior') { row.evidence = ev(row, undefined, row.gsis); for (const g of row.games) g.evidence = ev(row, g.components, row.gsis + ':' + g.game_id); }
      if (kind === 'week1') row.evidence = ev(row, row.components, row.population_row_id + ':' + row.game_id, true);
      if (kind === 'labels') row.evidence = ev(row, row.components, row.row_id);
    }
  }
  function registry(kind: SourceKind, rows: any[]) {
    const records: any[] = [];
    for (const row of rows) {
      if (kind === 'population' || kind === 'labels') records.push({ key: JSON.stringify([row.row_id]), evidence: row.evidence });
      if (kind === 'prior') { records.push({ key: JSON.stringify([row.gsis]), evidence: row.evidence }); for (const g of row.games) records.push({ key: JSON.stringify([row.gsis, g.game_id]), evidence: g.evidence }); }
      if (kind === 'week1') records.push({ key: JSON.stringify([row.population_row_id, row.game_id]), evidence: row.evidence });
    }
    return { sources: kind === 'schedule' ? [] : [{ id: 'source', kind, season: kind === 'prior' ? season - 1 : season, sha256: rawHash(kind), locator: 'synthetic:raw-' + kind, provider: 'synthetic-test', receipt_sha256: HASH }],
      mappings: kind === 'schedule' ? [] : rows.filter(row => row.gsis !== null).map(row => ({ id: row.gsis, source_ref: 'source', provider_player_id: providerId(row), canonical_gsis: row.gsis,
        version: 'synthetic-mapping-v1', sha256: HASH, receipt_sha256: HASH, status: 'resolved', confidence: 'provider_verified' })), rows: JSON.parse(JSON.stringify(records)) } as SourceBinding['evidence'];
  }
  function make(kind: SourceKind, rows: unknown[], keys: string[]) {
    decorate(kind, rows);
    const bytes = canonicalForwardJsonBytes({ kind, season: kind === 'prior' ? season - 1 : season, rows });
    const hash = forwardArtifactSha256(bytes);
    const binding: SourceBinding = { evidence: registry(kind, rows), kind, season, cutoff, purpose, sha256: hash, byte_count: bytes.length, source_sha256: hash,
      source_version: 'synthetic-v0', source_locator: 'synthetic:no-real-source', provider: 'synthetic-test', license_ref: 'synthetic-only',
      owner_commit: 'b'.repeat(40), contract_version: 'year1-bootstrap-internal-v0', reader_version: 'synthetic-v0', transform_version: 'synthetic-v0',
      evidence_class: 'verified_asof', publication_at: null, retrieved_at: cutoff, effective_at: season + '-09-11T12:00:00.000Z',
      generated_at: cutoff, admitted_at: season + '-09-14T13:00:00.000Z', witness_ids: [kind], record_keys: keys, complete: true,
      prior_membership: kind === 'prior' ? prior.map(p => ({ gsis: p.gsis, season: season - 1, season_type: 'REG' as const, complete: true,
        receipt_sha256: HASH, games: p.games.map(g => ({ game_id: g.game_id, season: g.season, season_type: 'REG' as const, completed_at: g.completed_at })) })) : null,
      decision_ref: 'synthetic-operator', review_ref: 'synthetic-independent-review', receipt_sha256: HASH, limitations: [], reconstruction_checks: null, derivation: null };
    if (kind === 'labels') {
      binding.effective_at = season + '-09-18T12:00:00.000Z'; binding.generated_at = season + '-09-19T12:00:00.000Z'; binding.admitted_at = season + '-09-19T13:00:00.000Z';
    }
    return { source: { kind, bytes }, binding, witness: { id: kind, kind: 'retrieval' as const, at: cutoff, source_sha256: hash, source_version: 'synthetic-v0', receipt_sha256: HASH } };
  }
  const parts = [make('prior', prior, prior.map(p => p.gsis)), make('week1', weekly, weekly.map(p => p.population_row_id + ':' + p.game_id)),
    make('population', populations, populations.map(p => p.row_id)), make('schedule', schedule, schedule.map(p => p.week + ':' + p.game_id))];
  const hashes = parts.map(p => p.binding.sha256).sort();
  const reconciliation = { status: 'passed' as const, validator_id: 'synthetic', validator_version: '0',
    evidence_ref: { repository: 'synthetic', path: 'no-file', artifact_version: '0', content_sha256: HASH }, scoring_profile_sha256: PROFILE.profile_sha256, source_input_sha256s: hashes };
  const admission = { id: 'synthetic-input-admission', scope: 'forecast.bootstrap.inputs' as const, purpose, season, cutoff,
    source_sha256s: hashes, decision_ref: 'synthetic-operator', review_ref: 'synthetic-review', admitted_at: season + '-09-14T13:00:00.000Z' };
  const request: InputRequest = { season, cutoff, purpose, profile: PROFILE, sources: parts.map(p => p.source), admission_id: admission.id, reconciliation };
  const trusted: TrustedEvidence = { bindings: parts.map(p => p.binding), witnesses: parts.map(p => p.witness), admissions: [admission], reconciliations: [reconciliation] };
  const lp = make('labels', outcomes, outcomes.map(p => p.row_id));
  const label: LabelRequest = { source: lp.source, admission_id: 'synthetic-label-admission' };
  const labelTrusted: TrustedEvidence = { bindings: [lp.binding], witnesses: [], reconciliations: [], admissions: [{ ...admission, id: label.admission_id, scope: 'forecast.bootstrap.labels', source_sha256s: [lp.binding.sha256], admitted_at: lp.binding.admitted_at }] };
  function replace(kind: SourceKind, change: (body: any) => void, resign = true, certifyEvidence = true) {
    const source = kind === 'labels' ? label.source : request.sources.find(s => s.kind === kind)!;
    const body = JSON.parse(new TextDecoder().decode(source.bytes)); change(body);
    if (certifyEvidence) decorate(kind, body.rows);
    const old = forwardArtifactSha256(source.bytes); source.bytes = canonicalForwardJsonBytes(body);
    if (!resign) return;
    const next = forwardArtifactSha256(source.bytes), context = kind === 'labels' ? labelTrusted : trusted;
    const b = context.bindings.find(b => b.sha256 === old)!; b.sha256 = next; b.source_sha256 = next; b.byte_count = source.bytes.length;
    if (certifyEvidence) b.evidence = registry(kind, body.rows);
    for (const w of context.witnesses) if (w.source_sha256 === old) w.source_sha256 = next;
    for (const a of context.admissions) a.source_sha256s = a.source_sha256s.map(h => h === old ? next : h).sort();
    if (kind !== 'labels') { request.reconciliation = { ...request.reconciliation, source_input_sha256s: request.sources.map(s => forwardArtifactSha256(s.bytes)).sort() }; trusted.reconciliations = [request.reconciliation]; }
  }
  function acceptEvidence(kind: SourceKind) {
    const source = kind === 'labels' ? label.source : request.sources.find(s => s.kind === kind)!;
    const body = JSON.parse(new TextDecoder().decode(source.bytes));
    const context = kind === 'labels' ? labelTrusted : trusted;
    context.bindings.find(b => b.kind === kind)!.evidence.rows = registry(kind, body.rows).rows;
  }
  function world() { const r = validateInputs(request, trusted); if (!r.ok) throw new Error(r.errors.map(e => e.message).join(';')); return r.data; }
  const loader = () => ({ request: label, trusted: labelTrusted });
  return { request, trusted, label, labelTrusted, replace, acceptEvidence, world, loader };
}
// SYNTHETIC FIXTURE END


import { createReplay } from '../src/experiments/year1Week2Bootstrap/replay.js';
import { buildCandidate, serializeCandidate, SPECIFICATION_SHA256, type CandidateMetadata } from '../src/experiments/year1Week2Bootstrap/artifacts.js';
const meta: CandidateMetadata = { run_id: 'synthetic-only-run', generated_at: '2026-01-01T00:00:00.000Z', code_sha256: HASH, configuration_sha256: HASH, specification_sha256: SPECIFICATION_SHA256 };
function study(yv = 15, yf = 15, reconstruction = false, identity = RUN) {
  const a = synthetic(2022), b = synthetic(2023), v = synthetic(2024), f = synthetic(2025, 21);
  for (const [fixture, y] of [[v, yv], [f, yf]] as const) fixture.replace('labels', body => { body.rows.forEach((row: any) => { row.components = components(y); }); });
  if (reconstruction) a.trusted.bindings.forEach(binding => {
    binding.evidence_class = 'retrospective_reconstruction_for_method_selection'; binding.witness_ids = [];
    binding.limitations = ['synthetic-reconstruction-original-clock-unknown'];
    binding.reconstruction_checks = { completed_game_facts: true, cutoff_context_supported: true, no_postcutoff_information: true, labels_excluded: true };
  });
  f.replace('prior', body => { body.rows[0].games = []; });
  f.trusted.bindings[0].prior_membership![0].games = [];
  const r = createReplay(identity); r.train([a.world(), b.world()], [a.loader, b.loader]);
  r.prepareValidation(v.world()); r.evaluateValidation(v.loader); const seal = r.sealValidation();
  r.prepareFinal(f.world(), seal); return r.evaluateFinal(f.loader);
}
describe('candidate-only artifact bytes', () => {
  it('retains anchor, W1 observation and C0 output as distinct fields with valid/null movement', () => {
    const s = study(10), candidate = buildCandidate(s, meta);
    const valid = candidate.rows.find(r => r.population_row_id === 'QB:1')!, missing = candidate.rows.find(r => r.population_row_id === 'QB:0')!;
    expect(valid.prior.basis).toBe('prior_production_rate_anchor'); expect(valid.prior.value).toBe(10);
    expect(valid.forecast.method).toBe('C0'); expect(valid.forecast.point).toBe(10);
    expect(valid.week_1_observed.value).toBe(20); expect(valid.week_1_observed.method_use).toBe('observed_no_predictive_weight_under_v0');
    expect(valid.movement.versus_prior).toBe(0); expect(missing.forecast.point).toBeNull(); expect(missing.movement.versus_prior).toBeNull();
    expect(candidate.rows).toHaveLength(84); expect(candidate.manifest.consumer_eligibility).toBe('not_eligible_pending_admission');
    expect(candidate.manifest.artifact_context).toBe('retrospective_method_study_candidate'); expect(candidate.manifest.target.season).toBe(2025);
  });
  it('serializes deterministic canonical bytes, distinct report/row channels and non-self-referential hashes', () => {
    const s = study(), c = buildCandidate(s, meta);
    const a = serializeCandidate(c, s, meta), b = serializeCandidate(c, s, { ...meta });
    expect(a.hashes).toEqual(b.hashes);
    expect(forwardArtifactSha256(a.rows_bytes)).toBe(c.manifest.rows_sha256);
    expect(forwardArtifactSha256(a.rule_bytes)).toBe(c.manifest.rule_sha256);
    expect(new TextDecoder().decode(a.manifest_bytes).endsWith('\n')).toBe(true);
    expect(Object.hasOwn(c.manifest, 'manifest_sha256')).toBe(false);
    const reversedKeys = Object.fromEntries(Object.entries(c).reverse());
    expect(serializeCandidate(reversedKeys, s, meta).hashes).toEqual(a.hashes);
    expect(c.rows.every(r => r.forecast.confidence === null && r.forecast.floor === null && r.forecast.probabilities === null)).toBe(true);
  });
  it.each(['week', 'player', 'point', 'profile', 'uncertainty', 'authority', 'digest', 'label', 'extra', 'row_count', 'nonfinite'])('rejects %s tampering', kind => {
    const s = study(), value = structuredClone(buildCandidate(s, meta)) as any;
    if (kind === 'week') value.manifest.target.week = 3;
    if (kind === 'player') value.rows[1].gsis = 'another';
    if (kind === 'point') value.rows[1].forecast.point = 999;
    if (kind === 'profile') value.manifest.scoring_profile.profile_sha256 = '0'.repeat(64);
    if (kind === 'uncertainty') value.rows[1].forecast.confidence = 0.9;
    if (kind === 'authority') value.manifest.production_ready = true;
    if (kind === 'digest') value.manifest.rows_sha256 = HASH;
    if (kind === 'label') value.rows[1].actual_week2 = 15;
    if (kind === 'extra') value.manifest.league_adjusted = true;
    if (kind === 'row_count') value.rows.pop();
    if (kind === 'nonfinite') value.rows[1].forecast.point = NaN;
    expect(() => serializeCandidate(value, s, meta)).toThrow();
  });
  it('preserves reconstruction lineage without upgrading final verified-asof inputs or admission', () => {
    const s = study(15, 15, true), c = buildCandidate(s, meta);
    expect(c.manifest.method_evidence.class).toBe('retrospective_reconstruction_for_method_selection');
    expect(c.manifest.source_bindings.every(b => b.evidence_class === 'verified_asof')).toBe(true);
    expect(c.manifest.input_admission.purpose).toBe('historical_method_selection');
    expect(c.manifest.method_evidence.limitations).toContain('synthetic-reconstruction-original-clock-unknown');
    expect(() => buildCandidate({ ...s } as typeof s, meta)).toThrow('unissued');
  });
  it('changes byte identity when the run identity changes and rejects invented specification pins/backdating', () => {
    const s = study(), a = buildCandidate(s, meta), changedMeta = { ...meta, run_id: 'synthetic-second-identity' }, other = study(15, 15, false, { ...RUN, run_id: changedMeta.run_id }), b = buildCandidate(other, changedMeta);
    expect(serializeCandidate(a, s, meta).hashes.manifest).not.toBe(serializeCandidate(b, other, changedMeta).hashes.manifest);
    expect(() => buildCandidate(s, { ...meta, generated_at: '2024-01-01T00:00:00.000Z' })).toThrow('predates');
    expect(() => buildCandidate(s, { ...meta, specification_sha256: HASH } as CandidateMetadata)).toThrow('pins');
  });
});


describe('repair regressions: frozen study identity and clocks', () => {
  it.each(['run_id', 'code_sha256', 'configuration_sha256'])('F3 rejects changed %s after study completion', field => {
    const s = study();
    expect(() => buildCandidate(s, { ...meta, [field]: field === 'run_id' ? 'another-run' : 'c'.repeat(64) })).toThrow();
  });
  it.each([2022, 2023, 2024])('F6 rejects candidate generation before %i feature generation', season => {
    const fixtures = [synthetic(2022), synthetic(2023), synthetic(2024), synthetic(2025)];
    const changed = fixtures[season - 2022];
    changed.trusted.bindings.forEach(b => {
      b.evidence_class = 'retrospective_reconstruction_for_method_selection'; b.witness_ids = [];
      b.reconstruction_checks = { completed_game_facts: true, cutoff_context_supported: true, no_postcutoff_information: true, labels_excluded: true };
      b.limitations = ['synthetic-later-processing']; b.generated_at = '2026-02-01T00:00:00.000Z'; b.admitted_at = b.generated_at;
    });
    const r = createReplay(RUN); r.train([fixtures[0].world(), fixtures[1].world()], [fixtures[0].loader, fixtures[1].loader]);
    r.prepareValidation(fixtures[2].world()); r.evaluateValidation(fixtures[2].loader); const seal = r.sealValidation();
    r.prepareFinal(fixtures[3].world(), seal); const s = r.evaluateFinal(fixtures[3].loader);
    expect(() => buildCandidate(s, meta)).toThrow('generation predates consumed evidence');
    expect(() => buildCandidate(s, { ...meta, generated_at: '2026-02-01T00:00:00.000Z' })).not.toThrow();
  });
});

it('R1 preserves prior-game evidence in candidate rows', () => { expect(buildCandidate(study(), meta).rows[1].prior).toHaveProperty('game_evidence'); });

function evidenceStudy(change?: (fixtures: ReturnType<typeof synthetic>[]) => void) {
  const fixtures = [synthetic(2022), synthetic(2023), synthetic(2024), synthetic(2025)]; change?.(fixtures);
  const r = createReplay(RUN); r.train([fixtures[0].world(), fixtures[1].world()], [fixtures[0].loader, fixtures[1].loader]);
  r.prepareValidation(fixtures[2].world()); r.evaluateValidation(fixtures[2].loader); const seal = r.sealValidation();
  r.prepareFinal(fixtures[3].world(), seal); return r.evaluateFinal(fixtures[3].loader);
}
describe('R1 candidate evidence and semantic permutation conformance', () => {
  it('retains complete evidence through bytes and retains observations for unavailable forecasts', () => {
    const s = study(), c = buildCandidate(s, meta), bytes = serializeCandidate(c, s, meta);
    const rows = new TextDecoder().decode(bytes.rows_bytes).trim().split('\n').map(line => JSON.parse(line));
    const noPrior = rows.find(r => r.population_row_id === 'QB:0'), available = rows.find(r => r.population_row_id === 'QB:1');
    expect(noPrior.forecast.point).toBeNull(); expect(noPrior.week_1_observed.evidence[0].evidence.descriptive.targets.value).toBe(3);
    expect(available.identity_evidence.mapping_record.sha256).toBe(HASH);
    expect(available.prior.game_evidence[0].evidence.components.receptions.value).toBe(10);
    expect(available.week_1_observed.evidence[0].evidence.components.receptions.locator.field).toBe('receptions');
    expect(JSON.stringify(rows)).not.toContain('SYN_W2\",\"evidence');
    expect(rows.every(r => !Object.hasOwn(r, 'outcomes'))).toBe(true);
  });
  it('valid descriptive changes alter evidence and candidate hashes but never features, alpha, predictions or selection', () => {
    const a = evidenceStudy(), b = evidenceStudy(fixtures => fixtures.forEach(f => {
      f.replace('week1', body => { for (const row of body.rows) { row.evidence.descriptive.targets.value = 9; row.evidence.descriptive.carries.value = 12; } }, true, false); f.acceptEvidence('week1');
    }));
    expect(b.rule).toEqual(a.rule); expect(b.selected).toBe(a.selected); expect(b.prepared_final.points).toEqual(a.prepared_final.points);
    const numeric = (s: typeof a) => s.feature_worlds.map(w => w.rows.map(r => [r.row_id, r.p, r.w, r.prior_games, r.prior_total_cents, r.week1_cents, r.primary]));
    expect(numeric(b)).toEqual(numeric(a));
    const ca = buildCandidate(a, meta), cb = buildCandidate(b, meta);
    expect(cb.rows[0].week_1_observed.evidence[0].evidence.descriptive!.targets.value).toBe(9);
    expect(serializeCandidate(cb, b, meta).hashes.manifest).not.toBe(serializeCandidate(ca, a, meta).hashes.manifest);
  }, 15000);
  it('orders semantic rows deterministically while retaining genuine source-byte/hash changes', () => {
    const a = evidenceStudy(), b = evidenceStudy(fixtures => fixtures.forEach(f => {
      for (const kind of ['prior', 'week1', 'population', 'schedule', 'labels'] as const) f.replace(kind, body => { body.rows.reverse(); if (kind === 'prior') body.rows.forEach((r: any) => r.games.reverse()); });
    }));
    expect(b.rule).toEqual(a.rule); expect(b.selected).toBe(a.selected); expect(b.prepared_final.points).toEqual(a.prepared_final.points);
    expect(b.prepared_final.world.rows).toEqual(a.prepared_final.world.rows);
    const ca = buildCandidate(a, meta), cb = buildCandidate(b, meta);
    expect(cb.rows.map(r => r.population_row_id)).toEqual(ca.rows.map(r => r.population_row_id));
    expect(cb.rows.map(({ source_refs, ...row }) => row)).toEqual(ca.rows.map(({ source_refs, ...row }) => row));
    expect(cb.manifest.source_sha256s).not.toEqual(ca.manifest.source_sha256s);
    expect(serializeCandidate(cb, b, meta).hashes.manifest).not.toBe(serializeCandidate(ca, a, meta).hashes.manifest);
  }, 15000);
  it('never moves label evidence into feature-world or candidate observation channels', () => {
    const s = evidenceStudy(), c = buildCandidate(s, meta);
    expect(s.feature_worlds.flatMap(w => w.bindings).every(b => b.kind !== 'labels')).toBe(true);
    expect(c.reports.final.label_binding.kind).toBe('labels');
    for (const row of c.rows) for (const observation of row.week_1_observed.evidence) {
      expect(observation.evidence.source_records.every(r => r.kind === 'week1')).toBe(true);
      expect(observation.evidence.components!.receptions.value).toBe(20);
    }
    expect(c.rows.every(r => r.forecast.point === 15)).toBe(true);
  });
});

it('R1 accepted mapping/component provenance changes survive serialization and change candidate identity', () => {
  const a = evidenceStudy(), b = evidenceStudy(fixtures => {
    const f = fixtures[3];
    f.trusted.bindings.find(binding => binding.kind === 'population')!.evidence.mappings[0].sha256 = 'c'.repeat(64);
    f.replace('week1', body => { body.rows[0].evidence.components.receptions.locator.field = 'provider_receptions_v2'; }, true, false);
    f.acceptEvidence('week1');
  });
  expect(b.prepared_final.points).toEqual(a.prepared_final.points);
  const ca = buildCandidate(a, meta), cb = buildCandidate(b, meta);
  const row = cb.rows.find(r => r.population_row_id === 'QB:0')!;
  expect(row.identity_evidence.mapping_record!.sha256).toBe('c'.repeat(64));
  expect(row.week_1_observed.evidence[0].evidence.components!.receptions.locator!.field).toBe('provider_receptions_v2');
  expect(serializeCandidate(cb, b, meta).hashes.rows).not.toBe(serializeCandidate(ca, a, meta).hashes.rows);
}, 15000);

// R1a: synthetic accepted evidence only; source location survives absent player identity.
function anonymousEvidence(f: ReturnType<typeof synthetic>, knownProvider = false) {
  for (const kind of ['population', 'week1', 'labels'] as const) {
    f.replace(kind, body => {
      const row = body.rows[0]; row.gsis = null;
      if (kind === 'population') row.identity_status = 'unresolved';
      row.evidence.identity = { status: 'unresolved', source_ref: 'source',
        provider_player_id: knownProvider ? 'provider:synthetic:QB:0' : null,
        mapping_ref: knownProvider ? 'synthetic:QB:0' : null };
      for (const cell of [...Object.values(row.evidence.components ?? {}), ...Object.values(row.evidence.descriptive ?? {})] as any[]) {
        if (cell.locator) cell.locator.provider_player_id = row.evidence.identity.provider_player_id;
      }
    }, true, false);
    const context = kind === 'labels' ? f.labelTrusted : f.trusted;
    const binding = context.bindings.find(b => b.kind === kind)!;
    if (knownProvider) {
      const mapping = binding.evidence.mappings.find(m => m.id === 'synthetic:QB:0')!;
      mapping.canonical_gsis = null; mapping.status = 'unresolved'; mapping.confidence = null;
    } else binding.evidence.mappings = binding.evidence.mappings.filter(m => m.id !== 'synthetic:QB:0');
    f.acceptEvidence(kind);
  }
}

it('R1a serializes anonymous observations without changing arithmetic or selection', () => {
  function run(known: boolean) {
    const fs = [2022, 2023, 2024, 2025].map(y => synthetic(y, 21));
    for (const f of fs) {
      anonymousEvidence(f, known);
      f.replace('week1', b => { const e = b.rows[0].evidence;
        e.descriptive.targets.value = null; e.descriptive.targets.state = 'source_null';
      }, true, false); f.acceptEvidence('week1');
    }
    const r = createReplay(RUN); r.train([fs[0].world(), fs[1].world()], [fs[0].loader, fs[1].loader]);
    r.prepareValidation(fs[2].world()); r.evaluateValidation(fs[2].loader); const seal = r.sealValidation();
    r.prepareFinal(fs[3].world(), seal); return r.evaluateFinal(fs[3].loader);
  }
  const known = run(true), anonymous = run(false);
  expect(anonymous.rule).toEqual(known.rule); expect(anonymous.selected).toBe(known.selected);
  expect(anonymous.prepared_final.points).toEqual(known.prepared_final.points);
  const numeric = (s: typeof known) => s.feature_worlds.map(w => w.rows.map(r => [r.row_id, r.p, r.w, r.prior_games, r.prior_total_cents, r.week1_cents, r.primary]));
  expect(numeric(anonymous)).toEqual(numeric(known));
  const a = buildCandidate(anonymous, meta), k = buildCandidate(known, meta);
  expect(a.rows.map(r => r.forecast.point)).toEqual(k.rows.map(r => r.forecast.point));
  const bytes = serializeCandidate(a, anonymous, meta);
  const rows = new TextDecoder().decode(bytes.rows_bytes).trim().split('\n').map(s => JSON.parse(s));
  const row = rows.find(r => r.population_row_id === 'QB:0'), e = row.week_1_observed.evidence[0].evidence;
  expect(row.gsis).toBeNull(); expect(row.forecast.point).toBeNull();
  expect(row.identity_evidence.mapping_record).toBeNull(); expect(e.mapping_record).toBeNull();
  expect(e.identity.provider_player_id).toBeNull(); expect(e.identity.mapping_ref).toBeNull();
  expect(e.components.receptions).toMatchObject({ value: 20, state: 'observed', units: 'count' });
  expect(e.components.receiving_yards).toMatchObject({ value: 0, state: 'explicit_zero', units: 'yards' });
  expect(e.descriptive.targets).toMatchObject({ value: null, state: 'source_null', units: 'count' });
  for (const c of [...Object.values(e.components), ...Object.values(e.descriptive)] as any[]) {
    expect(c.locator.provider_player_id).toBeNull(); expect(c.locator.source_ref).toBe('source');
    expect(c.locator.artifact_sha256).toBe(e.source_records[0].sha256);
    expect(c.locator.row).toBe('QB:0:SYN_W1'); expect(c.locator.field.length).toBeGreaterThan(0);
  }
  expect(bytes.hashes.rows).not.toBe(serializeCandidate(k, known, meta).hashes.rows);
}, 15000);
