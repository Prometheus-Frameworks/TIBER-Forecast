import { describe, it, expect } from 'vitest';
import { scoreComponents, priorAnchor, fitAlpha, calculateChallengers, movement, POSITIONS, type TrainingObservation, type FittedAlpha, type Features } from '../src/experiments/year1Week2Bootstrap/shrinkage.js';
const base = { prior_total_cents: 1000, prior_games: 1, week1_cents: 2000 };
function training(y = 1500): TrainingObservation[] {
  return ([2022, 2023] as const).flatMap(season => POSITIONS.map(position => ({ ...base, season, position, player_id: position, outcome_cents: y })));
}
describe('exact bootstrap arithmetic', () => {
  it('scores the eight components in cents, including negative points, without provider PPR', () => {
    const zero = { receptions: 0, receiving_yards: 0, receiving_tds: 0, rushing_yards: 0, rushing_tds: 0, passing_yards: 0, passing_tds: 0, interceptions: 0 };
    expect(scoreComponents({ ...zero, interceptions: 1 })).toBe(-200);
    expect(scoreComponents({ ...zero, receptions: 4, receiving_yards: 50, receiving_tds: 1, rushing_yards: 10, passing_yards: 25 })).toBe(1700);
    expect(scoreComponents({ ...zero, receptions: null })).toBeNull();
    expect(() => scoreComponents({ ...zero, receptions: 0.5 })).toThrow();
    expect(() => scoreComponents({ ...zero, fantasy_points_ppr: 999 })).toThrow();
    expect(priorAnchor(3000, 3)).toBe(10); expect(priorAnchor(3000, 4)).toBe(7.5);
    expect(() => priorAnchor(1000, 0)).toThrow('prior_unavailable');
  });
  it('learns one alpha and retains exact C0/C1/C2 meanings', () => {
    const rule = fitAlpha(training()); expect(rule.alpha).toBe(0.5); expect(rule.numerator).toBe('1'); expect(rule.denominator).toBe('2');
    expect(calculateChallengers(base, rule).points).toEqual({ C0: 10, C1: 20, C2: 15 });
    expect(movement(10, 10, true)).toBe(0); expect(movement(10, null, true)).toBeNull(); expect(movement(10, 10, false)).toBeNull();
  });
  it('equalizes position contributions despite unequal player counts', () => {
    const rows: TrainingObservation[] = Array.from({ length: 10 }, (_, i) => ({ ...base, season: 2022, position: 'QB', player_id: 'QB' + i, outcome_cents: 1000 }));
    for (const position of ['RB', 'WR', 'TE'] as const) rows.push({ ...base, season: 2023, position, player_id: position, outcome_cents: 2000 });
    expect(fitAlpha(rows).alpha).toBe(0.75);
  });
  it('clips at both endpoints and marks a zero update denominator unidentifiable', () => {
    expect(fitAlpha(training(0)).alpha).toBe(0); expect(fitAlpha(training(3000)).alpha).toBe(1);
    const rows = training().map(r => ({ ...r, week1_cents: 1000 })), rule = fitAlpha(rows);
    expect(rule.identifiable).toBe(false); expect(rule.status).toBe('update_not_identifiable');
    expect(calculateChallengers({ ...base, week1_cents: 1000 }, rule).points.C2).toBe(10);
  });
  it('rounds positive and negative half-cent ties away from zero and keeps full precision', () => {
    const rule = fitAlpha(training());
    for (const sign of [1, -1]) {
      const p = calculateChallengers({ prior_total_cents: sign * 201, prior_games: 2, week1_cents: 0 }, rule);
      expect(p.points.C0).toBeCloseTo(sign * 1.005, 10); expect(p.emitted.C0).toBe(sign * 1.01);
    }
    expect(calculateChallengers({ prior_total_cents: 100, prior_games: 3, week1_cents: 100 }, rule).points.C2).toBeCloseTo(2 / 3, 10);
  });
  it('rejects arbitrary weights, extra predictors, duplicate identities and nontraining seasons', () => {
    const rule = fitAlpha(training());
    expect(() => calculateChallengers(base, { ...rule, alpha: 0.7 } as FittedAlpha)).toThrow();
    expect(() => calculateChallengers({ ...base, targets: 20 } as Features, rule)).toThrow();
    expect(() => fitAlpha([...training(), training()[0]])).toThrow();
    expect(() => fitAlpha(training().map(r => ({ ...r, season: 2026 })) as unknown as TrainingObservation[])).toThrow();
    expect(() => fitAlpha(training().map(r => ({ ...r, outcome_cents: NaN })))).toThrow();
  });
});
