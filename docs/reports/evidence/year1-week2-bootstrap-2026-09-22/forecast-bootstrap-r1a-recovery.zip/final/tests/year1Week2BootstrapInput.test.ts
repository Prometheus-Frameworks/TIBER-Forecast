import { describe, it, expect } from 'vitest';
// SYNTHETIC FIXTURE START
import { TIBER_GENERIC_FULL_PPR_V1_PROFILE_REF as PROFILE } from '../src/contracts/genericFullPprProfile.js';
import { canonicalForwardJsonBytes, forwardArtifactSha256 } from '../src/serialization/canonicalForwardArtifacts.js';
import { validateInputs, type InputRequest, type SourceKind, type SourceBinding, type TrustedEvidence, type LabelRequest } from '../src/experiments/year1Week2Bootstrap/input.js';
const HASH = 'a'.repeat(64);
const RUN = { run_id: 'synthetic-only-run', code_sha256: HASH, configuration_sha256: HASH, specification_sha256: '7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844' };
const components = (points: number) => ({ receptions: points, receiving_yards: 0, receiving_tds: 0, rushing_yards: 0, rushing_tds: 0, passing_yards: 0, passing_tds: 0, interceptions: 0 });
/** Entirely invented games, people, source bytes, receipts and labels. No I/O. */
function synthetic(season = 2022, n = 20, outcome = 15) {
  const cutoff = season + '-09-14T12:00:00.000Z';
  const purpose = season === 2026 ? 'live_2026_forecast_inputs' as const : 'historical_method_selection' as const;
  const populations = ['QB', 'RB', 'WR', 'TE'].flatMap(position => Array.from({ length: n }, (_, i) => ({
    row_id: position + ':' + i, gsis: 'synthetic:' + position + ':' + i, position, team: 'SYN_A', identity_status: 'resolved', roster_status: 'active', position_resolution_ref: null,
  })));
  const prior = populations.map(p => ({ gsis: p.gsis, season: season - 1, position: p.position, team: 'SYN_A', coverage: 'complete',
    games: [{ game_id: 'SYN_PRIOR', season: season - 1, season_type: 'REG', completed_at: (season - 1) + '-09-10T12:00:00.000Z', components: components(10) }] }));
  const weekly = populations.map(p => ({ population_row_id: p.row_id, gsis: p.gsis, season, week: 1, game_id: 'SYN_W1', state: 'played', zero_evidence_ref: null, components: components(20) }));
  const schedule = [
    { game_id: 'SYN_W1', week: 1, home: 'SYN_A', away: 'SYN_B', completed_at: season + '-09-11T12:00:00.000Z', kickoff: season + '-09-11T09:00:00.000Z' },
    { game_id: 'SYN_W2', week: 2, home: 'SYN_A', away: 'SYN_B', completed_at: null, kickoff: season + '-09-17T09:00:00.000Z' },
  ];
  const outcomes = populations.map(p => ({ row_id: p.row_id, gsis: p.gsis, season, week: 2, game_id: 'SYN_W2', state: 'played', zero_evidence_ref: null, components: components(outcome) }));
  const providerId = (row: any) => row.gsis === null ? null : 'provider:' + row.gsis;
  const rawHash = (kind: SourceKind) => forwardArtifactSha256(canonicalForwardJsonBytes({ synthetic_raw: kind, season }));
  function decorate(kind: SourceKind, rows: any[]) {
    const identity = (row: any) => ({ status: row.gsis === null ? (row.identity_status === 'unavailable' ? 'unavailable' : 'unresolved') : 'resolved',
      source_ref: row.gsis === null ? null : 'source', provider_player_id: providerId(row), mapping_ref: row.gsis === null ? null : row.gsis });
    const cells = (row: any, values: any, rowKey: string) => Object.fromEntries(Object.keys(components(0)).map(field => {
      const value = values === null ? null : values[field];
      return [field, { value, state: value === null ? 'source_null' : value === 0 ? 'explicit_zero' : 'observed', units: field.endsWith('_yards') ? 'yards' : 'count',
        locator: row.gsis === null ? null : { source_ref: 'source', artifact_sha256: rawHash(kind), row: rowKey, field, provider_player_id: providerId(row) } }];
    }));
    const ev = (row: any, vals: any, rowKey: string, description = false) => ({ identity: identity(row), components: vals === undefined ? null : cells(row, vals, rowKey),
      descriptive: description ? Object.fromEntries(['targets', 'carries'].map(field => [field, { value: 3, state: 'observed', units: 'count',
        locator: { source_ref: 'source', artifact_sha256: rawHash(kind), row: rowKey, field, provider_player_id: providerId(row) } }])) : null });
    for (const row of rows) {
      if (kind === 'population') row.evidence = ev(row, undefined, row.row_id);
      if (kind === 'prior') { row.evidence = ev(row, undefined, row.gsis); for (const g of row.games) g.evidence = ev(row, g.components, row.gsis + ':' + g.game_id); }
      if (kind === 'week1') row.evidence = ev(row, row.components, row.population_row_id + ':' + row.game_id, true);
      if (kind === 'labels') row.evidence = ev(row, row.components, row.row_id);
    }
  }
  function registry(kind: SourceKind, rows: any[]) {
    const records: any[] = [];
    for (const row of rows) {
      if (kind === 'population' || kind === 'labels') records.push({ key: JSON.stringify([row.row_id]), evidence: row.evidence });
      if (kind === 'prior') { records.push({ key: JSON.stringify([row.gsis]), evidence: row.evidence }); for (const g of row.games) records.push({ key: JSON.stringify([row.gsis, g.game_id]), evidence: g.evidence }); }
      if (kind === 'week1') records.push({ key: JSON.stringify([row.population_row_id, row.game_id]), evidence: row.evidence });
    }
    return { sources: kind === 'schedule' ? [] : [{ id: 'source', kind, season: kind === 'prior' ? season - 1 : season, sha256: rawHash(kind), locator: 'synthetic:raw-' + kind, provider: 'synthetic-test', receipt_sha256: HASH }],
      mappings: kind === 'schedule' ? [] : rows.filter(row => row.gsis !== null).map(row => ({ id: row.gsis, source_ref: 'source', provider_player_id: providerId(row), canonical_gsis: row.gsis,
        version: 'synthetic-mapping-v1', sha256: HASH, receipt_sha256: HASH, status: 'resolved', confidence: 'provider_verified' })), rows: JSON.parse(JSON.stringify(records)) } as SourceBinding['evidence'];
  }
  function make(kind: SourceKind, rows: unknown[], keys: string[]) {
    decorate(kind, rows);
    const bytes = canonicalForwardJsonBytes({ kind, season: kind === 'prior' ? season - 1 : season, rows });
    const hash = forwardArtifactSha256(bytes);
    const binding: SourceBinding = { evidence: registry(kind, rows), kind, season, cutoff, purpose, sha256: hash, byte_count: bytes.length, source_sha256: hash,
      source_version: 'synthetic-v0', source_locator: 'synthetic:no-real-source', provider: 'synthetic-test', license_ref: 'synthetic-only',
      owner_commit: 'b'.repeat(40), contract_version: 'year1-bootstrap-internal-v0', reader_version: 'synthetic-v0', transform_version: 'synthetic-v0',
      evidence_class: 'verified_asof', publication_at: null, retrieved_at: cutoff, effective_at: season + '-09-11T12:00:00.000Z',
      generated_at: cutoff, admitted_at: season + '-09-14T13:00:00.000Z', witness_ids: [kind], record_keys: keys, complete: true,
      prior_membership: kind === 'prior' ? prior.map(p => ({ gsis: p.gsis, season: season - 1, season_type: 'REG' as const, complete: true,
        receipt_sha256: HASH, games: p.games.map(g => ({ game_id: g.game_id, season: g.season, season_type: 'REG' as const, completed_at: g.completed_at })) })) : null,
      decision_ref: 'synthetic-operator', review_ref: 'synthetic-independent-review', receipt_sha256: HASH, limitations: [], reconstruction_checks: null, derivation: null };
    if (kind === 'labels') {
      binding.effective_at = season + '-09-18T12:00:00.000Z'; binding.generated_at = season + '-09-19T12:00:00.000Z'; binding.admitted_at = season + '-09-19T13:00:00.000Z';
    }
    return { source: { kind, bytes }, binding, witness: { id: kind, kind: 'retrieval' as const, at: cutoff, source_sha256: hash, source_version: 'synthetic-v0', receipt_sha256: HASH } };
  }
  const parts = [make('prior', prior, prior.map(p => p.gsis)), make('week1', weekly, weekly.map(p => p.population_row_id + ':' + p.game_id)),
    make('population', populations, populations.map(p => p.row_id)), make('schedule', schedule, schedule.map(p => p.week + ':' + p.game_id))];
  const hashes = parts.map(p => p.binding.sha256).sort();
  const reconciliation = { status: 'passed' as const, validator_id: 'synthetic', validator_version: '0',
    evidence_ref: { repository: 'synthetic', path: 'no-file', artifact_version: '0', content_sha256: HASH }, scoring_profile_sha256: PROFILE.profile_sha256, source_input_sha256s: hashes };
  const admission = { id: 'synthetic-input-admission', scope: 'forecast.bootstrap.inputs' as const, purpose, season, cutoff,
    source_sha256s: hashes, decision_ref: 'synthetic-operator', review_ref: 'synthetic-review', admitted_at: season + '-09-14T13:00:00.000Z' };
  const request: InputRequest = { season, cutoff, purpose, profile: PROFILE, sources: parts.map(p => p.source), admission_id: admission.id, reconciliation };
  const trusted: TrustedEvidence = { bindings: parts.map(p => p.binding), witnesses: parts.map(p => p.witness), admissions: [admission], reconciliations: [reconciliation] };
  const lp = make('labels', outcomes, outcomes.map(p => p.row_id));
  const label: LabelRequest = { source: lp.source, admission_id: 'synthetic-label-admission' };
  const labelTrusted: TrustedEvidence = { bindings: [lp.binding], witnesses: [], reconciliations: [], admissions: [{ ...admission, id: label.admission_id, scope: 'forecast.bootstrap.labels', source_sha256s: [lp.binding.sha256], admitted_at: lp.binding.admitted_at }] };
  function replace(kind: SourceKind, change: (body: any) => void, resign = true, certifyEvidence = true) {
    const source = kind === 'labels' ? label.source : request.sources.find(s => s.kind === kind)!;
    const body = JSON.parse(new TextDecoder().decode(source.bytes)); change(body);
    if (certifyEvidence) decorate(kind, body.rows);
    const old = forwardArtifactSha256(source.bytes); source.bytes = canonicalForwardJsonBytes(body);
    if (!resign) return;
    const next = forwardArtifactSha256(source.bytes), context = kind === 'labels' ? labelTrusted : trusted;
    const b = context.bindings.find(b => b.sha256 === old)!; b.sha256 = next; b.source_sha256 = next; b.byte_count = source.bytes.length;
    if (certifyEvidence) b.evidence = registry(kind, body.rows);
    for (const w of context.witnesses) if (w.source_sha256 === old) w.source_sha256 = next;
    for (const a of context.admissions) a.source_sha256s = a.source_sha256s.map(h => h === old ? next : h).sort();
    if (kind !== 'labels') { request.reconciliation = { ...request.reconciliation, source_input_sha256s: request.sources.map(s => forwardArtifactSha256(s.bytes)).sort() }; trusted.reconciliations = [request.reconciliation]; }
  }
  function acceptEvidence(kind: SourceKind) {
    const source = kind === 'labels' ? label.source : request.sources.find(s => s.kind === kind)!;
    const body = JSON.parse(new TextDecoder().decode(source.bytes));
    const context = kind === 'labels' ? labelTrusted : trusted;
    context.bindings.find(b => b.kind === kind)!.evidence.rows = registry(kind, body.rows).rows;
  }
  function world() { const r = validateInputs(request, trusted); if (!r.ok) throw new Error(r.errors.map(e => e.message).join(';')); return r.data; }
  const loader = () => ({ request: label, trusted: labelTrusted });
  return { request, trusted, label, labelTrusted, replace, acceptEvidence, world, loader };
}
// SYNTHETIC FIXTURE END

describe('bootstrap input trust and population', () => {
  it('accepts independently witnessed exact bytes with unknown publication before/equal live cutoff', () => {
    for (const at of ['2026-09-14T11:00:00.000Z', '2026-09-14T12:00:00.000Z']) {
      const f = synthetic(2026);
      f.trusted.bindings.forEach(b => { b.retrieved_at = at; }); f.trusted.witnesses.forEach(w => { w.at = at; });
      const w = f.world(); expect(w.primary_ids).toHaveLength(80); expect(w.bindings[0].publication_at).toBeNull();
      expect(w.bindings[0].admitted_at).not.toBe(at); expect(w.bindings[0].effective_at).not.toBe(at);
    }
  });
  it('accepts an independently bound deterministic derivation and rejects mismatched lineage', () => {
    const f = synthetic(2026), b = f.trusted.bindings[0]; b.source_sha256 = 'c'.repeat(64);
    b.derivation = { receipt_sha256: HASH, source_sha256: b.source_sha256, consumed_sha256: b.sha256, transform_sha256: HASH };
    f.trusted.witnesses[0].source_sha256 = b.source_sha256;
    expect(f.world().primary_ids.length).toBe(80);
    b.derivation.consumed_sha256 = HASH; expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it.each(['late', 'missing', 'wrong_bytes', 'wrong_version', 'self_claim', 'admission', 'profile'])('rejects %s evidence', mode => {
    const f = synthetic(2026);
    if (mode === 'late') { f.trusted.witnesses[0].at = '2026-09-15T12:00:00.000Z'; f.trusted.bindings[0].retrieved_at = f.trusted.witnesses[0].at; }
    if (mode === 'missing') f.trusted.witnesses = [];
    if (mode === 'wrong_bytes') f.replace('week1', b => { b.rows[0].components.receptions = 21; }, false);
    if (mode === 'wrong_version') f.trusted.witnesses[0].source_version = 'different';
    if (mode === 'self_claim') Object.assign(f.request, { trusted: true });
    if (mode === 'admission') f.trusted.admissions = [];
    if (mode === 'profile') f.request.profile = { ...PROFILE, profile_sha256: HASH } as typeof PROFILE;
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('qualifies reconstruction historically but cannot relabel it into live evidence', () => {
    for (const season of [2025, 2026]) {
      const f = synthetic(season);
      f.trusted.bindings.forEach(b => { b.evidence_class = 'retrospective_reconstruction_for_method_selection'; b.witness_ids = []; b.limitations = ['original-publication-unknown'];
        b.reconstruction_checks = { completed_game_facts: true, cutoff_context_supported: true, no_postcutoff_information: true, labels_excluded: true }; });
      expect(validateInputs(f.request, f.trusted).ok).toBe(season === 2025);
      if (season === 2026) { f.trusted.bindings.forEach(b => { b.evidence_class = 'verified_asof'; }); expect(validateInputs(f.request, f.trusted).ok).toBe(false); }
    }
  });
  it('preserves explicit zero, DNP, missing counts and incomplete/no prior as distinct', () => {
    const f = synthetic();
    f.replace('week1', b => { b.rows[0].components = components(0); b.rows[0].state = 'did_not_play'; b.rows[0].zero_evidence_ref = 'synthetic-final-participation';
      b.rows[1].components = components(0); b.rows[1].state = 'played_zero'; b.rows[1].zero_evidence_ref = 'synthetic-zero'; b.rows[2].components.receptions = null; });
    f.replace('prior', b => { b.rows[3].games = []; b.rows[4].coverage = 'unavailable'; });
    f.trusted.bindings[0].prior_membership![3].games = [];
    const w = f.world(), get = (id: string) => w.rows.find(r => r.row_id === id)!;
    expect(get('QB:0').w).toBe(0); expect(get('QB:0').week1_state).toBe('did_not_play'); expect(get('QB:1').week1_state).toBe('played_zero');
    expect(get('QB:2').reasons).toContain('week1_unavailable'); expect(get('QB:3').p).toBeNull(); expect(get('QB:4').p).toBeNull();
  });
  it('rejects duplicates/truncation and withholds unresolved position without discarding census rows', () => {
    const f = synthetic(); f.replace('population', b => { b.rows[0].position = 'WR'; });
    expect(f.world().rows.find(r => r.row_id === 'QB:0')!.reasons).toContain('position_unresolved');
    f.replace('population', b => { b.rows[0].gsis = b.rows[1].gsis; }); expect(validateInputs(f.request, f.trusted).ok).toBe(false);
    const truncated = synthetic(); truncated.replace('week1', b => { b.rows.pop(); }); expect(validateInputs(truncated.request, truncated.trusted).ok).toBe(false);
  });
  it('rejects post-cutoff game completion, wrong season and labels hidden in features', () => {
    for (const which of ['game', 'season', 'label']) {
      const f = synthetic();
      if (which === 'game') f.replace('schedule', b => { b.rows[0].completed_at = '2022-09-15T12:00:00.000Z'; });
      if (which === 'season') f.replace('prior', b => { b.rows[0].season = 2022; });
      if (which === 'label') f.replace('week1', b => { b.rows[0].week2_points = 99; });
      expect(validateInputs(f.request, f.trusted).ok).toBe(false);
    }
  });
  it('freezes validated inputs independently of mutable request bytes and receipts', () => {
    const f = synthetic(), w = f.world(); f.trusted.bindings[0].limitations.push('later'); f.request.sources[0].bytes[0] = 0;
    expect(w.bindings[0].limitations).toEqual([]); expect(Object.isFrozen(w.rows[0])).toBe(true);
  });
});

// Regressions for the original independent review (synthetic only).
describe('repair regressions: input evidence', () => {
  it.each(['binding', 'admission', 'witness', 'reconciliation', 'evidence_ref'])('F1 rejects hidden labels in %s', where => {
    const f = synthetic();
    const target: any = where === 'binding' ? f.trusted.bindings[0] : where === 'admission' ? f.trusted.admissions[0] :
      where === 'witness' ? f.trusted.witnesses[0] : where === 'reconciliation' ? f.trusted.reconciliations[0] : f.trusted.reconciliations[0].evidence_ref;
    target.week2_points = 99;
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('F2 rejects a current-season game relabeled as prior production', () => {
    const f = synthetic(); f.replace('prior', b => { b.rows[0].games[0].completed_at = '2022-09-10T12:00:00.000Z'; });
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('F2 rejects denominator truncation independently of player inventory', () => {
    const f = synthetic(); f.replace('prior', b => { b.rows[0].games = []; });
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('F4 changing the accepted witness receipt changes world identity', () => {
    const f = synthetic(), before = f.world(); f.trusted.witnesses[0].receipt_sha256 = 'c'.repeat(64);
    expect(f.world().hash).not.toBe(before.hash);
  });
  it('F4 changing the accepted reconciliation receipt changes world identity', () => {
    const f = synthetic(), before = f.world(); f.request.reconciliation = { ...f.request.reconciliation, evidence_ref: { ...f.request.reconciliation.evidence_ref, content_sha256: 'c'.repeat(64) } }; f.trusted.reconciliations = [f.request.reconciliation];
    expect(f.world().hash).not.toBe(before.hash);
  });
  it('F5 incomplete components do not assert absence of prior production', () => {
    const f = synthetic(); f.replace('prior', b => { b.rows[0].games[0].components.receptions = null; });
    const row = f.world().rows.find(r => r.row_id === 'QB:0')!;
    expect(row.reasons).toContain('prior_components_incomplete');
    expect(row.reasons).not.toContain('no_prior_production'); expect(row.p).toBeNull();
  });
});

describe('repair positive controls and nested evidence rejection', () => {
  it.each(['reconstruction', 'derivation', 'prior_certificate', 'prior_game_certificate', 'string_array'])('rejects unknown/nonscalar evidence in %s', where => {
    const f = synthetic(); const b = f.trusted.bindings[0];
    if (where === 'reconstruction') b.reconstruction_checks = { completed_game_facts: true, cutoff_context_supported: true, no_postcutoff_information: true, labels_excluded: true, week2_points: 99 } as any;
    if (where === 'derivation') { b.source_sha256 = 'c'.repeat(64); f.trusted.witnesses[0].source_sha256 = b.source_sha256;
      b.derivation = { receipt_sha256: HASH, source_sha256: b.source_sha256, consumed_sha256: b.sha256, transform_sha256: HASH, week2_points: 99 } as any; }
    if (where === 'prior_certificate') Object.assign(b.prior_membership![0], { week2_points: 99 });
    if (where === 'prior_game_certificate') Object.assign(b.prior_membership![0].games[0], { week2_points: 99 });
    if (where === 'string_array') b.limitations = [{ week2_points: 99 }] as any;
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it.each(['season', 'type', 'extra', 'duplicate', 'uncertified'])('F2 rejects invalid prior membership %s', mode => {
    const f = synthetic();
    if (mode === 'season') f.replace('prior', b => { b.rows[0].games[0].season = 2022; });
    if (mode === 'type') f.replace('prior', b => { b.rows[0].games[0].season_type = 'POST'; });
    if (mode === 'extra') f.replace('prior', b => { b.rows[0].games.push({ ...b.rows[0].games[0], game_id: 'UNREGISTERED' }); });
    if (mode === 'duplicate') f.trusted.bindings[0].prior_membership![0].games.push({ ...f.trusted.bindings[0].prior_membership![0].games[0] });
    if (mode === 'uncertified') f.trusted.bindings[0].prior_membership = null;
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('F2 permits certified January prior-season REG production, counts zero games, and hashes membership receipts', () => {
    const f = synthetic();
    f.replace('prior', b => { b.rows[0].games[0].completed_at = '2022-01-09T12:00:00.000Z'; b.rows[0].games[0].components = components(0); });
    f.trusted.bindings[0].prior_membership![0].games[0].completed_at = '2022-01-09T12:00:00.000Z';
    const w = f.world(), row = w.rows.find(r => r.row_id === 'QB:0')!;
    expect(row.prior_games).toBe(1); expect(row.p).toBe(0); expect(row.prior_state).toBe('available');
    f.trusted.bindings[0].prior_membership![0].receipt_sha256 = 'c'.repeat(64); expect(f.world().hash).not.toBe(w.hash);
  });
  it('F5 retains all five prior states without zero filling', () => {
    const f = synthetic();
    f.replace('prior', b => { b.rows[0].games = []; b.rows[1].coverage = 'unavailable'; b.rows[2].games[0].components.receptions = null; b.rows.splice(3, 1); });
    const binding = f.trusted.bindings[0]; binding.prior_membership![0].games = [];
    binding.prior_membership = binding.prior_membership!.filter(m => m.gsis !== 'synthetic:QB:3');
    binding.record_keys = binding.record_keys.filter(id => id !== 'synthetic:QB:3');
    const w = f.world();
    expect([0, 1, 2, 3, 4].map(i => w.rows.find(r => r.row_id === 'QB:' + i)!.prior_state)).toEqual([
      'no_prior_production', 'prior_coverage_unavailable', 'prior_components_incomplete', 'prior_row_missing', 'available']);
    expect(w.rows.filter(r => r.row_id.startsWith('QB:') && !r.primary).every(r => r.p === null)).toBe(true);
  });
  it('F4 retains selected witness kind, receipt and exact availability upper bound plus reconciliation', () => {
    const f = synthetic(2026), w = f.world();
    expect(w.witnesses.find(x => x.id === 'prior')).toEqual(f.trusted.witnesses[0]);
    expect(w.availability[0].fact_available_at).toBe(f.request.cutoff);
    expect(w.availability[0].witness_ids).toEqual(['prior']); expect(w.reconciliation).toEqual(f.request.reconciliation);
    expect(Object.isFrozen(w.witnesses[0])).toBe(true);
  });
});

it('R1 preserves accepted population identity evidence', () => { expect(synthetic().world().rows[0]).toHaveProperty('population_evidence'); });

import { featuresFor } from '../src/experiments/year1Week2Bootstrap/input.js';
describe('R1 bounded identity and observation preservation', () => {
  it('retains supported identity, mapping, prior game lineage, units and descriptive context', () => {
    const f = synthetic(), row = f.world().rows.find(r => r.row_id === 'QB:0')!;
    expect(row.population_evidence.identity.provider_player_id).toBe('provider:synthetic:QB:0');
    expect(row.population_evidence.mapping_record).toMatchObject({ canonical_gsis: row.gsis, version: 'synthetic-mapping-v1', sha256: HASH, confidence: 'provider_verified' });
    expect(row.prior_game_evidence[0]).toMatchObject({ game_id: 'SYN_PRIOR', season: 2021, season_type: 'REG' });
    expect(row.prior_game_evidence[0].evidence.components!.receptions).toMatchObject({ value: 10, units: 'count', state: 'observed', locator: { field: 'receptions' } });
    expect(row.week1_evidence[0].evidence.descriptive!.targets.value).toBe(3);
  });
  it.each(['explicit_zero', 'source_null', 'absent', 'unavailable'] as const)('preserves %s distinctly and withholds missing scoring components', state => {
    const f = synthetic(); f.replace('week1', b => {
      const r = b.rows[0], value = state === 'explicit_zero' ? 0 : null; r.components.receptions = value;
      const cell = r.evidence.components.receptions; cell.value = value; cell.state = state;
      if (state === 'unavailable') { cell.units = null; cell.locator = null; }
    }, true, false); f.acceptEvidence('week1');
    const row = f.world().rows.find(r => r.row_id === 'QB:0')!;
    expect(row.week1_evidence[0].evidence.components!.receptions.state).toBe(state);
    expect(row.w).toBe(state === 'explicit_zero' ? 0 : null);
    expect(row.week1_evidence[0].evidence.descriptive!.targets.value).toBe(3);
  });
  it('preserves a provider-known but canonically unresolved player and independent observations', () => {
    const f = synthetic();
    f.replace('population', b => { b.rows[0].gsis = null; b.rows[0].identity_status = 'unresolved'; b.rows[0].evidence.identity.status = 'unresolved'; }, true, false);
    f.replace('week1', b => { b.rows[0].gsis = null; b.rows[0].evidence.identity.status = 'unresolved'; }, true, false);
    for (const kind of ['population', 'week1'] as const) {
      const binding = f.trusted.bindings.find(b => b.kind === kind)!;
      binding.evidence.mappings[0].canonical_gsis = null; binding.evidence.mappings[0].status = 'unresolved'; binding.evidence.mappings[0].confidence = null;
      f.acceptEvidence(kind);
    }
    const row = f.world().rows.find(r => r.row_id === 'QB:0')!;
    expect(row.gsis).toBeNull(); expect(row.primary).toBe(false); expect(row.reasons).toContain('identity_unresolved');
    expect(row.population_evidence.identity.provider_player_id).toBe('provider:synthetic:QB:0');
    expect(row.population_evidence.mapping_record!.confidence).toBeNull(); expect(row.w).toBe(20);
  });
  it('can retain completely unavailable identity without inventing provider IDs or mappings', () => {
    const f = synthetic();
    f.replace('population', b => { const p = b.rows[0]; p.gsis = null; p.identity_status = 'unavailable'; p.evidence.identity = { status: 'unavailable', source_ref: null, provider_player_id: null, mapping_ref: null }; }, true, false);
    f.acceptEvidence('population');
    // Missing Week 1 observation is an honest absence; never synthesize a zero row.
    f.replace('week1', b => { b.rows.shift(); }); f.trusted.bindings.find(b => b.kind === 'week1')!.record_keys.shift();
    const row = f.world().rows.find(r => r.row_id === 'QB:0')!;
    expect(row.population_evidence.mapping_record).toBeNull(); expect(row.population_evidence.identity.provider_player_id).toBeNull();
    expect(row.week1_evidence).toEqual([]); expect(row.w).toBeNull(); expect(row.primary).toBe(false);
  });
  it.each(['units', 'value', 'state', 'player', 'source', 'missing_mapping', 'wrong_mapping', 'mapping_scope', 'locator', 'nested_outcome'])('rejects malformed or contradictory %s even in accepted row evidence', mode => {
    const f = synthetic();
    f.replace('week1', b => { const e = b.rows[0].evidence, c = e.components.receptions;
      if (mode === 'units') c.units = 'yards'; if (mode === 'value') c.value = 21;
      if (mode === 'state') c.state = 'explicit_zero'; if (mode === 'player') c.locator.provider_player_id = 'someone-else';
      if (mode === 'source') c.locator.artifact_sha256 = 'c'.repeat(64); if (mode === 'locator') c.locator = null;
      if (mode === 'missing_mapping') e.identity.mapping_ref = null; if (mode === 'wrong_mapping') e.identity.mapping_ref = 'synthetic:QB:1';
      if (mode === 'nested_outcome') c.week2_points = 55;
    }, true, false); f.acceptEvidence('week1');
    if (mode === 'mapping_scope') f.trusted.bindings.find(b => b.kind === 'week1')!.evidence.sources[0].kind = 'labels';
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('rejects a substituted locator without an accepted corresponding row record', () => {
    const f = synthetic(); f.replace('week1', b => { b.rows[0].evidence.components.receptions.locator.row = 'another-row'; }, true, false);
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('accepted provenance changes alter world identity; missing trust records reject', () => {
    const f = synthetic(), initial = f.world();
    f.trusted.bindings.find(b => b.kind === 'population')!.evidence.mappings[0].sha256 = 'c'.repeat(64);
    const remapped = f.world(); expect(remapped.hash).not.toBe(initial.hash);
    f.replace('week1', b => { b.rows[0].evidence.components.receptions.locator.field = 'provider_receptions_v2'; }, true, false);
    expect(validateInputs(f.request, f.trusted).ok).toBe(false); f.acceptEvidence('week1');
    expect(f.world().hash).not.toBe(remapped.hash);
    f.trusted.bindings.find(b => b.kind === 'population')!.evidence.mappings = [];
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it('optional descriptive missingness and unknown confidence do not alter features or eligibility', () => {
    const f = synthetic(), before = f.world();
    f.replace('week1', b => { for (const r of b.rows) for (const k of ['targets', 'carries']) r.evidence.descriptive[k] = { value: null, state: 'unavailable', units: null, locator: null }; }, true, false); f.acceptEvidence('week1');
    f.trusted.bindings.find(b => b.kind === 'population')!.evidence.mappings.forEach(m => { m.confidence = null; });
    const after = f.world(); expect(after.primary_ids).toEqual(before.primary_ids);
    expect(after.rows.map(featuresFor)).toEqual(before.rows.map(featuresFor)); expect(after.hash).not.toBe(before.hash);
  });
});

// R1a: synthetic accepted evidence only; source location survives absent player identity.
function anonymousEvidence(f: ReturnType<typeof synthetic>, knownProvider = false) {
  for (const kind of ['population', 'week1', 'labels'] as const) {
    f.replace(kind, body => {
      const row = body.rows[0]; row.gsis = null;
      if (kind === 'population') row.identity_status = 'unresolved';
      row.evidence.identity = { status: 'unresolved', source_ref: 'source',
        provider_player_id: knownProvider ? 'provider:synthetic:QB:0' : null,
        mapping_ref: knownProvider ? 'synthetic:QB:0' : null };
      for (const cell of [...Object.values(row.evidence.components ?? {}), ...Object.values(row.evidence.descriptive ?? {})] as any[]) {
        if (cell.locator) cell.locator.provider_player_id = row.evidence.identity.provider_player_id;
      }
    }, true, false);
    const context = kind === 'labels' ? f.labelTrusted : f.trusted;
    const binding = context.bindings.find(b => b.kind === kind)!;
    if (knownProvider) {
      const mapping = binding.evidence.mappings.find(m => m.id === 'synthetic:QB:0')!;
      mapping.canonical_gsis = null; mapping.status = 'unresolved'; mapping.confidence = null;
    } else binding.evidence.mappings = binding.evidence.mappings.filter(m => m.id !== 'synthetic:QB:0');
    f.acceptEvidence(kind);
  }
}

it('R1a source-located absent-provider probe and unchanged positive control', () => {
  expect(validateInputs(synthetic().request, synthetic().trusted).ok).toBe(true);
  const f = synthetic(); anonymousEvidence(f);
  const result = validateInputs(f.request, f.trusted);
  expect(result.ok, JSON.stringify(result)).toBe(true);
});

describe('R1a anonymous source-location boundaries', () => {
  it.each(['observed', 'explicit_zero', 'source_null', 'absent', 'unavailable'] as const)('retains anonymous %s evidence without fabricated identity', state => {
    const f = synthetic(); anonymousEvidence(f);
    f.replace('week1', b => {
      const row = b.rows[0], c = row.evidence.components.receptions;
      c.state = state; c.value = row.components.receptions = state === 'observed' ? 20 : state === 'explicit_zero' ? 0 : null;
      if (state === 'unavailable') { c.locator = null; c.units = null; }
    }, true, false); f.acceptEvidence('week1');
    const row = f.world().rows.find(r => r.row_id === 'QB:0')!, e = row.week1_evidence[0].evidence;
    expect(row.gsis).toBeNull(); expect(row.primary).toBe(false); expect(row.reasons).toContain('identity_unresolved');
    expect(row.population_evidence.mapping_record).toBeNull(); expect(e.mapping_record).toBeNull();
    expect(e.identity).toEqual({ status: 'unresolved', source_ref: 'source', provider_player_id: null, mapping_ref: null });
    expect(e.components!.receptions.state).toBe(state);
    expect(e.components!.receptions.value).toBe(state === 'observed' ? 20 : state === 'explicit_zero' ? 0 : null);
    expect(row.w).toBe(state === 'observed' ? 20 : state === 'explicit_zero' ? 0 : null);
    if (state !== 'unavailable') expect(e.components!.receptions.locator).toEqual({ source_ref: 'source', artifact_sha256: e.source_records[0].sha256, row: 'QB:0:SYN_W1', field: 'receptions', provider_player_id: null });
    else expect(e.components!.receptions.locator).toBeNull();
    expect(e.descriptive!.targets.locator!.provider_player_id).toBeNull();
  });
  it.each(['observed', 'explicit_zero', 'source_null'] as const)('rejects missing source locator for anonymous %s', state => {
    const f = synthetic(); anonymousEvidence(f);
    f.replace('week1', b => { const r = b.rows[0], c = r.evidence.components.receptions; c.state = state; c.value = r.components.receptions = state === 'observed' ? 20 : state === 'explicit_zero' ? 0 : null; c.locator = null; }, true, false); f.acceptEvidence('week1');
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it.each(['', ' ', ' bad ', 7, {}, [], false])('rejects malformed provider identity %j instead of making it anonymous', id => {
    const f = synthetic(); anonymousEvidence(f);
    f.replace('week1', b => { b.rows[0].evidence.components.receptions.locator.provider_player_id = id; }, true, false); f.acceptEvidence('week1');
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it.each([null, 'other-provider-player'])('rejects locator identity %j contradicting resolved accepted row/mapping', id => {
    const f = synthetic();
    f.replace('week1', b => { b.rows[0].evidence.components.receptions.locator.provider_player_id = id; }, true, false); f.acceptEvidence('week1');
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it.each(['source_ref', 'artifact_sha256', 'row', 'field', 'provider_player_id'])('requires the exact bounded locator key %s even for anonymous evidence', key => {
    const f = synthetic(); anonymousEvidence(f);
    f.replace('week1', b => { delete b.rows[0].evidence.components.receptions.locator[key]; }, true, false); f.acceptEvidence('week1');
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
  it.each(['source', 'hash', 'mapping', 'canonical', 'confidence', 'hidden_label', 'invented_provider'])('rejects anonymous %s substitution', mode => {
    const f = synthetic(); anonymousEvidence(f);
    f.replace('week1', b => { const r = b.rows[0], e = r.evidence, l = e.components.receptions.locator;
      if (mode === 'source') l.source_ref = 'other-source';
      if (mode === 'hash') l.artifact_sha256 = 'c'.repeat(64);
      if (mode === 'mapping') e.identity.mapping_ref = 'synthetic:QB:1';
      if (mode === 'canonical') { r.gsis = 'synthetic:QB:0'; e.identity.status = 'resolved'; }
      if (mode === 'confidence') e.identity.confidence = 'high';
      if (mode === 'hidden_label') l.outcome = { week2_points: 99 };
      if (mode === 'invented_provider') l.provider_player_id = 'unknown';
    }, true, false); f.acceptEvidence('week1');
    expect(validateInputs(f.request, f.trusted).ok).toBe(false);
  });
});
