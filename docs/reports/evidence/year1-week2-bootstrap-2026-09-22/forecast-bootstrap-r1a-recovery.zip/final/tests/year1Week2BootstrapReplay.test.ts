import { describe, it, expect } from 'vitest';
// SYNTHETIC FIXTURE START
import { TIBER_GENERIC_FULL_PPR_V1_PROFILE_REF as PROFILE } from '../src/contracts/genericFullPprProfile.js';
import { canonicalForwardJsonBytes, forwardArtifactSha256 } from '../src/serialization/canonicalForwardArtifacts.js';
import { validateInputs, type InputRequest, type SourceKind, type SourceBinding, type TrustedEvidence, type LabelRequest } from '../src/experiments/year1Week2Bootstrap/input.js';
const HASH = 'a'.repeat(64);
const RUN = { run_id: 'synthetic-only-run', code_sha256: HASH, configuration_sha256: HASH, specification_sha256: '7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844' };
const components = (points: number) => ({ receptions: points, receiving_yards: 0, receiving_tds: 0, rushing_yards: 0, rushing_tds: 0, passing_yards: 0, passing_tds: 0, interceptions: 0 });
/** Entirely invented games, people, source bytes, receipts and labels. No I/O. */
function synthetic(season = 2022, n = 20, outcome = 15) {
  const cutoff = season + '-09-14T12:00:00.000Z';
  const purpose = season === 2026 ? 'live_2026_forecast_inputs' as const : 'historical_method_selection' as const;
  const populations = ['QB', 'RB', 'WR', 'TE'].flatMap(position => Array.from({ length: n }, (_, i) => ({
    row_id: position + ':' + i, gsis: 'synthetic:' + position + ':' + i, position, team: 'SYN_A', identity_status: 'resolved', roster_status: 'active', position_resolution_ref: null,
  })));
  const prior = populations.map(p => ({ gsis: p.gsis, season: season - 1, position: p.position, team: 'SYN_A', coverage: 'complete',
    games: [{ game_id: 'SYN_PRIOR', season: season - 1, season_type: 'REG', completed_at: (season - 1) + '-09-10T12:00:00.000Z', components: components(10) }] }));
  const weekly = populations.map(p => ({ population_row_id: p.row_id, gsis: p.gsis, season, week: 1, game_id: 'SYN_W1', state: 'played', zero_evidence_ref: null, components: components(20) }));
  const schedule = [
    { game_id: 'SYN_W1', week: 1, home: 'SYN_A', away: 'SYN_B', completed_at: season + '-09-11T12:00:00.000Z', kickoff: season + '-09-11T09:00:00.000Z' },
    { game_id: 'SYN_W2', week: 2, home: 'SYN_A', away: 'SYN_B', completed_at: null, kickoff: season + '-09-17T09:00:00.000Z' },
  ];
  const outcomes = populations.map(p => ({ row_id: p.row_id, gsis: p.gsis, season, week: 2, game_id: 'SYN_W2', state: 'played', zero_evidence_ref: null, components: components(outcome) }));
  const providerId = (row: any) => row.gsis === null ? null : 'provider:' + row.gsis;
  const rawHash = (kind: SourceKind) => forwardArtifactSha256(canonicalForwardJsonBytes({ synthetic_raw: kind, season }));
  function decorate(kind: SourceKind, rows: any[]) {
    const identity = (row: any) => ({ status: row.gsis === null ? (row.identity_status === 'unavailable' ? 'unavailable' : 'unresolved') : 'resolved',
      source_ref: row.gsis === null ? null : 'source', provider_player_id: providerId(row), mapping_ref: row.gsis === null ? null : row.gsis });
    const cells = (row: any, values: any, rowKey: string) => Object.fromEntries(Object.keys(components(0)).map(field => {
      const value = values === null ? null : values[field];
      return [field, { value, state: value === null ? 'source_null' : value === 0 ? 'explicit_zero' : 'observed', units: field.endsWith('_yards') ? 'yards' : 'count',
        locator: row.gsis === null ? null : { source_ref: 'source', artifact_sha256: rawHash(kind), row: rowKey, field, provider_player_id: providerId(row) } }];
    }));
    const ev = (row: any, vals: any, rowKey: string, description = false) => ({ identity: identity(row), components: vals === undefined ? null : cells(row, vals, rowKey),
      descriptive: description ? Object.fromEntries(['targets', 'carries'].map(field => [field, { value: 3, state: 'observed', units: 'count',
        locator: { source_ref: 'source', artifact_sha256: rawHash(kind), row: rowKey, field, provider_player_id: providerId(row) } }])) : null });
    for (const row of rows) {
      if (kind === 'population') row.evidence = ev(row, undefined, row.row_id);
      if (kind === 'prior') { row.evidence = ev(row, undefined, row.gsis); for (const g of row.games) g.evidence = ev(row, g.components, row.gsis + ':' + g.game_id); }
      if (kind === 'week1') row.evidence = ev(row, row.components, row.population_row_id + ':' + row.game_id, true);
      if (kind === 'labels') row.evidence = ev(row, row.components, row.row_id);
    }
  }
  function registry(kind: SourceKind, rows: any[]) {
    const records: any[] = [];
    for (const row of rows) {
      if (kind === 'population' || kind === 'labels') records.push({ key: JSON.stringify([row.row_id]), evidence: row.evidence });
      if (kind === 'prior') { records.push({ key: JSON.stringify([row.gsis]), evidence: row.evidence }); for (const g of row.games) records.push({ key: JSON.stringify([row.gsis, g.game_id]), evidence: g.evidence }); }
      if (kind === 'week1') records.push({ key: JSON.stringify([row.population_row_id, row.game_id]), evidence: row.evidence });
    }
    return { sources: kind === 'schedule' ? [] : [{ id: 'source', kind, season: kind === 'prior' ? season - 1 : season, sha256: rawHash(kind), locator: 'synthetic:raw-' + kind, provider: 'synthetic-test', receipt_sha256: HASH }],
      mappings: kind === 'schedule' ? [] : rows.filter(row => row.gsis !== null).map(row => ({ id: row.gsis, source_ref: 'source', provider_player_id: providerId(row), canonical_gsis: row.gsis,
        version: 'synthetic-mapping-v1', sha256: HASH, receipt_sha256: HASH, status: 'resolved', confidence: 'provider_verified' })), rows: JSON.parse(JSON.stringify(records)) } as SourceBinding['evidence'];
  }
  function make(kind: SourceKind, rows: unknown[], keys: string[]) {
    decorate(kind, rows);
    const bytes = canonicalForwardJsonBytes({ kind, season: kind === 'prior' ? season - 1 : season, rows });
    const hash = forwardArtifactSha256(bytes);
    const binding: SourceBinding = { evidence: registry(kind, rows), kind, season, cutoff, purpose, sha256: hash, byte_count: bytes.length, source_sha256: hash,
      source_version: 'synthetic-v0', source_locator: 'synthetic:no-real-source', provider: 'synthetic-test', license_ref: 'synthetic-only',
      owner_commit: 'b'.repeat(40), contract_version: 'year1-bootstrap-internal-v0', reader_version: 'synthetic-v0', transform_version: 'synthetic-v0',
      evidence_class: 'verified_asof', publication_at: null, retrieved_at: cutoff, effective_at: season + '-09-11T12:00:00.000Z',
      generated_at: cutoff, admitted_at: season + '-09-14T13:00:00.000Z', witness_ids: [kind], record_keys: keys, complete: true,
      prior_membership: kind === 'prior' ? prior.map(p => ({ gsis: p.gsis, season: season - 1, season_type: 'REG' as const, complete: true,
        receipt_sha256: HASH, games: p.games.map(g => ({ game_id: g.game_id, season: g.season, season_type: 'REG' as const, completed_at: g.completed_at })) })) : null,
      decision_ref: 'synthetic-operator', review_ref: 'synthetic-independent-review', receipt_sha256: HASH, limitations: [], reconstruction_checks: null, derivation: null };
    if (kind === 'labels') {
      binding.effective_at = season + '-09-18T12:00:00.000Z'; binding.generated_at = season + '-09-19T12:00:00.000Z'; binding.admitted_at = season + '-09-19T13:00:00.000Z';
    }
    return { source: { kind, bytes }, binding, witness: { id: kind, kind: 'retrieval' as const, at: cutoff, source_sha256: hash, source_version: 'synthetic-v0', receipt_sha256: HASH } };
  }
  const parts = [make('prior', prior, prior.map(p => p.gsis)), make('week1', weekly, weekly.map(p => p.population_row_id + ':' + p.game_id)),
    make('population', populations, populations.map(p => p.row_id)), make('schedule', schedule, schedule.map(p => p.week + ':' + p.game_id))];
  const hashes = parts.map(p => p.binding.sha256).sort();
  const reconciliation = { status: 'passed' as const, validator_id: 'synthetic', validator_version: '0',
    evidence_ref: { repository: 'synthetic', path: 'no-file', artifact_version: '0', content_sha256: HASH }, scoring_profile_sha256: PROFILE.profile_sha256, source_input_sha256s: hashes };
  const admission = { id: 'synthetic-input-admission', scope: 'forecast.bootstrap.inputs' as const, purpose, season, cutoff,
    source_sha256s: hashes, decision_ref: 'synthetic-operator', review_ref: 'synthetic-review', admitted_at: season + '-09-14T13:00:00.000Z' };
  const request: InputRequest = { season, cutoff, purpose, profile: PROFILE, sources: parts.map(p => p.source), admission_id: admission.id, reconciliation };
  const trusted: TrustedEvidence = { bindings: parts.map(p => p.binding), witnesses: parts.map(p => p.witness), admissions: [admission], reconciliations: [reconciliation] };
  const lp = make('labels', outcomes, outcomes.map(p => p.row_id));
  const label: LabelRequest = { source: lp.source, admission_id: 'synthetic-label-admission' };
  const labelTrusted: TrustedEvidence = { bindings: [lp.binding], witnesses: [], reconciliations: [], admissions: [{ ...admission, id: label.admission_id, scope: 'forecast.bootstrap.labels', source_sha256s: [lp.binding.sha256], admitted_at: lp.binding.admitted_at }] };
  function replace(kind: SourceKind, change: (body: any) => void, resign = true, certifyEvidence = true) {
    const source = kind === 'labels' ? label.source : request.sources.find(s => s.kind === kind)!;
    const body = JSON.parse(new TextDecoder().decode(source.bytes)); change(body);
    if (certifyEvidence) decorate(kind, body.rows);
    const old = forwardArtifactSha256(source.bytes); source.bytes = canonicalForwardJsonBytes(body);
    if (!resign) return;
    const next = forwardArtifactSha256(source.bytes), context = kind === 'labels' ? labelTrusted : trusted;
    const b = context.bindings.find(b => b.sha256 === old)!; b.sha256 = next; b.source_sha256 = next; b.byte_count = source.bytes.length;
    if (certifyEvidence) b.evidence = registry(kind, body.rows);
    for (const w of context.witnesses) if (w.source_sha256 === old) w.source_sha256 = next;
    for (const a of context.admissions) a.source_sha256s = a.source_sha256s.map(h => h === old ? next : h).sort();
    if (kind !== 'labels') { request.reconciliation = { ...request.reconciliation, source_input_sha256s: request.sources.map(s => forwardArtifactSha256(s.bytes)).sort() }; trusted.reconciliations = [request.reconciliation]; }
  }
  function acceptEvidence(kind: SourceKind) {
    const source = kind === 'labels' ? label.source : request.sources.find(s => s.kind === kind)!;
    const body = JSON.parse(new TextDecoder().decode(source.bytes));
    const context = kind === 'labels' ? labelTrusted : trusted;
    context.bindings.find(b => b.kind === kind)!.evidence.rows = registry(kind, body.rows).rows;
  }
  function world() { const r = validateInputs(request, trusted); if (!r.ok) throw new Error(r.errors.map(e => e.message).join(';')); return r.data; }
  const loader = () => ({ request: label, trusted: labelTrusted });
  return { request, trusted, label, labelTrusted, replace, acceptEvidence, world, loader };
}
// SYNTHETIC FIXTURE END


import { createReplay, type ValidationSeal } from '../src/experiments/year1Week2Bootstrap/replay.js';
function throughValidation(y2024 = 15, trainOutcome = 15, n = 20) {
  const a = synthetic(2022, n, trainOutcome), b = synthetic(2023, n, trainOutcome), v = synthetic(2024, n, y2024);
  const replay = createReplay(RUN);
  replay.train([a.world(), b.world()], [a.loader, b.loader]);
  replay.prepareValidation(v.world()); const validation = replay.evaluateValidation(v.loader); const seal = replay.sealValidation();
  return { replay, validation, seal };
}
describe('staged bootstrap replay', () => {
  it('freezes predictions and seals 2024 before the 2025 label source can be called', () => {
    const r = createReplay(RUN), calls: string[] = [];
    const a = synthetic(2022), b = synthetic(2023), v = synthetic(2024), f = synthetic(2025);
    const load = (name: string, fixture: ReturnType<typeof synthetic>) => () => { calls.push(name); return fixture.loader(); };
    expect(() => r.evaluateFinal(load('forbidden', f))).toThrow(); expect(calls).toEqual([]);
    r.train([a.world(), b.world()], [load('2022', a), load('2023', b)]);
    expect(calls).toEqual(['2022', '2023']);
    expect(() => r.train([a.world(), b.world()], [a.loader, b.loader])).toThrow();
    r.prepareValidation(v.world()); expect(calls).toHaveLength(2);
    r.evaluateValidation(load('2024', v));
    expect(() => r.prepareFinal(f.world(), {} as ValidationSeal)).toThrow();
    const seal = r.sealValidation();
    expect(() => r.prepareFinal(f.world(), { ...seal })).toThrow('seal');
    r.prepareFinal(f.world(), seal); expect(calls).toEqual(['2022', '2023', '2024']);
    const study = r.evaluateFinal(load('2025', f));
    expect(calls).toEqual(['2022', '2023', '2024', '2025']); expect(study.selected).toBe('C2');
    expect(study.rule.alpha).toBe(0.5); expect(study.final.arms.C2.pooled.mae).toBe(0);
    expect(study.final.arms.C0.pooled.mae).toBe(5); expect(study.final.arms.C1.pooled.rmse).toBe(5);
    expect(study.final.arms.C2.pooled.spearman).toBeNull();
    expect(study.final.game_count).toBe(1); expect(study.final.cohorts.no_prior.arms.C0.mae).toBeNull();
    expect(study.final.evaluated_ids).toEqual(study.final.primary_ids);
    expect(study.final.paired_errors).toHaveLength(80);
    expect(Object.isFrozen(study.final)).toBe(true); expect(r.state()).toBe('done');
    expect(() => r.evaluateFinal(f.loader)).toThrow();
  });
  it.each([
    ['validation_failure', 10, 15, 15, 'C0'],
    ['final_failure', 15, 10, 15, 'C0'],
    ['mae_tie', 12.5, 15, 15, 'C0'],
    ['zero_alpha', 10, 10, 5, 'C0'],
    ['C1_best_stays_diagnostic', 20, 20, 15, 'C2'],
  ])('%s preserves the conservative selection gate', (_name, yv, yf, yt, expected) => {
    // Fractional targets are represented through integral receiving yards, never fractional components.
    const make = (season: number, y: number) => {
      const x = synthetic(season, 20, Math.floor(y));
      if (y % 1) x.replace('labels', body => { body.rows.forEach((row: any) => { row.components.receiving_yards = 5; }); });
      return x;
    };
    const a = make(2022, Number(yt)), b = make(2023, Number(yt)), v = make(2024, Number(yv)), f = make(2025, Number(yf));
    const r = createReplay(RUN); r.train([a.world(), b.world()], [a.loader, b.loader]); r.prepareValidation(v.world()); r.evaluateValidation(v.loader);
    const seal = r.sealValidation(); r.prepareFinal(f.world(), seal); expect(r.evaluateFinal(f.loader).selected).toBe(expected);
  });
  it('retains C0 if a single position worsens despite aggregate C2 improvement', () => {
    const a = synthetic(2022), b = synthetic(2023), v = synthetic(2024), f = synthetic(2025);
    v.replace('labels', body => { body.rows.filter((row: any) => row.row_id.startsWith('QB:')).forEach((row: any) => { row.components = components(10); }); });
    const r = createReplay(RUN); r.train([a.world(), b.world()], [a.loader, b.loader]); r.prepareValidation(v.world());
    const report = r.evaluateValidation(v.loader);
    expect(report.arms.C2.macro_mae!).toBeLessThan(report.arms.C0.macro_mae!);
    const seal = r.sealValidation(); r.prepareFinal(f.world(), seal); expect(r.evaluateFinal(f.loader).selected).toBe('C0');
  });
  it('does not pool away a failed year/position threshold', () => {
    const a = synthetic(2022, 19), b = synthetic(2023, 25);
    expect(() => createReplay(RUN).train([a.world(), b.world()], [a.loader, b.loader])).toThrow('inconclusive');
    const run = throughValidation(); const f = synthetic(2025, 19);
    run.replay.prepareFinal(f.world(), run.seal); expect(run.replay.evaluateFinal(f.loader).result).toBe('bootstrap_study_inconclusive');
  });
  it('enforces 95% label resolution on the fixed cohort and reports missing outcomes', () => {
    for (const [n, missing, passes] of [[21, 1, true], [22, 2, false], [40, 2, true], [40, 3, false]] as const) {
      const run = throughValidation(), f = synthetic(2025, n);
      f.replace('labels', body => { body.rows.filter((row: any) => row.row_id.startsWith('QB:')).slice(0, missing).forEach((row: any) => { row.state = 'unresolved'; row.components = null; }); });
      run.replay.prepareFinal(f.world(), run.seal); const study = run.replay.evaluateFinal(f.loader);
      expect(study.final.sufficiency.QB.resolved).toBe(n - missing); expect(study.final.sufficiency.QB.passes).toBe(passes);
      expect(study.final.primary_ids).toHaveLength(4 * n); expect(study.final.unresolved_label_ids).toHaveLength(missing);
      expect(study.selected === null).toBe(!passes);
    }
  });
  it('keeps no-prior rows outside all three common-cohort losses and reports extra C1 coverage', () => {
    const run = throughValidation(), f = synthetic(2025, 21);
    f.replace('prior', body => { body.rows[0].games = []; });
  f.trusted.bindings[0].prior_membership![0].games = [];
    run.replay.prepareFinal(f.world(), run.seal); const study = run.replay.evaluateFinal(f.loader);
    expect(study.final.primary_ids).toHaveLength(83); expect(study.final.cohorts.no_prior.population_count).toBe(1);
    expect(study.final.coverage.C1.diagnostic_extra_ids).toEqual(['QB:0']);
    expect(study.final.coverage.C2.full_population.denominator).toBe(84);
    for (const a of ['C0', 'C1', 'C2'] as const) expect(study.final.arms[a].pooled.n).toBe(83);
  });
  it('rejects 2026 training, swapped validation season, altered labels and replay after a failed access', () => {
    const live = synthetic(2026), b = synthetic(2023);
    expect(() => createReplay(RUN).train([live.world(), b.world()], [live.loader, b.loader])).toThrow('season');
    const a = synthetic(2022), r = createReplay(RUN); r.train([a.world(), b.world()], [a.loader, b.loader]);
    expect(() => r.prepareValidation(synthetic(2025).world())).toThrow('season');
    const v = synthetic(2024); r.prepareValidation(v.world()); v.replace('labels', body => { body.rows[0].gsis = 'wrong'; });
    expect(() => r.evaluateValidation(v.loader)).toThrow('membership');
    expect(() => r.evaluateValidation(synthetic(2024).loader)).toThrow('stage');
  });
});


describe('repair stage identity and prior cohort regressions', () => {
  it('F3 freezes run identity before labels open and includes it in the seal', () => {
    const proposed = { ...RUN }; const r = createReplay(proposed); proposed.code_sha256 = 'c'.repeat(64);
    const a = synthetic(2022), b = synthetic(2023), v = synthetic(2024);
    r.train([a.world(), b.world()], [a.loader, b.loader]); r.prepareValidation(v.world()); r.evaluateValidation(v.loader);
    const seal = r.sealValidation(); expect(seal.identity).toEqual(RUN); expect(Object.isFrozen(seal.identity)).toBe(true);
    expect(() => createReplay({ ...RUN, week2_points: 12 } as any)).toThrow('exact fields');
    expect(() => createReplay(undefined as any)).toThrow();
  });
  it('F5 counts certified no-prior separately from incomplete prior in reports', () => {
    const run = throughValidation(), f = synthetic(2025, 24);
    f.replace('prior', body => { body.rows[0].games = []; body.rows[1].coverage = 'unavailable'; body.rows[2].games[0].components.receptions = null; });
    f.trusted.bindings[0].prior_membership![0].games = [];
    run.replay.prepareFinal(f.world(), run.seal); const s = run.replay.evaluateFinal(f.loader);
    expect(s.final.cohorts.no_prior.population_count).toBe(1); expect(s.final.cohorts.prior_unavailable.population_count).toBe(2);
    expect(s.final.unavailable_counts.no_prior_production).toBe(1); expect(s.final.unavailable_counts.prior_components_incomplete).toBe(1);
  });
});

describe('mixed-ranking-tie conformance', () => {
  it('uses hand-calculated midranks and is invariant to equivalent source row permutations', () => {
    // x=[1,1,2,3,4], y=[1,2,2,4,3]. Midranks are [1.5,1.5,3,4,5]
    // and [1,2.5,2.5,5,4]; means 3; cross-product 7.75, both sums of
    // squared deviations 9.5. Thus rho=7.75/9.5=31/38, not a generated oracle.
    // Repeating each vector four times preserves that correlation.
    const evaluate = (reverse: boolean) => {
      const run = throughValidation(), f = synthetic(2025);
      f.replace('prior', b => { for (const r of b.rows) r.games[0].components = components([1, 1, 2, 3, 4][Number(r.gsis.split(':').at(-1)) % 5]); if (reverse) b.rows.reverse(); });
      f.replace('labels', b => { for (const r of b.rows) r.components = components([1, 2, 2, 4, 3][Number(r.row_id.split(':').at(-1)) % 5]); if (reverse) b.rows.reverse(); });
      run.replay.prepareFinal(f.world(), run.seal); return run.replay.evaluateFinal(f.loader);
    };
    const a = evaluate(false), b = evaluate(true);
    expect(a.final.arms.C0.pooled.spearman).toBeCloseTo(31 / 38, 12);
    for (const position of ['QB', 'RB', 'WR', 'TE'] as const) expect(a.final.arms.C0.positions[position].spearman).toBeCloseTo(31 / 38, 12);
    expect(b.final.arms).toEqual(a.final.arms); expect(b.final.evaluated_ids).toEqual(a.final.evaluated_ids);
    expect(b.final.world_hash).not.toBe(a.final.world_hash);
  }, 15000);
});
