# Year 1 Week 2 bootstrap v0 — proposed input and replay contract

**Home:** [TIBER-Forecast #187](https://github.com/Prometheus-Frameworks/TIBER-Forecast/issues/187) and its [bootstrap addendum](https://github.com/Prometheus-Frameworks/TIBER-Forecast/issues/187#issuecomment-5628159257).

**Status:** Joe accepted the revised Y1-P1 design as scoped. This document now includes the requested final availability-witness clarification and an exact proposed offline implementation packet, prepared under docs/spec-only authority. Input validators are not frozen or implemented; the implementation packet requires separate approval. This is not an implemented runtime contract, a model result, or a source admission decision.

**Only proposed repository change in this slice:** `docs/experiments/year1-week2-bootstrap-v0.md` in `Prometheus-Frameworks/TIBER-Forecast`. Only this prepared document was revised. No code, schema, data, other document, issue, branch, PR, provider, database, deployment or consumer was changed. No fitting, inference, statistical evaluation, fixture execution or model-output inspection was performed. Preparation remains an uncommitted document for review, not a remote branch or PR.

## 1. Decision the specification enables

The smallest v0 is a point-only, single-week forecast with two scalar model inputs: the `prior_production_rate_anchor` (prior-season generic PPR per recorded production game), and Week 1 generic PPR. It tests one learned shrinkage coefficient against two fixed challengers. The anchor is historical production evidence, not independently an availability-adjusted weekly expectation. Basic usage remains visible descriptive evidence but does not secretly acquire model weight.

The operator can approve or reject this exact contract for a later offline implementation slice. Approval of implementation would still be separate from permission to use historical source bytes in an experiment, run a 2026 candidate, or admit a result into TIBER Team.

Current executable readiness is **blocked**. Historical method selection needs compatible multi-season panels and separately authorized source use meeting either `verified_asof` or the bounded `retrospective_reconstruction_for_method_selection` requirements in section 6.3. Live 2026 separately requires independently evidenced `verified_asof` source inputs, including the prior anchor, complete Week 1 and cutoff population/schedule packages, plus a reviewed point-only consumer contract and admission before Team use. This specification establishes none of those source admissions. Historical reconstruction may inform method choice; it cannot supply live evidence authority. A missing prerequisite must produce a typed blocker, not a source substitution.

## 2. Revisions, drift and evidence inventory

Read-only revision check: **2026-09-11T16:03:43Z**. Immutable file references below use these pins. Issue and review records are observations at this check, not immutable authority.

The reconstruction/anchor revision preserved that dated audit, inventory and all source pins without refreshing remote state. For the final witness clarification and implementation packet, a bounded read-only check at **2026-09-11T19:20:07Z** confirmed Forecast main still at `e295e3de745b676df571348cb8541fb5e35e3a02`, inspected its dependency/configuration files, resolved the pinned source paths in complete repository trees, and fetched the S1 review permalink. This later check does not refresh Data/Fantasy main, #269's latest status/review, or the original data inventory; the table below remains the original dated observation.

| Surface | Revision/state | Change from the completed Y1-P0 audit |
| --- | --- | --- |
| Forecast main | `e295e3de745b676df571348cb8541fb5e35e3a02` | None. Requested new document absent at this revision. |
| Data main | `793329ff77a1764bb61cd70ce4b4b26e7180ae0c` | None. |
| Fantasy main | `e4931017d56e468dd153bc13d327ae3c25d7c691` | None. |
| Data PR #269 | Open, unmerged; head `c134a0e75e1ab5f9cc3ae76168c056c259e392e2`, base `793329ff77a1764bb61cd70ce4b4b26e7180ae0c` | Same head as the final P0 check. The PR's update clock advanced to 16:01:53Z; latest returned review still covers `75797cb`, not `c134a0e`. |
| Forecast #187 | Open; body/addendum unchanged, latest addendum `5628159257` | None. |

#269's latest patch repairs blank binary game-ID acceptance and raw game-ID reporting in duplicate inventories. The prior head's independent 180-test/Ruff receipt is not validation of the new head. New-head independent review remains pending in the inspected record. Its reader performs no acquisition or admission; a successful one-game read would not certify an entire completed Week 1 or a Forecast feature package. [S1]

### 2.1 Existing bytes and their permitted meaning

| Existing Data path | Evidence and boundary |
| --- | --- |
| `exports/promoted/nfl/player_season_coverage_v0.json` | Promoted 2021–2025 REG player-season history: 3,016 rows (633, 609, 576, 588, 610 by year). Recorded SHA-256 `d45f612b207085df00b4b080e4f55ce1abbd060dcbf30b0bee777ff833ddd8ac`. Its promotion does not grant a new weekly Forecast binding. [S2] |
| `data/processed/evidence/player_season_coverage_2021_2025.source_backed.json` | Retained candidate underlying that promotion. Inspected for historical join inventory, not substituted for the promoted artifact. Recorded candidate SHA-256 `c92404a1b519a62ee9f4b75f74662157fc8dd02b883648d4cdae694d0e021424`. Seasonal summaries and team-week counts do not contain earlier seasons' weekly stat vectors. [S2] |
| `data/processed/evidence/player_weekly_ppr_outcomes_2025.source_backed.json` | Substantive retained weekly raw-component snapshot, 6,394 records including weeks 19–22; 6,106 records in the documented weeks 1–18 window. Recorded SHA-256 `f241112115c9a625abead3410db89db6b4a8b603ce1dd663a45ff0697563e3a2`. [S3], [S4] |
| `data/processed/evidence/player_weekly_usage_2025.source_backed.json` | 6,043 records in weeks 1–18. Recorded SHA-256 `30a8e17370270e2fa5d055c7a771f19af2fe7bd89282cd2373f7704a492412cb`. Legacy zero defaults make it unsuitable as the authoritative counts source; preserve null-aware outcome counts. [S3], [S4] |
| `exports/promoted/nfl/player_weekly_ppr_outcomes_v1.json` and `player_weekly_usage_v1.json` | Six-row offline fixtures, despite the directory name. Excluded from empirical evaluation. [S3] |
| `exports/candidates/population_census/bounded_2026_population_census_v0.json` | Bounded historical-offense-plus-rookies population; not current roster membership, Week 2 eligibility, or a complete current player universe. [S5] |

These source snapshots exist as committed, fetchable Git objects. No pre-existing local data checkout or Parquet input was found in this task workspace. The table's SHA-256 values are recorded producer/receipt pins, not newly recomputed hash attestations; a later experiment must verify its actual local bytes. Existing source content was read through the authorized repository connection, with no provider fetch or source-builder execution.

The weekly snapshots lack original acquisition/publication/update clocks, original release hash and package version. Their accepted descriptive-use receipt explicitly says `forecast_allowed:false` and `refresh_allowed:false`. A current Git receipt cannot prove historical knowability. [S3], [S4] Such missing clocks do not by themselves preclude the proposed historical method-selection reconstruction class, but the full conditions in section 6.3 and separate purpose-specific source authorization remain required. No inspected snapshot is admitted or assigned that class by this revision.

### 2.2 Read-only inventory, not an evaluation cohort

The 2025 outcome snapshot has 359 Week 1 rows and 354 Week 2 rows. Exact GSIS joins from Week 1 to the 588 retained 2024 candidate season records give:

| Week 1 position | Week 1 records | Prior-ID matches | No prior-ID match | Position disagreements within matches |
| --- | ---: | ---: | ---: | ---: |
| QB | 34 | 30 | 4 | 0 |
| RB | 98 | 73 | 25 | 0 |
| WR | 150 | 121 | 29 | 1 |
| TE | 77 | 70 | 7 | 0 |
| Total | 359 | 294 | 65 | 1 |

Both weekly snapshots have zero duplicate season/week/player keys. Three Week 1 outcome records lack a usage record. The eight scoring components plus targets and rushing attempts are nonnull on all 359 Week 1 outcome records. These checks establish neither season-type proof nor admission, target-week eligibility, genuine participation denominators, historical position availability, or predictive performance. No-prior rows are not automatically rookies. Do not form a forecast population from the subset that later recorded Week 2 outcomes.

The inspected repository trees were not truncated. A 2024 eight-player weekly proof scaffold exists, but is not a compatible full replay panel. No substantive, admitted 2022–2024 weekly panel or admitted 2026 Week 1 player-week package was established in the inspected records. This is a bounded repository finding, not a claim that external data does not exist.

## 3. Target and scoring

| Property | Proposed frozen value |
| --- | --- |
| Live season / target week | 2026 / 2 |
| Observed through | Completed REG Week 1, subject to the exact availability cutoff below |
| Horizon | One NFL scoring week; never a seasonal total, next-three-weeks total or ROS |
| Positions | QB, RB, WR, TE only |
| Profile | `tiber-generic-full-ppr-v1`, version `1.0.0`, `league_specific:false` |
| Forecast profile SHA-256 | `a368b75bf5503558a4f664e0486e2c3cc75c01004d4527fd29ecaa1e247a6274` |
| Output | Point forecast; `uncertainty_status: unavailable_not_calibrated` |
| Candidate lifecycle | Candidate only; consumer admission is a separate decision |

For a complete, reconciled production row, define generic points Q:

`Q = receptions + 0.1*receiving_yards + 6*receiving_tds + 0.1*rushing_yards + 6*rushing_tds + 0.04*passing_yards + 4*passing_tds - 2*interceptions`.

No bonuses, fumbles, two-point conversions, sacks or league-specific terms are added to this fixed profile. This is an explicitly generic estimate and must not be labeled as Joe's league score. Do not trust provider `fantasy_points_ppr`, `season_ppr`, or `season_ppg` as exact equivalents. Existing Forecast reconciliation derives its target from the eight components. [S6], [S7]

Scoring input components must be finite and complete; a null is not zero. Reconcile signed yardage and integer-count fields before arithmetic. Compute Q in integer point-cents from integral components where supported. Reject non-integral component values for this v0 instead of inventing a new quantization policy. A future extension needs separate design.

Keep full precision for rates, fitting and evaluation. Emit points to two decimals using decimal ROUND_HALF_UP, including negative values; do not introduce a minimum-zero clamp. Displayed movement is emitted forecast minus emitted prior anchor, rounded to two decimals by the same rule, only when both are valid and share the exact scoring semantics. Persist full-precision model values separately in the candidate evaluation artifact so display rounding cannot change selection. Exact rational formulas below define reference semantics; numerical implementation must reproduce them within 1e-10 absolute points on bounded fixtures and record its numeric/serializer version. This tolerance is a computation check, not uncertainty.

## 4. Exact C0, C1 and C2 definitions

For player i in replay season s:

- `G_i`: count of distinct prior-season REG games carrying a source-certified complete player production record. This is a **recorded-production-game denominator**, not an inferred active/snap count. Count a complete explicit zero production record; never manufacture one for a missing week.
- `T_i`: sum of reconciled Q over exactly those G_i records, or a Data-certified season component aggregate that provably represents the same set.
- `P_i = T_i / G_i`: `prior_production_rate_anchor`, the prior-season generic PPR per recorded production game, requiring G_i >= 1 and complete source coverage accounting. Record G_i without using it to fabricate confidence. P_i is the historical basis used by C0/C2.
- `W_i`: reconciled Q for the player's one Week 1 REG game, under the status rules in section 5.
- `Y_i`: separately held Week 2 outcome, revealed only in the evaluation stage.

P_i is a deterministic historical production-rate anchor. Its recorded-production-game denominator is a deliberate Year 1 simplification: it does not model future participation or availability and is not inherently an expected-points forecast for a future scheduled week. TIBER Team must label the raw anchor as a historical basis, never as an independently availability-adjusted weekly expectation.

The C0/C1/C2 challenger outputs below are evaluated as forecasts of total points in the target scoring week. A selected C0 output can numerically equal P_i while remaining a distinct Forecast output with a target, cutoff, run identity and selection record. Neither C0 nor C2 models future availability in this v0. Target-week nonparticipation remains a scored risk, not a reason to remove a player after prediction.

| Arm | Exact point calculation | Role |
| --- | --- | --- |
| C0 | `P_i` | Prior-only challenger and possible final v0 weekly point method; numerical equality does not merge the historical anchor with the selected Forecast output |
| C1 | `W_i` | Week-1-only diagnostic challenger; never selected for live use under this v0 |
| C2 | `P_i + alpha*(W_i - P_i)` | Combined candidate; one global alpha for all supported positions |

When C0 is selected, preserve three distinct meanings: historical basis `prior_production_rate_anchor`; selected output `C0 weekly point forecast`; and present Week 1 observed evidence that did not earn predictive weight under this v0 selection rule. W_i remains required by the shared live cohort even though it contributes no numeric weight to C0. Movement versus the anchor is `0.00` only when the valid anchor and selected C0 forecast both exist under the same scoring semantics. A missing or invalid operand yields null movement with its typed reason, never an inferred zero.

### 4.1 Learning alpha

Fit **once**, using eligible 2022 and 2023 training rows only. No grid search, per-position coefficients, intercept, extra features, agent-proposed percentages or current-season tuning.

Let `d_i = W_i - P_i`. For each supported position p, let n_p be its count in the combined training set and `a_i = 1/n_p`. Minimize `sum_i a_i * (Y_i - P_i - alpha*d_i)^2`, constrained to `0 <= alpha <= 1`.

When `D = sum_i a_i*d_i^2 > 0`, use `alpha = clip(sum_i a_i*d_i*(Y_i-P_i) / D, 0, 1)`. The 1/n_p factors equalize each position's contribution to fitting; they are fixed evaluation-design weights, not invented football weights. If D is zero, record `update_not_identifiable`, set the mathematical C2 challenger to C0, and make C2 ineligible for selection. If any required value is nonfinite, reject the fit rather than dropping it silently.

Freeze alpha, training membership, numeric policy and all artifact hashes before opening validation labels. No refit with 2024 or 2025 is allowed in this v0. A later live C2 would reuse this exact historically tested coefficient; replacing it with a fit on more seasons would be a different candidate requiring evaluation.

### 4.2 Minimal model and context fields

Only P_i and W_i enter point calculation. Position enters cohort accounting and the fixed fitting objective. Prior sample size enters availability and subgroup reporting. No player/team identifier is a numeric or categorical model predictor.

Targets, receptions, carries, passing/receiving/rushing production and prior sample counts may be shown as separately sourced observations. They do **not** enter C2 as additional predictors. Passing attempts may be displayed only when supplied by an admitted source; they are absent from the retained 2025 weekly outcome wrapper and are not required for v0.

No route, participation, first-read, red-zone, air-yards-total, Teamstate, rookie-alpha, age, injury, matchup-strength, special-teams or operator-film variable enters this candidate. Historical production has the strongest existing reusable Forecast path; its current seasonal binding is not this weekly binding. Teamstate's existing comparison records a failed sanity control; the rookie mirror is inert. Those findings do not justify new activation or make these families prerequisites. [S8], [S9], [S10]

## 5. Population, missingness and identity

Data owns a cutoff-bound population ledger for each replay/live season. The proposed v0 population includes source-listed QB/RB/WR/TE players in active, practice-squad, injured-reserve, PUP, NFI or suspended team-roster states at cutoff. These states determine roster inclusion only, never expected workload or medical clearance. Include source roster rows with unresolved position/identity/status as unresolved ledger entries; count known other-position exclusions separately. Exclude positively evidenced free agents or released players without a team assignment at cutoff, with an exclusion receipt. Absence from a partial source is not proof of exclusion. Data must publish a reviewed mapping from its provider's actual roster vocabulary to these categories before package acceptance; an unknown provider code remains unresolved. The same inclusion rule applies across replay seasons and 2026. An independently published schedule binds each eligible team's Week 2 game. Final Week 2 participation, Week 2 statistics, fantasy ownership and later roster changes must not determine initial membership.

Use exact canonical GSIS identity with retained provider identity and evidence. No fuzzy names, new local namespace or inference from a display string. Old-team versus new-team differences across seasons are legitimate historical context and do not break a GSIS prior join. Conflicting identity, multiple target-week team assignments, or disputed position at cutoff require Data disposition; Forecast must not choose whichever record produces a forecast.

One ledger row per population row is mandatory. Preserve all applicable typed reasons and use this precedence for the primary state:

1. `identity_unresolved` or `identity_conflicting`;
2. `eligibility_unresolved`, then `population_ineligible` (e.g. a verified bye/no target game);
3. `position_unresolved` or `unsupported_position`;
4. `prior_unavailable`;
5. `week1_unavailable`;
6. `forecast_available`.

Do not map conflicting evidence to ordinary absence. Duplicate canonical identities in a supposedly one-to-one population or contradictory source revisions invalidate the package; they are not resolved by last-write-wins. Source identical duplicates may be collapsed only under a declared Data deduplication policy that preserves their receipt and reports the collapse.

| Case | v0 behavior |
| --- | --- |
| No prior-season NFL production | P_i unavailable; C0/C2 unavailable. Record no-prior, not zero or a veteran mean. C1 may appear only in its separate diagnostic cohort. |
| Prior G_i between 1 and 7 | Include when otherwise complete; label `weak_prior`. No hand-set alpha adjustment. G_i >= 8 is `established_prior` for reporting only. |
| Week 1 explicitly inactive/did not play | W_i = 0 only with source-backed final game/participation evidence that certifies zero applicable production; otherwise unavailable. Keep `did_not_play` distinct from `played_zero`. |
| Played with explicit zero production | W_i = 0 only when all eight components are certified complete zeros. Zero opportunity is not proof of zero passing/rushing/receiving points without these components. |
| Missing Week 1 row | `week1_unavailable`, never inferred injury, bye, inactivity or zero. |
| One scoring component missing | Q unavailable; no partial point total. Independent descriptive observations may remain available. |
| Prior/current positions disagree | Require cutoff-valid source resolution or withhold. Do not silently borrow the newer label. |
| More than one counted Week 1 game | `unsupported_week1_game_structure`; no implicit summation or per-game reinterpretation. |
| Player later inactive, released or traded before Week 2 | Keep the originally frozen population and forecast. Bind the realized outcome later by canonical identity and declared week; never remove a miss using later information. |
| Postponed/canceled Week 2 game | Keep population row. Outcome rules require Data's final week-assignment/completion evidence; unresolved outcome is unscored and reported, not zeroed. |
| K/DST/IDP | Explicit unsupported domain; no offensive-model forecast. |

The primary comparison cohort is fixed from cutoff-time eligibility plus complete P_i and W_i, **before labels are opened**. Score C0/C1/C2 on the same label-resolved subset of that fixed cohort. Show any additional C0-only/C1-only coverage separately; it cannot improve the shared-cohort comparison by changing its denominator. Live v0 uses the same primary-cohort requirements even if C0 is selected. Broader prior-only fallback coverage is outside this specification.

## 6. Temporal contract and replay worlds

### 6.1 Proposed seasons and ordered access

| Stage | Prior seasons | Week 1 inputs / Week 2 labels | Status of required weekly panels |
| --- | --- | --- | --- |
| Train alpha | 2021, 2022 | 2022, 2023 | Not established as compatible admitted panels |
| Validation | 2023 | 2024 | Only a limited proof scaffold located; not sufficient |
| Final evaluation | 2024 | 2025 | Retained components exist; source-use authorization and verified-asof/reconstruction eligibility unresolved |
| Live candidate | 2025 | 2026 Week 1 / Week 2 labels forbidden at generation | Admitted Week 1 package not established |

These are proposed fixed seasons, not supported-coverage claims. Do not substitute seasons, random-split players/weeks, reuse seasonal fitted coefficients, or use 2025 alone to fit and validate. If the fixed panels cannot be supplied, stop with a source-gap report; a different replay design needs an explicit amended spec.

The 2025 snapshot is already accessible and has been used elsewhere in TIBER. Call it **protocol-reserved final evaluation**, not a never-seen or independently blind discovery holdout. No performance-dependent change to this design is permitted after its results are opened. Record all prior outcome exposure relevant to implementation/review. This specification uses inventory/coverage counts and does not claim outcome-blind research novelty.

### 6.2 Cutoff semantics by evidence purpose

For every replay/live world, Data must supply the complete expected Week 1 REG game set, evidence of completed games, and an exact canonical UTC `forecast_cutoff` after whole-Week-1 completion and before the independently evidenced earliest Week 2 kickoff. Stop if a whole-Week-1 window cannot fit. Historical reconstruction may use later-retained game/schedule evidence to establish this event order without claiming that the retained source version was published by the historical cutoff; it must satisfy section 6.3's restrictions on features and cutoff context.

For `verified_asof` inputs, additionally require independently evidenced finalization of the consumed source records and `fact_available_at <= forecast_cutoff` for the exact source version. For live 2026, **every source input must meet this rule**, including the 2025 prior, Week 1 observations, population, identity/position context and schedule. Require `generated_at < earliest_week2_kickoff` for a live candidate. The decision/configuration freeze and independently attributable run authorization must also predate that kickoff. A historical reconstruction's processing/run time is its actual later timestamp; never backdate it to appear to be a historical production run.

**Availability witness clarification:** a trustworthy, independently evidenced retrieval receipt for the exact source bytes at or before the relevant live cutoff may establish that those bytes were available **no later than that retrieval time**. The original publication timestamp may remain unknown/null. The receipt must bind an independently trusted retrieval time, exact source identity/version and byte digest; the accepted source-version/cutoff binding must verify that the consumed bytes, or their declared deterministic derivation lineage, are those witnessed bytes. Record the witness kind (`publication` or `retrieval`), witness time and receipt reference separately from publication, retrieval, event/effective, processing and admission times. For this comparison, `fact_available_at` is the independently evidenced availability upper bound, not an invented earliest publication time. A retrieval witness uses its verified retrieval time as that bound and requires `fact_available_at <= forecast_cutoff`, preserving the existing equality boundary.

The retrieval witness proves availability only. It does not establish completeness, scoring correctness, pre-cutoff event semantics, source admission or consumer authority. An accepted source-version/cutoff binding and purpose-specific admission remain mandatory. A self-declared timestamp, relabeled reconstruction receipt or matching values cannot establish live eligibility. If the only witness is a retrieval after cutoff, it cannot prove availability by cutoff; do not backdate it. Missing original publication time alone is not a rejection when a qualifying independent retrieval witness and all other live gates are satisfied.

**The exact 2026 cutoff remains null/unfrozen in this specification** because neither the full-week completion evidence nor the required Week 2 schedule receipt has been verified here. This is a declared input parameter with a blocking state, not permission to use the computer clock or the old Week 1 constant. Before an experiment/live gate, the exact UTC instant, evidence purpose and source refs must be fixed in a separately authorized manifest. Each historical world also needs its exact reconstructed cutoff; missing original publication clocks must remain explicit rather than being synthesized.

Keep event/effective time, original publication time, retrieval time, processing time, admission time and source revision separate. Event time alone does not prove knowability. For a `verified_asof` schedule, the game may occur after cutoff, but an independently evidenced publication or qualifying retrieval witness for the exact schedule version must establish availability by cutoff. A Git commit date or source `generated_at` value alone cannot establish that witness. Historical reconstruction permits missing original publication/availability clocks subject to its limited claims; live verified-asof permits unknown publication time only when availability is independently witnessed, including by qualifying retrieval.

Input snapshots must preserve revisions and disclose missing revision history. No feature may depend on information known only after that world's Week 1 cutoff. A known post-cutoff correction is excluded from features in both historical classes; later snapshot retention alone is not proof of such a correction and is not proof of original availability. Target-season Week 2 information is excluded from the feature set, including realized statistics, final participation, later roster facts and target-season summaries/denominators incorporating Week 2. This does not exclude completed prior-season games from the unchanged P_i formula. Later finalized label revisions are allowed only in the separate evaluation ledger, which retains their revisions and never overwrites the forecast.

### 6.3 Historical reconstruction eligibility and strict live eligibility

Declare evidence purpose (`historical_method_selection` or `live_2026_forecast_inputs`), source season, cutoff and `historical_availability_class` per artifact/row. Retain the existing class field name for continuity; `verified_asof` is always relative to the explicitly bound cutoff, including the live 2026 cutoff when used there.

| Class | Historical Week-1 → Week-2 method selection | Live 2026 source-input eligibility |
| --- | --- | --- |
| `verified_asof` | Eligible subject to all other gates and scoped source authorization; exact source version and independent availability at/before that world's cutoff are evidenced | Required for every live source input, with independent evidence bound to the live cutoff and separate live admission |
| `retrospective_reconstruction_for_method_selection` | Eligible only under the conditions below and separate historical-study source authorization | Never eligible; historical status or receipts cannot supply live evidence |
| `retrospective_reconstruction` | Insufficient by itself; an unqualified later snapshot does not establish the method-selection conditions | Never eligible |
| `unresolved` | Ineligible; event/source semantics or revision cannot be adequately bound | Never eligible |

`retrospective_reconstruction_for_method_selection` is permitted for this historical bootstrap-method study only when all of the following hold:

1. Production features represent completed-game facts from the prior season or Week 1, with governed source semantics and the unchanged scoring/recorded-production-game denominator rules.
2. Target-season Week 2 information is excluded from the feature set and feature/population construction. Historical labels remain isolated under the existing 2022–2023 training, 2024 validation, sealed 2025 final-evaluation order.
3. Source, snapshot and revision limitations are recorded, including missing original publication/acquisition clocks and any unavailable revision history. Known post-cutoff corrections are excluded; an unresolved dependency on later information blocks the affected input.
4. No feature depends on information known only after the historical Week 1 cutoff. Reconstructed identity, position, roster membership and schedule context must refer to the state effective at that cutoff, supported by source evidence; later roster/position labels, target-season Week 2 participation, survivor selection and target-season full-season aggregates cannot substitute for that state. Missing original publication timing alone is permitted for this historical class; missing support for the cutoff state is not.
5. The replay, reports and method-selection receipt explicitly say **reconstructed historical method-selection study**, not fully verified historical production replay. Such evidence can demonstrate method behavior and support the section 8 selection decision, but it does not prove exact historical availability at the original cutoff.

If any contributing historical input or population/context fact uses this class, the combined study and selected-rule lineage retain that reconstruction label and its source/revision limitations. Verified rows cannot upgrade the mixed study to fully verified historical availability. Retrospective Week 2 labels remain acceptable when their final-outcome semantics and revisions are governed; no claim is made that labels were available before Week 2.

Historical method selection and live input eligibility are separate decisions. A rule selected by an authorized reconstructed study may inform a later, separately authorized 2026 candidate. Its historical evidence class must remain visible as method lineage; it grants no authority to the live source-input packages. Every live source input, including the historical prior used for 2026, still requires independently evidenced `verified_asof` semantics at the live cutoff and purpose-specific admission.

**Negative requirement:** historical retrospective-reconstruction status must never be reused or relabeled as live 2026 evidence. Changing season, purpose, class text, timestamps, wrapper, receipt reference or file path cannot satisfy the live gate. Matching values or a selected rule do not establish live source availability. Any separately proposed live artifact requires its own independently evidenced source-version/cutoff binding and admission; no historical receipt or reconstruction label can stand in for them. This revision grants no source use, source admission, study execution or live inference authority.

## 7. Exact Data-owned package requirements

The logical interfaces below are **proposed requests to Data**, not adopted Data schemas or authorized new artifacts. Data must choose and review physical paths/versioned contracts under a separate task. No database is required by the Forecast interface: durable, immutable, content-addressed files with accepted custody can satisfy it. Selecting an actual durable store remains Data-owned. Do not widen #269 into a Forecast builder.

### 7.1 Logical package inventory

| Logical ID | Required contents | Grain |
| --- | --- | --- |
| `bootstrap_prior_v0/<s>` | Prior-season eight scoring components or certified aggregates, recorded production-game denominator and enumerated membership proof, canonical identity, historical position/team context, nulls and coverage accounting | Player + prior season + REG |
| `bootstrap_week1_v0/<s>` | Exact Week 1 components, descriptive targets/carries where supported, game completion, played-zero/DNP/unresolved distinctions | Player + season + REG + game, mapped to week 1 |
| `bootstrap_population_v0/<s>` | Cutoff roster-based population, canonical identity resolution, supported position, cutoff-valid target-week team assignment, eligibility state and evidence | Population row; one-to-one canonical identity where resolved |
| `bootstrap_schedule_v0/<s>` | Complete expected Week 1 set; target Week 2 schedule, separate publication/retrieval clocks and availability-witness evidence, official week/game mapping and completion/postponement states | Game + source revision |
| `bootstrap_week2_labels_v0/<s>` | Complete finalized target outcomes or typed missing outcome, participation evidence needed to certify DNP zero, target-week mapping and later corrections | Frozen population row + target week; separate label package |
| `bootstrap_input_admission_v0/<s>` | Exact input/policy/code hashes, Data consumer-purpose decision, evidence class/cutoff, independent review and Forecast-side binding refs; historical method-selection scope and live 2026 source-input scope are distinct | Receipt keyed to exact package set and permitted purpose |

Historical s is 2022–2025; live s is 2026. The live package excludes labels entirely. Historical label packages must be physically/logically inaccessible to feature assembly and prediction functions; separate arguments or files alone are insufficient if a loader exposes all labels during selection. A future harness must enforce the stage boundary and record access.

### 7.2 Required manifest/receipt fields

Every package declares:

1. Contract ID/version; logical ID; owner repository and exact commit; immutable content URI/path; byte count, SHA-256 and serialization version.
2. Provider/dataset identity, original source-version locator and hash where evidenced; source license/attribution basis with scoped reuse permission; package/reader/transform versions. Unknown original values remain null and affect readiness.
3. Separate source event/effective, publication, retrieval, processing/generation and admission times with explicit timezone/normalization rules. Record availability-witness kind, independently evidenced time/upper bound, receipt identity/hash, exact witnessed source-version/byte digest and accepted cutoff binding; preserve derivation lineage to consumed bytes. Original publication time may remain null even for live `verified_asof` when a trustworthy independent retrieval witness establishes availability by cutoff. A live availability bound cannot be null or self-declared. Historical reconstruction may lack such a bound only under section 6.3's separate limits. Witness verification and purpose-specific admission remain separate.
4. Season, REG type, game/week mapping, exact cutoff, evidence purpose and historical availability class; complete expected game set and observed/finalized/unresolved game sets. Preserve per-input class and any reconstruction designation of the aggregate study; a method-selection receipt is not a live input receipt.
5. Population definition and census hash; row grain/key; expected, present, absent, duplicate, conflicting, excluded and unresolved counts; position and cohort counts. Empty/truncated subsets cannot self-declare whole-week coverage.
6. The eight generic scoring components with per-field observed-zero/null/absent status, units and source locator; denominator definition and member game IDs; non-model context fields marked separately.
7. Canonical GSIS plus retained source identity, mapping version/hash, confidence tier and conflict disposition; historical team and current cutoff team separated. No use of the old bounded census as evidence of current eligibility.
8. A passed scoring reconciliation binding the exact Forecast profile hash to the exact consumed input hashes. Recompute from components; disclose discrepancies with provider totals. The existing Data/Forecast profile-hash equivalence decision is scoped to its frozen versions and does not admit new weekly inputs. [S7], [S11]
9. Separate immutable admission/authority receipts naming consumer purpose, permitted fields/windows/uses, evidence class, source and manifest hashes, operator decision ref and independent review ref. Historical method-selection authorization must explicitly cover reconstructed evidence when applicable; live 2026 admission requires independently evidenced `verified_asof` source inputs. Neither this revision nor a historical-study receipt supplies that live authority. `source_backed` and file location cannot self-grant eligibility.
10. Null/missing/conflict policy, source revision retention, deduplication policy, coverage validation report and independently checkable row lineage.

### 7.3 Readiness rules

- Missing source file, hash mismatch, unresolved whole-week completeness, untrusted or wrong-purpose admission, wrong season/profile, conflicting identity or a feature depending on information known only after cutoff rejects the run package before fitting/inference. Later retention or missing original availability clocks alone does not reject an otherwise eligible historical reconstruction; it does reject a claim of `verified_asof` without independent evidence.
- Historical packages must meet either `verified_asof` or all `retrospective_reconstruction_for_method_selection` conditions and retain their limitations through selection. Live 2026 source packages must each meet independently evidenced `verified_asof`; a reconstructed historical package cannot pass by reuse or relabeling. Learned-rule lineage is recorded separately from live input admission.
- Package completeness and per-player completeness differ: a full source extract may honestly leave one player's prior unavailable. Preserve that population row and its reason rather than rejecting every other valid player. Conversely, a truncated extract is a package failure, not a collection of invented player absences.
- Row-level supported observations may be retained for diagnostics when a joined derivation is blocked; they cannot authorize a forecast.
- For 2026, admission must explicitly cover Forecast feature use of the prior and Week 1 plus cutoff population/context/schedule evidence, not only Research charting, Team descriptive display or historical method selection.
- If v0 is satisfied from a governed weekly box-score path, possession/route/special-teams interpretation is unnecessary. If PBP is selected as the source, its separately governed complete-game receipts and aggregation semantics must satisfy every requirement above. A bounded event sample never substitutes for complete game statistics.

## 8. Future evaluation and deterministic selection

This section specifies future work only; no metrics were computed in this slice.

Require at least 20 label-resolved primary-cohort rows per position in **each** training season and in each validation/final season, and at least 95% label resolution of the pre-label primary cohort in each position/season. These are conservative design sufficiency thresholds, not proof of statistical significance. Failure means `bootstrap_study_inconclusive`; do not pool away a failed year/position or silently reduce supported positions.

For every arm and each season, report:

- player-weighted MAE and RMSE; equal-position macro MAE and macro RMSE (arithmetic mean of the four position-specific metrics);
- Spearman rank correlation using midranks for ties; null with a reason for constant/insufficient arrays;
- per-position MAE/RMSE, sample counts, and paired errors;
- available forecasts divided by the full frozen population and by the resolved/eligible/supported population; each denominator named;
- primary-cohort count, evaluated count, label resolution and excluded/unavailable counts by reason;
- established-prior (G >= 8), weak-prior (1–7), no-prior, changed-team, played-zero and DNP cohorts where source-supported; empty groups stay empty, and unsupported classification stays unknown;
- C2 minus C0 and C1 minus C0 paired MAE/RMSE differences on identical members; top absolute misses for diagnosis only, never retroactive repair.

Every report also records historical evidence classes, reconstruction source/revision limitations and the cutoff assumptions used. A reconstructed study supports a method-behavior comparison and selection under this protocol; it does not establish verified historical production performance at the original publication cutoff.

Account for players sharing a team/game: errors are not independent observations of significance. Report game counts and per-game paired-error summaries; make no p-value, confidence-interval or calibration claim in v0. No synthetic intervals or probabilities are produced.

Selection sequence:

1. Verify all historical source-use, temporal, scoring, cohort and sufficiency gates, using the historical eligibility rules in section 6.3. Either `verified_asof` or qualified `retrospective_reconstruction_for_method_selection` may support this step; neither grants live 2026 input admission. Train and freeze alpha from 2022–2023 only.
2. Open 2024 validation labels. C2 passes only if macro MAE is strictly lower than C0, macro RMSE is no higher, and no position's MAE is higher than C0. Comparisons use unrounded metrics; equality does not count as MAE improvement.
3. Seal the validation result and unchanged method/configuration before opening 2025 final labels. Report all three arms on 2025 even if C2 failed validation; no parameter/model change is allowed.
4. C2 is eligible only if it passed validation and the same comparisons pass on 2025. It must also have identifiable alpha > 0. Otherwise choose C0 if all package, temporal and sufficiency gates passed. C1 is never a live selection. A large C1 advantage is a recorded limitation/research question, not permission to change the selection rule.
5. If any evidence/sufficiency gate failed, choose neither arm: `bootstrap_study_inconclusive`. An honest prior-only performance result is distinct from a failed evaluation.

The result identifies `c2_update_supported`, `c0_prior_only_retained`, or `bootstrap_study_inconclusive`, with exact method/source hashes and retained historical evidence class/limitations. These are method-selection outcomes, not live input eligibility. They grant no run or consumer authority. A separate operator decision and independently evidenced, admitted live inputs are still required before a 2026 candidate.

If C0 is selected, the historical basis remains `prior_production_rate_anchor`, while the selected Forecast output is a `C0 weekly point forecast` numerically equal to P_i. Team must state: “Week 1 was observed but did not earn predictive weight under this v0 selection rule; it did not move this forecast.” This describes the protocol outcome, not proof that Week 1 contains no predictive information. Movement is `0.00` only for a valid available anchor/selected-C0 pair under identical scoring semantics; otherwise it is null with the applicable reason.

## 9. Candidate artifacts and proposed Team packet

### 9.1 Forecast-owned artifacts

A future execution would emit an immutable candidate manifest, population-row ledger and fitted-rule artifact. The rule artifact pins alpha or selected C0, formula/numeric version, training member IDs and input hashes, validation/final report hashes, selection decision and historical evidence classes/limitations. The manifest separately pins target, cutoff, code, configuration, profile, census, source/admission receipts and their purposes/classes, active/inactive families, generation time and row-file hash. Historical rule lineage remains distinct from the independently verified live source-input bindings. It must not contain its own digest; admission later binds the complete manifest and row bytes from outside them.

Available candidate rows contain canonical identity, full-precision P/W/point, emitted values, method ID and all source refs. P is typed as `prior_production_rate_anchor`, W as Week 1 observed evidence, and point as the selected weekly Forecast output, even when selected C0 equals P. Unavailable rows contain null forecasts, typed complete reasons and supported independent observations. Exactly one output row per census row; canonical sorting by population_row_id. Reject unknown contract fields and nonfinite numbers. Initial candidate fields are `candidate_only:true`, `production_ready:false`, `consumer_eligibility:not_eligible_pending_admission`; actual Week 2 outcomes are absent/null. Validation is not self-admission.

### 9.2 Proposed semantic contract

Proposed ID: `tiber_team.weekly_point_forecast`, proposed version `0.1.0`. These are design names, not an existing deployed schema. Forecast owns the meaning; Fantasy would vendor exact reviewed contract bytes later. This packet carries only the selected weekly point and context, not rankings, replacement values or transaction instructions.

| Field/block | Required semantics |
| --- | --- |
| `contract`, `contract_version` | Exact proposed identity; reject unsupported versions |
| `status` | `available`, `unavailable`, or `stale`; only admitted, validated, request-matching evidence can be available |
| `player` | Population row ID, canonical GSIS, separately admitted provider mapping ref; names/team labels are untrusted display data |
| `target` | `season:2026`, `week:2`, `horizon:single_scoring_week`, `observed_through_week:1`; no ROS alias |
| `scoring_profile` | Exact ID/version/hash; generic full PPR, `league_specific:false` |
| `forecast_cutoff`, `generated_at` | Distinct canonical UTC instants, copied from the verified manifest; never refreshed by page rendering |
| `freshness` | `basis:frozen_preweek_snapshot`; consumer-owned receipt pins an exact `expires_at` and any revocation binding. Missing expiration policy prevents admission. This is not a live injury/roster freshness claim |
| `run` | Run ID, method/model ID and version, code/configuration hashes, manifest/rows/rule hashes |
| `method_evidence` | Historical study class(es), selection/report refs and reconstruction source/revision limitations; separate from live source-input eligibility, never represented as verified historical production availability when reconstructed |
| `prior` | Value, basis `prior_production_rate_anchor`, formula `T_i/G_i`, season, recorded-production-game denominator/count semantics and source refs; null with typed reason if unavailable. Historical production basis; future participation/availability is not modeled |
| `week_1_observed` | Q and permitted raw observations, observation states and individual source refs; remains present when C0 is selected. Record method-use explanation `observed_no_predictive_weight_under_v0` for C0 without altering the observed value or state |
| `forecast` | Selected weekly point or null, explicitly identified as C0 or C2 with target/cutoff/run binding. C0 may equal the anchor numerically but is a separate Forecast output. Future availability is not modeled; `uncertainty_status:unavailable_not_calibrated`; floor/median/ceiling/confidence/probabilities all null, never inferred from the old heuristic service |
| `movement` | `versus_prior` is emitted selected Forecast minus emitted prior anchor only when both are valid, the forecast binds that same anchor, and their exact scoring profile and numeric/unit semantics agree. Selected C0 yields `0.00` with reason `c0_selected_week1_did_not_move_forecast`; invalid/missing operands yield null with typed reason. Record formula version. C2's sole numeric driver is alpha*(W-P), not a causal explanation of football |
| `feature_families` | Active production bootstrap; each richer family explicitly inactive/not admitted. Context-only counts marked non-model |
| `admission` | Exact externally trusted consumer receipt and live source-input binding refs; every live source input requires independently evidenced `verified_asof` at the live cutoff and purpose-specific admission. Historical reconstruction/selection receipts cannot satisfy this block; request bytes cannot supply their own authority |
| `limitations`, `status_reasons`, `source_refs` | Structured codes plus source-backed explanation; preserve historical reconstruction/missing-clock limitations separately from live verified-asof evidence, recorded-production denominator, absence of availability modeling, weak prior, identity tier, generic scoring and inactive families |

`available` requires finite point/prior/W, correct identity/target/profile, all independently evidenced live `verified_asof` input gates, valid candidate bytes and separately authorized consumer admission. Unknown identity, mismatched week/profile, missing or altered bundle/receipt, reconstructed historical evidence offered as live proof, uncalibrated populated ranges, or conflicting source lineage returns a typed unavailable response. A structurally valid publication at or after its externally pinned `expires_at`, or with a trusted revocation, is `stale` and has null current forecast/movement; archive access is a separate presentation context. The first Week 2 kickoff freezes generation but does not by itself expire an already frozen forecast: the consumer may display that preweek estimate during the target week, clearly labeled with its cutoff, until its separately accepted expiry. The expiry is presentation policy, not permission to use later inputs or revise a forecast. Refusal never substitutes FORGE, a cached other-week point, zero, seasonal totals or the old heuristic card.

Consumer requests must bind a canonical player and target, or an admitted mapping from an exact Sleeper ID. Recheck exchange identity and profile; matching a display name is insufficient. Show the generic-PPR label even in half-PPR/custom leagues, and do not claim league-adjusted points. Show the historical anchor, selected weekly Forecast, Week 1 observation and movement as distinct concepts. For C0, explain that Week 1 was observed but did not earn predictive weight and did not move Forecast; never present the raw anchor alone as an availability-adjusted weekly expectation. Observation, historical basis, deterministic arithmetic, model inference, manager judgment and agent reasoning remain separate. Operator text cannot alter method, cutoff, input admission or source trust.

### 9.3 Preserve existing contracts and gates

The #176 publication validator is hard-scoped to 2026 Week 1 and a preseason path that excludes current-season results. Do not change its constants, repurpose its receipt or backdate a publication. Reuse only its explicit trust/canonicalization patterns in a separately reviewed weekly bootstrap contract. [S12]

The existing FFI weekly-card v1 requires numeric ranges/confidence; point-only output cannot be forced into it with zero-filled or invented fields. It is already vendored in Fantasy. Add a separate reviewed point-only contract later; do not silently weaken its schema. [S13], [S14]

Fantasy's ordinary meaningful-input rule requires games_sampled >= 2 and a positive signal, with a cohort threshold of max(10, floor(0.6*n)). This one-game candidate does not satisfy it. A future explicitly admitted bootstrap artifact is a distinct consumer source; it cannot set games_sampled to 2 or bypass the ordinary gate under its name. [S15], [S16]

Team's existing packet currently requests next-three-weeks, next-six-weeks and ROS and returns unavailable. A future consumer slice must explicitly add the single-week horizon; it may not populate those longer horizons from this point. The current public compiler remains unchanged. [S17]

## 10. Future verification contract and implementation boundary

No tests below were executed here. A later offline implementation should prove at minimum:

- component scoring, negative points, exact profile binding and null-versus-zero rejection;
- recorded-game denominator membership, zero denominator, partial prior and no-prior withholding;
- C0/C1/C2 formulas, alpha clipping, denominator-zero case, fixed position weighting and deterministic serialization;
- distinct historical `prior_production_rate_anchor`, Week 1 observation and selected weekly Forecast semantics; selected C0 preserves W as observed with no predictive weight, equals valid P numerically and yields `0.00` movement only for the same valid anchor/profile binding; missing, invalid or mismatched operands yield null movement, and the raw anchor is never labeled availability-adjusted;
- no labels in features, no 2024/2025 access during fitting, no final-label access before sealed validation, and no current-2026 data in historical training;
- exact identity/context joins, legitimate team changes, position conflict, duplicates, unresolved eligibility, delayed game and explicit DNP versus missing-row cases;
- cutoff equal-to-boundary acceptance for verified-asof input facts, rejection of features depending on information known only after cutoff, purpose-specific schedule/publication evidence and whole-week completeness; qualified later-retained historical snapshots with disclosed missing original clocks may support method selection under section 6.3, while live inputs require independent verified-asof evidence;
- a positive retrieval-witness case: original publication time is null, a trustworthy independent receipt binds the exact source bytes/version to a retrieval time at or before the live cutoff, the accepted source-version/cutoff binding and purpose-specific admission are supplied independently, and every other required input gate passes. Accept the availability check without inventing publication time or merging retrieval, event and admission clocks. A declared derived input must also bind the witnessed bytes through its verified deterministic lineage. Exercise both a strictly earlier retrieval and the existing equality boundary; this is a synthetic validator requirement, not admission of any real source;
- a negative class-reuse case: offer an otherwise valid historical `retrospective_reconstruction_for_method_selection` package or its receipt as live 2026 source evidence, including variants that relabel season/purpose/class/timestamps or rewrap identical values; reject with unavailable live input/forecast status because independent live source-version/cutoff evidence and live admission are absent. Keep reconstruction visible in learned-rule lineage; that lineage must never satisfy the live source-input gate;
- all three arms scored on identical cohort membership, metric formulas, deterministic tie handling, coverage/label-resolution accounting and every selection outcome;
- candidate/consumer separation, external trusted admission, digest tampering, identity/week/profile mismatch, stale output, null uncertainty, no fallback and point-versus-ROS rejection.

### 10.1 Exact proposed offline implementation slice — separate approval required

Sole proposed write repository: `Prometheus-Frameworks/TIBER-Forecast`. Planning base: `e295e3de745b676df571348cb8541fb5e35e3a02`, confirmed in section 2. The eight proposed files below are absent at that base. This packet proposes **eight new TypeScript files only**, with no edits to existing runtime, contracts, manifests, package files, lockfile or public exports. It implements internal Forecast validation of the proposed logical packages; it does not adopt a Data schema or publish a Team contract. No files in this table are created by the present docs-only task.

| Exact proposed path | Responsibility and boundary |
| --- | --- |
| `src/experiments/year1Week2Bootstrap/input.ts` | Internal input/evidence/validated-row types and runtime validators for sections 3, 5–7. Accept injected unknown package values plus separately supplied trusted witness/binding/admission context; check exact shapes, digests, purpose, cutoff, source lineage, completeness, scoring reconciliation refs, identity, denominator membership and typed missingness. Build the frozen primary cohort before labels. Preserve publication/retrieval/event/admission clocks and reconstruction class. No provider reader, trust-root creation, admission issuance or auto-classification of real snapshots. |
| `src/experiments/year1Week2Bootstrap/shrinkage.ts` | Pure component-to-cents scoring, P/W derivation, C0/C1/C2 calculations, one global bounded alpha from 2022–2023, and the existing full-precision/ROUND_HALF_UP policy. Preserve P as the historical anchor. Reject invalid/nonfinite arithmetic and unsupported input structure; no seasonal runner, live weights, extra predictors or uncertainty estimator. |
| `src/experiments/year1Week2Bootstrap/replay.ts` | In-memory staged historical replay and section 8 reporting/selection. Accept only validated stage-specific data: fit/freeze training, evaluate 2024, seal validation and unchanged configuration, then evaluate 2025. Freeze cohorts and challenger predictions before exposing each stage's labels. Record access/transition receipts and hashes; reject out-of-order or forged transitions. Compute the specified metrics, position/cohort/game/coverage reports and unchanged conservative selection decision. No all-season label loader, filesystem loader, live-2026 run entry point or CLI. |
| `src/experiments/year1Week2Bootstrap/artifacts.ts` | Pure builders/validators and canonical byte serialization for candidate manifest, row ledger, selected-rule artifact and replay reports in section 9.1. Preserve source lineage, anchor/observation/Forecast distinctions, valid C0 movement, null uncertainty, inactive families and candidate-only status. Return bytes/hashes to the caller; no file publication, consumer adapter, admission receipt creation or self-admission. |
| `tests/year1Week2BootstrapInput.test.ts` | Synthetic package, witness, trust-binding, identity, completeness, missingness and cutoff checks. |
| `tests/year1Week2BootstrapShrinkage.test.ts` | Hand-checkable synthetic arithmetic, denominator, alpha, rounding and C0 semantic checks. |
| `tests/year1Week2BootstrapReplay.test.ts` | Synthetic stage isolation, identical cohorts, report accounting, sufficiency and all selection outcomes. |
| `tests/year1Week2BootstrapArtifacts.test.ts` | Synthetic candidate invariants, immutable lineage, exact-byte determinism, digest tampering and output refusal checks. |

The trusted evidence context is supplied independently of the package being validated. A package's own `trusted`, `verified_asof` or `admitted` claim is never sufficient. Tests may inject explicitly synthetic trust records to exercise acceptance/refusal, but they confer no real authority. Label access is a runtime-enforced stage boundary, not only a TypeScript cast or an `output_seen:false` string. No function used for feature assembly or challenger prediction receives labels; training labels are provided only to the training calculation, and later labels only to their permitted evaluation stage. A later validated live package may be checked as a contract shape, but this slice has no orchestration that generates a 2026 forecast.

### 10.2 Existing dependencies and bounded reuse

All dependencies below are read-only reuse at the planning base, not permission to edit them. No new external package is proposed.

| Existing dependency | Exact reuse or limitation |
| --- | --- |
| [src/contracts/genericFullPprProfile.ts](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/contracts/genericFullPprProfile.ts) | Reuse the profile ID/version/hash, weights, `resolveGenericFullPprCompatibility` and `validateScoringReconciliationEvidence`. The last function validates a reference/binding; it does not prove component totals or confer source admission. New input/scoring code must perform the required component and trusted-receipt checks. |
| [src/serialization/canonicalForwardArtifacts.ts](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/serialization/canonicalForwardArtifacts.ts) | Reuse `compareForwardCanonicalStrings`, `canonicalForwardJsonBytes`, `canonicalForwardJsonlBytes` and `forwardArtifactSha256`. Sort semantic rows before JSONL serialization; the existing helper preserves caller order. No digest inside the bytes it hashes. |
| [src/services/result.ts](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/services/result.ts) | Reuse `ServiceResult`, `serviceSuccess` and `serviceFailure` for typed errors/warnings. |
| [src/datasets/seasonal/evaluateSeasonalPpr.ts](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/datasets/seasonal/evaluateSeasonalPpr.ts) | Reuse only the pure `summarizeSeasonalErrors` and `summarizeSeasonalErrorsByPosition` calculations on validated, canonically ordered nonempty point pairs. Add weekly macro/cohort/game/coverage accounting in `replay.ts`. The existing empty-array MAE/RMSE zero defaults must not turn an empty/unavailable weekly cohort into a measured zero loss; retain empty/null-with-reason behavior. |
| [package.json](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/package.json), [package-lock.json](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/package-lock.json), [tsconfig.json](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/tsconfig.json) | Existing Node >=20, strict ES2022/NodeNext TypeScript and Vitest; lockfile versions TypeScript 5.9.3, Vitest 2.1.9, tsx 4.21.0 and @types/node 25.5.0. `src` and `tests` are already included, so no configuration/script edit is needed. Use the available matching local toolchain; missing dependencies are an environment blocker, not permission for a network install. |

Native numeric/BigInt operations may implement the specified cent/rational/rounding semantics without a new math package; any BigInt intermediate must be converted to the declared finite-number or string representation before the existing JSON serializer. Existing component scoring in S7 is a read-only formula reference, not an import of its seasonal experiment orchestration. The seasonal model, frozen runner, live weekly service, FFI publication validator and source-builder scripts are outside the runtime dependency set. Their pins, targets, parameters, minimum-zero policy and authority do not transfer to this slice.

### 10.3 Synthetic verification and permitted check commands

If this exact packet is separately approved, tests use invented IDs, components, games and receipts constructed inside the four test files. They must not read retained historical snapshots, promoted exports, environment credentials, provider endpoints or a database. No real-data fit, evaluation, inferred point or reference output is used as a test oracle. Synthetic mathematical calculations and synthetic staged evaluations are the only proposed execution here; none have been executed during specification preparation.

| Test file | Required synthetic cases |
| --- | --- |
| `tests/year1Week2BootstrapInput.test.ts` | Positive unknown-publication retrieval witness with exact byte hash, independent trust/binding, proper purpose and before/equal-cutoff time; preserved distinct clocks. Reject after-cutoff-only retrieval, self-declared time/trust, mismatched bytes/version/lineage, missing admission and relabeled reconstruction. Historical reconstruction can qualify only for its separate method-selection purpose. Cover zero/missing/no-prior, certified DNP versus missing row, identity/position conflicts, duplicates, partial/truncated game sets and wrong profile/season. |
| `tests/year1Week2BootstrapShrinkage.test.ts` | Independently hand-derived small vectors for Q and T/G, including explicit zero production games; alpha interior, clipping at 0/1 and D=0; unequal position counts to verify fixed weighting; no-prior withholding, no hand-set live weight, no extra predictors. Check negative points, half-cent ties of both signs, 1e-10 reference tolerance, full-precision versus display rounding, and selected-C0 equality with distinct semantics and valid/null movement. |
| `tests/year1Week2BootstrapReplay.test.ts` | Access-recording synthetic stage sources demonstrate no 2024/2025 labels during fitting and no 2025 labels before the 2024 seal; feature/prediction calls never see labels. Reject out-of-order access, mutation after freeze, forged/mismatched stage hashes, refits and any 2026 training season. Exercise minimum 20 rows and 95% label-resolution boundaries for every required position/season; fixed shared cohorts; empty groups and ranking ties; C2 pass-both, validation failure, final failure, tie, zero-alpha, per-position regression and evidence/sufficiency failure. C1 remains diagnostic even if best. Verify reports and no performance-driven reselection. |
| `tests/year1Week2BootstrapArtifacts.test.ts` | Canonical output stable under equivalent input key/row permutations after sorting; hashes change on meaningful mutations. Preserve exactly one census row, all typed reasons, selected rule/anchor/W1 identity, C0 zero/null movement, reconstruction lineage and independent live witness bindings. Reject nonfinite/unknown fields, mismatched player/week/profile or input hashes, labels in candidate output, populated uncertainty and any attempt to emit consumer-ready/admitted status. Candidate bytes never carry their own admission authority. |

Proposed commands, from the Forecast repository root and only with the existing local dependencies available:

- `./node_modules/.bin/tsc --noEmit`
- `./node_modules/.bin/vitest run tests/year1Week2BootstrapInput.test.ts tests/year1Week2BootstrapShrinkage.test.ts tests/year1Week2BootstrapReplay.test.ts tests/year1Week2BootstrapArtifacts.test.ts`

The first command is a static project typecheck; the second runs only the four new synthetic test files. Do not run the whole existing test suite or an experiment/source-generation script under this packet: existing tests include real-artifact reads and experimental execution outside this authority. Report unrelated typecheck failures as limitations without broadening edits. Section 9.2's consumer-serving behavior, including expiry handling, remains a future separately authorized contract/integration task; this slice validates candidate metadata and refusal to claim consumer eligibility only.

### 10.4 Independent-review stopping point

The proposed later implementation stops after the eight-file local diff, static/synthetic check results, and **one independent read-only review of those exact bytes**. Bind the review to the Forecast base SHA and a manifest of relative paths plus SHA-256 for all eight files and the governing specification; an uncommitted local snapshot can be reviewed without creating a branch, commit or PR. The reviewer must be independent of the implementation author and assess the witness trust boundary, historical/live separation, stage isolation, arithmetic/selection invariants, missingness, serialization and absence of external/source/consumer execution paths.

Return the exact diff identity, check results and review findings, then stop for Joe's disposition. A clean review does not authorize historical source use, real-data fitting/evaluation, a 2026 run, Data/Team edits, consumer admission, a branch/PR, merge or deployment. Review findings do not silently expand the eight-file write scope. Implementation and that review have not started; both belong to the exact packet awaiting separate approval.

## 11. Preparation validation and remaining gates

Validation performed during the original docs-only preparation (the dated audit in section 2):

- Re-resolved the three main refs and #269 head/base; no main drift since P0. Re-read #187/addendum and #269 latest review metadata.
- Confirmed the proposed document did not already exist at Forecast main.
- Reused exact-commit source bytes from the P0 audit; verified referenced paths against complete pinned trees and rechecked profile, admission and promotion-manifest Git blob identities.
- Recomputed the inventory counts in section 2 without forecasting, fitting or scoring losses. Kept source-recorded SHA-256 pins distinct from independent local rehashing.
- Checked consistency of C0/C1/C2, cohort denominators, cutoff rules, training/validation/final order, missingness, selection and consumer non-authority.

Validation of the preceding reconstruction/anchor revision was document-only: compared its text with the original; checked historical eligibility, purpose/class propagation, strict live verified-asof admission, anchor/C0/movement semantics and the future negative requirement; confirmed unchanged formulas, alpha-learning rule, season order, identical-cohort/missingness rules, sufficiency thresholds, conservative selection comparisons, existing consumer gates and pinned source references. That revision performed no repository refresh, inventory rerun, fixture, harness, fitting or evaluation.

The final availability-witness clarification changes sections 6.2, 7.1–7.2 and 10's verification requirements. Sections 10.1–10.4 now hold the exact proposed implementation packet requested by Joe. The status preamble, section 2 dated-check note, this validation/terminal record and section 12 reference-link resolution are updated accordingly. No model-selection or feature-family change is introduced.

Validation for this final docs-only pass: compared sections 3–5, 6.1, 8 and 9 against the accepted revised design after normalizing reference-link formatting; their statistical, missingness and consumer rules are unchanged. Checked that unknown publication time plus a qualifying independent retrieval witness is allowed, that a missing/untrusted availability bound still fails live eligibility, and that witness/binding/admission remain separate. Verified all 17 numbered references have concrete Markdown targets: S1 resolves to its fetched review permalink and S2–S17 resolve to full-commit source paths; all 19 file links in those numbered entries exist as blobs in the complete pinned trees. Rechecked Forecast dependency/configuration contents, the eight proposed paths' absence at the planning base, and unchanged source pins. No source inventory rerun, provider/database access, implementation, fixture, typecheck, synthetic test, model fit or evaluation occurred. Every check command in section 10 is proposed future work only.

Still unresolved before a historical study: compatible 2022–2024 weekly panels; explicit experimental use of retained 2025 bytes; exact historical cutoff instants; source-backed cutoff populations/schedule context; denominator/scoring reconciliation; qualification as verified-asof or bounded method-selection reconstruction with disclosed source/revision limits; and separate source-use/run authorization. Missing historical publication witnesses alone need not block the qualified reconstruction study, but this revision assigns no artifact that status and admits none.

Still unresolved before live 2026: independently evidenced verified-asof source-version/cutoff bindings for every live input (including the 2025 prior), complete/admitted Week 1 and cutoff population/schedule packages, an accepted historical selection result retaining any reconstruction limitations, separately authorized/frozen run/configuration, and a reviewed point-only consumer contract/admission before Team use. Historical study eligibility cannot satisfy any live source evidence gate.

Terminal state:

```text
year1_week2_bootstrap_v0_spec_clarified_docs_only
revised_y1_p1_design_accepted_as_scoped
availability_retrieval_witness_clarification_prepared
input_validators_not_frozen
offline_implementation_packet_prepared_not_authorized
exact_packet_separate_approval_pending
historical_reconstruction_method_selection_class_specified_not_admitted
historical_study_source_and_execution_gates_unsatisfied
live_2026_verified_asof_gate_preserved_and_unsatisfied
historical_reconstruction_cannot_satisfy_live_evidence
prior_anchor_and_selected_c0_forecast_semantics_separate
implementation_not_started
independent_implementation_review_not_started
model_fit_or_run_not_executed
source_admission_not_granted
team_consumer_not_activated
forecast_170_185_pins_unchanged
data_269_unchanged_by_this_task
no_branch_pr_merge_or_deployment
```

## 12. Pinned source references

S1–S17 below are retained concrete source paths/permalinks. Bracketed references in the body resolve through the definitions at the end of this document; original audit assertions remain scoped to their recorded pins and dates.

- **S1:** [Data #269](https://github.com/Prometheus-Frameworks/TIBER-Data/pull/269), [latest inspected review at 75797cb](https://github.com/Prometheus-Frameworks/TIBER-Data/pull/269#pullrequestreview-5180579861), [repair delta to c134a0e](https://github.com/Prometheus-Frameworks/TIBER-Data/compare/75797cbdfee0c78ef73f509d919eb0958aed89ef...c134a0e75e1ab5f9cc3ae76168c056c259e392e2).
- **S2:** [Data promoted season-history manifest](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/exports/promoted/nfl/PLAYER_SEASON_COVERAGE_V0_PROMOTION_MANIFEST.json), [retained candidate](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/data/processed/evidence/player_season_coverage_2021_2025.source_backed.json).
- **S3:** [Historical evidence audit](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/docs/audits/draft-review-evidence-admission-2026-09-07.md), [accepted descriptive admission](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/exports/promoted/draft_review/evidence_admission_v1.json).
- **S4:** [2025 outcome components](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/data/processed/evidence/player_weekly_ppr_outcomes_2025.source_backed.json), [2025 usage](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/data/processed/evidence/player_weekly_usage_2025.source_backed.json).
- **S5:** [Bounded population contract](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/docs/contracts/bounded-2026-population-census-v0.md).
- **S6:** [Generic full-PPR profile](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/contracts/genericFullPprProfile.ts).
- **S7:** [Component scoring and existing seasonal evaluation](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/experiments/forwardBaseEval/forwardBaseEvaluation.ts).
- **S8:** [Production-only capability](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/capabilities/player-history-production-only-v0.md).
- **S9:** [Teamstate comparison outcome](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/reports/run2-teamstate-comparison-outcome-2026-06-29.md).
- **S10:** [Inert rookie mirror](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/experiments/rookie-transition-profile-forecast-mirror-implementation-2026-07-11.md).
- **S11:** [Profile-hash equivalence decision](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/decisions/scoring-profile-hash-equivalence-2026-07-28.md).
- **S12:** [Week 1 publication contract](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/contracts/weeklyForecastPublication.ts).
- **S13:** [FFI weekly-player contract](https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/fantasy-forecast-weekly-player-contract-v1.md).
- **S14:** [Fantasy vendored contract provenance](https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/modules/externalModels/scoring/contracts/fantasyForecastWeeklyPlayerV1/VENDOR_PROVENANCE.json).
- **S15:** [Meaningful-input rule](https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/modules/externalModels/scoring/scoringRequestMappers.ts).
- **S16:** [Rankings cohort gate](https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/routes/rankingsV2Routes.ts).
- **S17:** [TIBER Team compiler](https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/modules/draftReview/draftReviewService.ts).

Repository rules read: [Data AGENTS.md](https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/AGENTS.md). No AGENTS.md or CLAUDE.md appeared in the inspected complete Forecast tree. The user's narrower one-document authorization controls this slice.

[S1]: https://github.com/Prometheus-Frameworks/TIBER-Data/pull/269#pullrequestreview-5180579861
[S2]: https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/exports/promoted/nfl/PLAYER_SEASON_COVERAGE_V0_PROMOTION_MANIFEST.json
[S3]: https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/docs/audits/draft-review-evidence-admission-2026-09-07.md
[S4]: https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/data/processed/evidence/player_weekly_ppr_outcomes_2025.source_backed.json
[S5]: https://github.com/Prometheus-Frameworks/TIBER-Data/blob/793329ff77a1764bb61cd70ce4b4b26e7180ae0c/docs/contracts/bounded-2026-population-census-v0.md
[S6]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/contracts/genericFullPprProfile.ts
[S7]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/experiments/forwardBaseEval/forwardBaseEvaluation.ts
[S8]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/capabilities/player-history-production-only-v0.md
[S9]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/reports/run2-teamstate-comparison-outcome-2026-06-29.md
[S10]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/experiments/rookie-transition-profile-forecast-mirror-implementation-2026-07-11.md
[S11]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/decisions/scoring-profile-hash-equivalence-2026-07-28.md
[S12]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/src/contracts/weeklyForecastPublication.ts
[S13]: https://github.com/Prometheus-Frameworks/TIBER-Forecast/blob/e295e3de745b676df571348cb8541fb5e35e3a02/docs/fantasy-forecast-weekly-player-contract-v1.md
[S14]: https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/modules/externalModels/scoring/contracts/fantasyForecastWeeklyPlayerV1/VENDOR_PROVENANCE.json
[S15]: https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/modules/externalModels/scoring/scoringRequestMappers.ts
[S16]: https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/routes/rankingsV2Routes.ts
[S17]: https://github.com/Prometheus-Frameworks/TIBER-Fantasy/blob/e4931017d56e468dd153bc13d327ae3c25d7c691/server/modules/draftReview/draftReviewService.ts
