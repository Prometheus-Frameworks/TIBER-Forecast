# R1a portable recovery

Final eight-file map: dd884ce6b72801451984d9f99a7e9062e1b706d50c32252b7b227b3de6cae0d4
Base: e295e3de745b676df571348cb8541fb5e35e3a02

Verify FILES.sha256. final/ contains the exact eight implementation/test files, package files/configuration and accepted specification. base-to-final.patch restores the implementation on the exact base. r1a-only.patch applies only to the starting snapshot 83d92a66f192b931f86956604ad35a0aeda20650e1f522ebb978e81d49c0b6c3. starting-recovery.zip preserves prior reports, logs and patches. No full base repository or dependencies are bundled.

See independent-review.md for disposition and repair-validation-report.md for commands, results, changed paths and coverage limits. No commands are automatically executed by this archive. Recovery grants no admission or live execution authority.

Data candidate remains e59ff910a70414be333a5145adb9e451d007ea0c5b07c66fd9d87182ce7844d5, raw-support commit e890f825bc5863d16c7afedfbd376c806cfed448. No Data recovery archive was located at prior closeout; Data bytes are not embedded here.
