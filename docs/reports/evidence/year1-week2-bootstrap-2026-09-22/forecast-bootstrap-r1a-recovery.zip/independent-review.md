# Independent exact-snapshot R1a review

Disposition: **clean within full offline-bootstrap implementation scope**.

Reviewer `/root/r1a_exact_snapshot_review` is independent of author `/root`. I inspected the actual final eight files, recovered accepted specification, original and prior independent-review records, starting/final manifests, R1a patch, and validation records/logs. No concrete implementation finding remains from this review. R1a is resolved; F1–F6 and the remainder of R1 remain preserved. The accepted offline implementation can be considered complete within this reviewed implementation scope, subject to the expressly recorded non-exhaustive conformance coverage below. This is not exhaustive proof of every prescribed test case, source qualification or live readiness.

## Exact identity

- Base: `e295e3de745b676df571348cb8541fb5e35e3a02`
- Starting eight-file map: `83d92a66f192b931f86956604ad35a0aeda20650e1f522ebb978e81d49c0b6c3`
- Starting frozen manifest: `b702626a40604616b0aa70edcdeeb85ec147a57e635cc1b5c1293d6f4b5e00e1`
- Final eight-file map: `dd884ce6b72801451984d9f99a7e9062e1b706d50c32252b7b227b3de6cae0d4`
- Final frozen manifest: `4917f380f1d25d02437fe7e5c2d03ab8b5b9461bcb5df8da91758cbb241e3ed5`
- Accepted specification: `7247d91ce06761fcdcf62d78f6910369fdedd3c4d7a4d76dfd0e2f427e135844`
- R1a-only patch: `f5e87d8ce66eaf0c14143eced4c097cbd854ab07e71df1b3a319d8ad873bfd01`
- Validation record: `84670ee1264a778de9b72b1cf669f61dd0769d7ba64fdd1aa8bd3b2d1d8ea450`

Map identity is SHA-256 of the compact, sorted JSON path-to-SHA map. The JSON companion embeds the full final manifest with all eight file hashes, project-file hashes and execution-log hashes. I recomputed these pins from actual local bytes and matched checkout files to frozen copies.

## R1a disposition and evidence

The production delta is only `ComponentEvidence.locator.provider_player_id: string | null` and validation of that field with `nullableString` rather than the blanket nonempty-string loop (`input.ts:429–430, 459–463`). A locator still requires all five exact keys. `source_ref`, `artifact_sha256`, `row` and `field` remain nonempty bounded string fields; the artifact must be a valid SHA-256 and match an accepted source. Explicit null is the sole absent-provider representation. Omitted keys, undefined, empty/whitespace strings, numbers and objects remain invalid.

`preserveEvidence` (`input.ts:496–531`) still requires exact equality with accepted row evidence. Its locator source/hash/provider checks still require the same accepted source and provider identity as the row. A null locator provider therefore cannot contradict a concrete row provider identity. A mapping must match source/provider/canonical/status; a resolved identity still requires source, concrete provider, accepted mapping and canonical GSIS. Unresolved identity cannot carry canonical GSIS. An anonymous source-located row uses unresolved identity with a known accepted source, null provider ID and null mapping; no ID, mapping or confidence is inferred from its row location. Completely unavailable source location remains separately representable as a null locator under states permitting it.

| Required behavior | Actual code/test evidence | Result |
| --- | --- | --- |
| Exact previous failure reproduced | Pre-repair R1a probe reports `component locator: nonempty string required`; its normal synthetic positive control passes | Demonstrated by inspected author log |
| Supported anonymous nonzero/zero observations | Input tests 362–386 retain null provider/canonical/mapping, source hash/row/field, units, values and unavailable forecast eligibility | Covered |
| Source null versus absent/unavailable | Parameterized state tests preserve each state; source-null retains locator, unavailable can have null locator; incomplete scoring yields unavailable W | Covered |
| Required locator and bounded fields | Input tests 388–407 reject missing locator for observed/explicit-zero/source-null, every omitted locator key and malformed provider values | Covered |
| Contradictory identities, source/hash/mapping/confidence or nested labels | Input tests 398–421 reject null/different provider against concrete identity, wrong source/hash/mapping, canonical fabrication, invented provider and unknown confidence/outcome fields | Covered |
| Candidate preservation with no fabricated identity | Artifacts test 296–332 parses actual serialized bytes and checks anonymous nonzero/zero/source-null observations and complete locators, null GSIS/mapping/forecast | Covered |
| Arithmetic and selection unchanged | Same artifact test compares provider-known canonically unresolved versus provider-absent evidence across 2022–2025 synthetic worlds; P/W, prior counts/cents, primary membership, alpha/rule, selected arm, prepared points and candidate points agree; evidence hashes differ | Covered |
| Existing regressions preserved | Both edited test files are byte-prefix extensions of recovered starting files; other focused test files unchanged; all 136 tests pass in author log | Verified |

Exact changed paths are `src/experiments/year1Week2Bootstrap/input.ts`, `tests/year1Week2BootstrapInput.test.ts`, and `tests/year1Week2BootstrapArtifacts.test.ts`. No artifact production, replay, shrinkage or fixture-compatibility edit was required.

## Preserved implementation boundaries

I traced the unchanged exact nested trust/row schemas and channel separation (F1), certified prior-season denominator membership and lineage (F2), issued stage seal and code/configuration identity (F3), witness/reconciliation/world/candidate identity coverage (F4), incomplete-prior states (F5), and candidate generation checks against all training/validation/final feature and label generation clocks (F6). Their existing regressions remain unchanged. R1's full component evidence, optional descriptive targets/carries, accepted mapping records, unavailable-row observations and label/evaluation separation remain intact.

`shrinkage.ts`, `replay.ts`, `artifacts.ts`, shrinkage/replay tests, package/lock/config files are unchanged against recovered starting bytes. Inspected formulas remain C0=P, C1=W, C2=P+alpha(W−P), with one position-balanced bounded alpha, training 2022–2023, sealed 2024 validation and unchanged 2025 evaluation. No descriptive identity/targets/carries enter the three numerical Features. Anonymous rows retain observations but do not become resolved cohort members. Candidate flags, point-only/null uncertainty, separate purpose admission and historical/live boundaries remain unchanged; no live runner is present.

## Actual validation evidence

These are author executions whose frozen logs and exit files I inspected and hashed. I did **not** independently rerun TypeScript, Vitest, a synthetic execution probe or any model.

| Stage | Command/result |
| --- | --- |
| Pre-repair exact R1a probe plus old suite | Focused command below; exit 1; 105 passed, 1 failed with the expected locator error |
| Final compiler | `./node_modules/.bin/tsc --noEmit`; exit 0 |
| Final focused tests | Command below; exit 0; 136 passed, 0 failed; four files passed |

```text
./node_modules/.bin/vitest run tests/year1Week2BootstrapInput.test.ts tests/year1Week2BootstrapShrinkage.test.ts tests/year1Week2BootstrapReplay.test.ts tests/year1Week2BootstrapArtifacts.test.ts
```

Final breakdown: Input 88, Shrinkage 6, Replay 14, Artifacts 28. Recorded unchanged toolchain: Node v24.19.0, TypeScript 5.9.3, Vitest 2.1.9. Test fixtures use invented source bytes, IDs, admissions and labels. Synthetic trust fixture rebinding is acceptance-test setup, not issuance of real authority.

Independently performed checks were read-only file/code/specification inspection, SHA-256 recomputation, starting/final byte comparisons, test-prefix preservation, scope verification and Git HEAD/empty-staging verification. No network, installation, code changes or test execution occurred during this review.

## Remaining prescribed-but-uncovered conformance cases

Prior recorded limits remain: dedicated legitimate prior/current team-change positives; complete roster-state inclusion/exclusion and bye examples; delayed/resumed-game completion positives; exhaustive position-by-season combinations at the minimum-20 and 95% thresholds; and true multi-game inner-row permutation coverage (the current ordering fixture has one prior game per player). These are coverage limitations, not independently demonstrated implementation defects. Existing semantic row permutations and hand-calculated nonconstant mixed-ranking tie tests remain covered and unchanged.

Thus there is no open finding within reviewed offline implementation scope, but do not claim exhaustive full-spec test coverage. Consumer expiry/staleness behavior belongs to a separately scoped future consumer. No actual source/finality/purpose admission, historical dataset study, fitted live alpha, live runner or Week 2 forecast is established by this review.

## Preservation

All final code/frozen-copy/project/log/validation/specification/patch hashes were rechecked, alongside the recovered starting map/manifest and base HEAD. Staging is empty. Only these two new exclusive review reports were written; earlier reports, patches and Data artifacts were not changed. No additional repair or review loop was launched.
